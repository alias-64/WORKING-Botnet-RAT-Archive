# Vulturi-stealer

<img src="https://i.ibb.co/K6SnjYP/Vulturi-Dashboard.pngg" ><br>

<img src="https://i.ibb.co/kB6Lwfn/Vulturi-Statistics.png" ><br>




