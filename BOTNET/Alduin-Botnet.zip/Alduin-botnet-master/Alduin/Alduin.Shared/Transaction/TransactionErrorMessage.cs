﻿namespace Alduin.Shared.Transaction
{
    public class TransactionErrorMessage
    {
        public bool IsPublic { get; set; }

        public string Message { get; set; }
    }
}
