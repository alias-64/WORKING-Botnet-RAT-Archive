﻿namespace Alduin.Shared.Enums
{
    public enum Role
    {
        User,
        Member,
        Admin
    }
}
