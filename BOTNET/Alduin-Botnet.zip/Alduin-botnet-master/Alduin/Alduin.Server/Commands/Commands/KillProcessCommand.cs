﻿
using Alduin.Server.Commands;

public class KillProcessCommands
{
    public KillProcessVariables newVariables { get; set; }
    public BaseCommands newBaseCommand { get; set; }
}

public class KillProcessVariables
{
    public int Id { get; set; }
}
