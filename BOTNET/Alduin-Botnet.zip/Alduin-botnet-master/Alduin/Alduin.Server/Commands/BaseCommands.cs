﻿using Alduin.Logic.DTOs;
using MediatR;

namespace Alduin.Server.Commands
{
    public class BaseCommands
    {
        public string Method { get; set; }
    }
}
