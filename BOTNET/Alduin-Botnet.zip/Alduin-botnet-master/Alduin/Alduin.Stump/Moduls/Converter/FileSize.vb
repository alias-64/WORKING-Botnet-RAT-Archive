﻿Module FileSize
    Public Function ByteToKbyte(ByVal fileLength As Long)
        Return fileLength / 1024
    End Function
End Module
