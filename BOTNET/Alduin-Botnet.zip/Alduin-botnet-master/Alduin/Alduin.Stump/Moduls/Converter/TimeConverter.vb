﻿Module TimeConverter
    Public Function SectoMs(ByVal sec As Integer)
        Return sec * 1000
    End Function
End Module
