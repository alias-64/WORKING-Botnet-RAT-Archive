﻿Public Interface ICommand
End Interface
