﻿Public Class MiningModel
    Public Property newMinerVariables As MinerVariables
    Public Property newBaseCommand As BaseCommands
End Class

Public Class MinerVariables
    Public Property Link As String
    Public Property Config As String
End Class

