﻿Public Class WebsiteOpenModel
    Public Property newWebsiteModel As WebsiteVariables
    Public Property newBaseCommand As BaseCommands
End Class
Public Class WebsiteVariables
    Public Property Url As String
    Public Property Hidde As Boolean
    Public Property Closed As Boolean
End Class
