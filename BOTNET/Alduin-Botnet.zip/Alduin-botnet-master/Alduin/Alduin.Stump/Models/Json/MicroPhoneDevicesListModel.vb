﻿Public Class MicroPhoneDevicesListModel
    Public Property Index As Integer
    Public Property Name As String
End Class
