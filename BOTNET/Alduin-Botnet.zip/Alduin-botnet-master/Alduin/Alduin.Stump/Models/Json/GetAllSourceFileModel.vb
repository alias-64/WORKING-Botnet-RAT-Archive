﻿Public Class GetAllSourceFileModel
    Public Property Files As ArrayList = New ArrayList
End Class
