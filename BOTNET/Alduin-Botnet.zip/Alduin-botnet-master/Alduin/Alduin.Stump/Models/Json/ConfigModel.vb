﻿Namespace Alduin.Stump.Models
    Public Class ConfigModel
        Public Property KeyUnique As String
        Public Property KeyCertified As String
        Public Property MainFileName As String
        Public Property MainPath As String
    End Class
End Namespace


