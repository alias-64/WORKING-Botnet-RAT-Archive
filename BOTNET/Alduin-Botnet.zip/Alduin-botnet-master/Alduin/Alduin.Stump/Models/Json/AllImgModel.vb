﻿Public Class AllImgModel
    Public Property Images As ArrayList = New ArrayList
End Class
