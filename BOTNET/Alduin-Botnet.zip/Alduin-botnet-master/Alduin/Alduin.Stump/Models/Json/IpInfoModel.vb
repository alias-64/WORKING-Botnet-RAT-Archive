﻿Public Class IpInfoModel

    Public Property Ip As String

    Public Property Hostname As String

    Public Property City As String

    Public Property Region As String

    Public Property Country As String

    Public Property Loc As String

    Public Property Org As String

    Public Property Postal As String

End Class
