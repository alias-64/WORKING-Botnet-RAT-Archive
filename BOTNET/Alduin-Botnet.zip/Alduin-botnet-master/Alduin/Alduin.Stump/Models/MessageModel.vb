﻿Public Class MessageModel
    Public Property newMessageModel As MessageVariables
    Public Property newBaseCommand As BaseCommands
End Class
Public Class MessageVariables
    Public Property Msg As String
    Public Property Closed As Boolean
End Class
