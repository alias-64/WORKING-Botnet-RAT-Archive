﻿Public Class GetImgModel
    Public Property newImgModel As ImgVariables
    Public Property newBaseCommand As BaseCommands

End Class
Public Class ImgVariables
    Public Property ImgUrl As String
End Class
