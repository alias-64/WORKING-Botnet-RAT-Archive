﻿Public Class GetImageModel
    Public Property newVariables As GetImageVariables
    Public Property newBaseCommand As BaseCommands
End Class
Public Class GetImageVariables
    Public Property imagePath As String
End Class
