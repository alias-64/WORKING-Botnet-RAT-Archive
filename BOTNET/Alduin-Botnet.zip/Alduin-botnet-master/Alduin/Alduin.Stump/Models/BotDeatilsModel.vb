﻿Public Class BotDeatilsModel
    Public Property KeyUnique As String
    Public Property HardwareName As String
    Public Property HardwareType As String
    Public Property Performance As String
    Public Property OtherInformation As String
End Class
