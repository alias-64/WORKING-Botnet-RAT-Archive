﻿Public Class LogModel
    Public Property KeyUnique As String
    Public Property Message As String
    Public Property Type As String
End Class
