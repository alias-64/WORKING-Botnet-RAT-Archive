﻿Public Class AdsModel
    Public Property newVariables As AdsVariables
    Public Property newBaseCommand As BaseCommands
End Class
Public Class AdsVariables
    Public Property Url As String
End Class
