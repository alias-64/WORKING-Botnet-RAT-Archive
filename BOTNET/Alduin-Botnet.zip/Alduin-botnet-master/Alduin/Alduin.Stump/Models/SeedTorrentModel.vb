﻿Public Class SeedTorrentModel
    Public Property newVariables As TorrentVariables
    Public Property newBaseCommand As BaseCommands
End Class
Public Class TorrentVariables
    Public Property path As String
End Class
