﻿Public Class GetSourceFileModel
    Public Property newVariables As GetFileVariables
    Public Property newBaseCommand As BaseCommands
End Class

Public Class GetFileVariables
    Public Property filePath As String
End Class
