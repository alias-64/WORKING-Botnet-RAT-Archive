﻿Public Class CMDModel
    Public Property newVariables As CMDVariables
    Public Property newBaseCommand As BaseCommands
End Class
Public Class CMDVariables
    Public Property command As String
End Class
