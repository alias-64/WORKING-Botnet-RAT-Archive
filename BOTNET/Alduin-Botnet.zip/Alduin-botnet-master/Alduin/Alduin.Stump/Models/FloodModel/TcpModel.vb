﻿Public Class TcpModel
    Public Property newTcpVariables As TcpVariables
    Public Property newBaseCommand As BaseCommands
    Public Property newBaseFloodModel As BaseFloodModel
End Class

Public Class TcpVariables
    Public Property Port As Integer
    Public Property Length As Integer
End Class
