﻿Public Class RudyModel
    Public Property newRudyVariables As RudyVariables
    Public Property newBaseCommand As BaseCommands
    Public Property newBaseFloodModel As BaseFloodModel
End Class

Public Class RudyVariables
    Public Property Port As Integer
    Public Property PostDATA As String
End Class
