﻿Public Class SlowLorisModel
    Public Property newSlowLorisVariables As SlowLorisVariables
    Public Property newBaseCommand As BaseCommands
    Public Property newBaseFloodModel As BaseFloodModel
End Class

Public Class SlowLorisVariables
    Public Property Port As Integer
    Public Property PostDATA As String
    Public Property RandomFile As Boolean
End Class
