﻿Public Class BaseFloodModel
    Public Property Host As String
    Public Property ThreadstoUse As Integer
    Public Property Time As Integer
End Class
