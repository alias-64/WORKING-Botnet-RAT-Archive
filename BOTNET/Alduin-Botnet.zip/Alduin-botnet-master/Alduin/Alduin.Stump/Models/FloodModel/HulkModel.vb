﻿Public Class HulkModel
    Public Property newHulkVariables As HulkVariables
    Public Property newBaseCommand As BaseCommands
    Public Property newBaseFloodModel As BaseFloodModel
End Class

Public Class HulkVariables
    Public Property Port As Integer
    Public Property PostDATA As String
    Public Property RandomFile As Boolean
End Class
