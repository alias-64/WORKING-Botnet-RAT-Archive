﻿
Public Class ArmeModel
    Public Property newArmeVariables As ArmeVariables
    Public Property newBaseCommand As BaseCommands
    Public Property newBaseFloodModel As BaseFloodModel
End Class
Public Class ArmeVariables
    Public Property Port As Integer
    Public Property PostDATA As String
    Public Property RandomFile As Boolean
End Class
