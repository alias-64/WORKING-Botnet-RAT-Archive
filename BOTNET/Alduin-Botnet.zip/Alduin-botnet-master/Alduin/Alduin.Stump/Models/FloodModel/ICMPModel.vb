﻿Public Class IcmpModel
    Public Property newIcmpVariables As IcmpVariables
    Public Property newBaseCommand As BaseCommands
    Public Property newBaseFloodModel As BaseFloodModel
End Class

Public Class IcmpVariables
    Public Property Length As Integer
    Public Property Timeout As Integer
End Class

