﻿Public Class EditHostFileModel
    Public Property newVariables As EditHostFileVariables
    Public Property newBaseCommand As BaseCommands
End Class
Public Class EditHostFileVariables
    Public Property Line As String
End Class
