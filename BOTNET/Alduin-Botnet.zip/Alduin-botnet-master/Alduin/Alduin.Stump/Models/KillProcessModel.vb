﻿Public Class KillProcessModel
    Public Property newVariables As KillProcessVariables
    Public Property newBaseCommand As BaseCommands
End Class
Public Class KillProcessVariables
    Public Property Id As Integer
End Class
