﻿Public Class ExecuteModel
    Public Property newExecute As ExecuteVariables
    Public Property newBaseCommand As BaseCommands
End Class
Public Class ExecuteVariables
    Public Property Url As String
    Public Property Name As String
    Public Property Run As Boolean
    Public Property Proxy As Boolean
End Class
