﻿Public Class DefaultRegistrationModel
    Public Property UserName As String
    Public Property KeyUnique As String
    Public Property KeyCertified As String
    Public Property Domain As String
    Public Property CountryCode As String
    Public Property LastIPAddress As String
    Public Property City As String
End Class
