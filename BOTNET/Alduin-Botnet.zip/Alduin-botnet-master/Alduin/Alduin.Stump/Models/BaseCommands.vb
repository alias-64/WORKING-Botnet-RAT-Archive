﻿Public Class BaseCommands
    Public Property Methods As String
End Class
