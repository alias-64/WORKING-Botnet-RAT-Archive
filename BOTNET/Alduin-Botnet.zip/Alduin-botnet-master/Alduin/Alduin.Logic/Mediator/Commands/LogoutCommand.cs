﻿using MediatR;

namespace Alduin.Logic.Mediator.Commands
{
    public class LogoutCommand : IRequest
    { }
}
