﻿namespace Alduin.Web.SharedResource
{
    public class SharedResourceDummy
    { }
}
