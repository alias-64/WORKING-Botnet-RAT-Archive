﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alduin.Web.Models.Commands.Commands
{
    public class GetAllFileJsonModel
    {
        public List<string> Files { get; set; }
    }
}
