﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alduin.Web.Models.Commands.Commands
{
    public class GetImgJsonModel
    {
        public List<string> Images { get; set; }
    }
}
