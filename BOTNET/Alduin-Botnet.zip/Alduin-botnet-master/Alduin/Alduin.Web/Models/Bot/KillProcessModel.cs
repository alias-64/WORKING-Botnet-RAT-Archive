﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alduin.Web.Models.Bot
{
    public class KillProcessModel
    {
        public int ProcessId { get; set; }
        public int UserId { get; set; }
    }
}
