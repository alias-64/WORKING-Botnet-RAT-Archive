﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alduin.Web.Models.Bot
{
    public class BotDownloadFileModel
    {
        public string File { get; set; }
        public int UserId { get; set; }
    }
}
