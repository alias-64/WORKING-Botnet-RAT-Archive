﻿namespace Alduin.Web.Models
{
    public class StreamModel
    {
        public StreamModelVariables[] NewVariables { get; set; }
    }
    public class StreamModelVariables
    {
        public string Name { get; set; }
        public string Domain { get; set; }
    }
    
}
