This is the Citadel Botnet v 1.3.5.1

Of course, it's still in Russian.

I need to get spend time translating it.
