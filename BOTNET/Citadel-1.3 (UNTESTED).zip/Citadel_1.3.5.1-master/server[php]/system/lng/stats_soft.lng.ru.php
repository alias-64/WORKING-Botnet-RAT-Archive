<?php if(!defined('__CP__'))die();
define('LNG_STATS',              'Статистика по установленному софту');
define('LNG_STATS_LIMIT',        'Топ N');
?>