<?php if(!defined('__CP__'))die();
define('LNG_REPORTS', 'Commands Output');
define('LNG_STATS_BOTNET', 'For botnet: ');
?>