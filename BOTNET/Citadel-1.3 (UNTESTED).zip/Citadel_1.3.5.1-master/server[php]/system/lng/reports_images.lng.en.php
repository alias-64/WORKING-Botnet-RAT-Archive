<?php
define('LNG_UPDATING_DATABASE',											'Updating database...');

define('LNG_NO_RESULTS',												'No results');
define('LNG_LOAD_MORE',													'Load more');

