<?php
define('LNG_REPORTS',				'Ссылки');

define('LNG_HINT_RMOUSE',			'Подсказка: используйте правую кнопку мыши для вызова контекстного меню');

define('LNG_PARSE_NEW_REPORTS',		'Парсить новые отчёты');

define('LNG_MARK_CHECKED',			'Отметить как "проверенные": ');
define('LNG_MARK_CHECKED_ALL',		'все домены');
define('LNG_MARK_CHECKED_FAVORITE',	'избранные домены');

define('LNG_PARSED_INTERRUPT',		'[ Прервано по лимиту времени. Вы можете продолжить: F5 ]');
define('LNG_PARSED_NEW_DOMAINS',		'Новых доменов:');
define('LNG_PARSED_NEW_REPORTS',		'Новых отчётов:');
define('LNG_PARSED_NEW_HOURS',		' новых часов');
define('LNG_MARKED_REPORTS',			' отчётов были отмечены как "проверенные"');

define('LNG_FORM_DATE',				'Дата');
define('LNG_FORM_URLTYPE',			'Тип ссылки');
define('LNG_FORM_SHOW_CHECKED',		'Показывать проверенные отчёты');
define('LNG_FORM_SHOW_JUNK',			'Показывать исключённые домены');
define('LNG_FORM_AUTOCHECK',			'Автоматически отмечать просмотренные отчёты как "проверенный"');

define('LNG_DOMAINLIST_DOMAIN',		'Домен');
define('LNG_DOMAINLIST_REPORTS',		'Отчётов');
define('LNG_DOMAINLIST_EXPAND',		'Развернуть домен до 3-го уровня');
define('LNG_DOMAINLIST_COLLAPSE',		'Свернуть домен обратно до 2-го уровня');

