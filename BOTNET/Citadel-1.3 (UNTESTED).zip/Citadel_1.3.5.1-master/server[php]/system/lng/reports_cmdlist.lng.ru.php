<?php if(!defined('__CP__'))die();
define('LNG_REPORTS', 'Вывод команд');
define('LNG_STATS_BOTNET', 'Для ботнета: ');

?>