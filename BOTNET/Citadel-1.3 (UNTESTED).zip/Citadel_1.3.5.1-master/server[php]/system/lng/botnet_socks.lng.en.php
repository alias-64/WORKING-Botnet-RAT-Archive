<?php
define('LNG_REPORTS',				'SOCKS');
define('LNG_TOKEN_ACCESS',			'Password-less access link');\

define('LNG_COLUMN_SOCKS',			'SOCKS');
define('LNG_COLUMN_COUNTRY',			'Country');
define('LNG_COLUMN_GEOLOCATION',		'Geolocation');
define('LNG_COLUMN_HOSTNAME',			'Hostname');
define('LNG_COLUMN_UPTIME',			'Uptime');
define('LNG_COLUMN_LAG',				'Lag');

define('LNG_COLUMN_SUFF_HOURS',		'h');
define('LNG_COLUMN_SUFF_SECONDS',		's');
