<?php
define('LNG_MATCHED_FILES',											'Найденные файлы');

define('LNG_MUST_BE_WRITABLE',										'должна существовать и быть доступна на запись');

define('LNG_SCRIPTS',												'Последние скрипты');
define('LNG_SCRIPTS_TH_NAME',										'Имя');
define('LNG_SCRIPTS_TH_SCRIPT',										'Скрипт');
define('LNG_SCRIPTS_TH_DATE',										'Дата');
define('LNG_SCRIPTS_TH_STATUS',										'Статус');
define('LNG_SCRIPTS_STATUS_WAIT',									'Ожидание');
define('LNG_SCRIPTS_STATUS_SENT',									'Отправлен');
define('LNG_SCRIPTS_STATUS_EXECUTED',								'Выполнен');
define('LNG_SCRIPTS_STATUS_FAILED',									'Ошибка');

define('LNG_FILES_TCAP_FOUND_FILES',								'Найдено файлов: ');
define('LNG_FILES_TH_BOT',											'Бот');
define('LNG_FILES_TH_FILE',											'Файл');
define('LNG_FILES_TH_MTIME',										'Дата');
define('LNG_FILES_TH_SIZE',											'Размер');
define('LNG_FILES_TH_STATE',										'Состояние');
define('LNG_FILES_TH_UPDATED',										'Обновлено');
define('LNG_FILES_TH_JOB',											'Задача');
define('LNG_FILES_TH_NOTES',										'Заметки');
