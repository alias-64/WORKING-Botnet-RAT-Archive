<?php
define('LNG_UPDATING_DATABASE',											'Обновление базы данных...');

define('LNG_NO_RESULTS',												'Ничего не найдено');
define('LNG_LOAD_MORE',													'Загрузить ещё');
