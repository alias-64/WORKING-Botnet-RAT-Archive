<?php if(!defined('__CP__'))die();
define('LNG_SYS', 'Information');

define('LNG_SYS_VERSIONS', 'Software versions');
define('LNG_SYS_PATHS',    'Paths');
define('LNG_SYS_CLIENT',   'Client');

define('LNG_SYS_CRON_JOBS',				'Cron jobs');
define('LNG_SYS_CRON_JOB_TIMES',		'times');
define('LNG_SYS_CRON_JOB_RUNNING',		'RUNNING');
define('LNG_SYS_CRON_JOB_NEVER',		'never');
