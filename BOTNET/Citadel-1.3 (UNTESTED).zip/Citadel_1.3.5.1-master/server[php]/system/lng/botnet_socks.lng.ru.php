<?php
define('LNG_REPORTS',				'SOCKS');
define('LNG_TOKEN_ACCESS',			'Ссылка для входа без пароля');

define('LNG_COLUMN_SOCKS',			'SOCKS');
define('LNG_COLUMN_COUNTRY',			'Страна');
define('LNG_COLUMN_GEOLOCATION',		'Геолокация');
define('LNG_COLUMN_HOSTNAME',			'Хост');
define('LNG_COLUMN_UPTIME',			'Uptime');
define('LNG_COLUMN_LAG',				'Лаг');

define('LNG_COLUMN_SUFF_HOURS',		'ч');
define('LNG_COLUMN_SUFF_SECONDS',		'с');

