<?php
define('LNG_THEME_TITLE',			'Crypt exe');

define('LNG_WARNING_PERMISSIONS',		'WARNING!! The required "write" permission is missing on folder ');
define('LNG_HINT_JABBERS',			'Hint: if scan4you is configured, you can <a href="?m=ajax_config&action=scan4you" class="ajax_colorbox" />add crypter\'s JabberID</a> to the list');

define('LNG_DIV_UPLOAD',				'Upload');
define('LNG_DIV_UPLOAD_NOPERM',		'Not enough permissions to upload: need `r_svc_crypter_crypt`');
define('LNG_DIV_UPLOAD_SUBMIT',		'Upload');
define('LNG_DIV_UPLOAD_ERROR',		'Upload error #');
define('LNG_DIV_UPLOAD_SUCCESS',		'Uploaded successfully');

define('LNG_DIV_HISTORY',			'Upload history');
define('LNG_DIV_HISTORY_FILENAME',		'Filename');
define('LNG_DIV_HISTORY_FILENAME_CUR',	'(current)');
define('LNG_DIV_HISTORY_DATE',		'Date');
define('LNG_DIV_HISTORY_HASH',		'Hash');
define('LNG_DIV_HISTORY_PAID',		'Paid');
define('LNG_DIV_HISTORY_PAY',			'Pay');




