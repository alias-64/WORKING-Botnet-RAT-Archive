<?php
define('LNG_REPORTS_TH_BOT_REPORT',										'Бот, Отчёт');
define('LNG_REPORTS_TH_RTIME',											'Время отчёта');
define('LNG_REPORTS_TH_COMMENT',										'Коммент');

