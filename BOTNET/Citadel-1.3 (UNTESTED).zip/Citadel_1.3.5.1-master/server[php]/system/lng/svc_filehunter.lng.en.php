<?php
define('LNG_MATCHED_FILES',											'Matched files');

define('LNG_MUST_BE_WRITABLE',										'must exist & be writable');

define('LNG_SCRIPTS',												'Recent scripts');
define('LNG_SCRIPTS_TH_NAME',										'Name');
define('LNG_SCRIPTS_TH_SCRIPT',										'Script');
define('LNG_SCRIPTS_TH_DATE',										'Date');
define('LNG_SCRIPTS_TH_STATUS',										'Status');
define('LNG_SCRIPTS_STATUS_WAIT',									'Wait');
define('LNG_SCRIPTS_STATUS_SENT',									'Sent');
define('LNG_SCRIPTS_STATUS_EXECUTED',								'Executed');
define('LNG_SCRIPTS_STATUS_FAILED',									'Failed');

define('LNG_FILES_TCAP_FOUND_FILES',								'Files found: ');
define('LNG_FILES_TH_BOT',											'Bot');
define('LNG_FILES_TH_FILE',											'File');
define('LNG_FILES_TH_MTIME',										'MTime');
define('LNG_FILES_TH_SIZE',											'Size');
define('LNG_FILES_TH_STATE',										'State');
define('LNG_FILES_TH_UPDATED',										'Updated');
define('LNG_FILES_TH_JOB',											'Job');
define('LNG_FILES_TH_NOTES',										'Notes');
