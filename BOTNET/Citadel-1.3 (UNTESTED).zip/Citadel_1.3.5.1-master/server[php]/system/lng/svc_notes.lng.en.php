<?php
define('LNG_DIR_MUST_BE_WRITABLE',									'The directory must have the write permission');
define('LNG_FILE_MUST_BE_WRITABLE',								'The file must have the write permission');
