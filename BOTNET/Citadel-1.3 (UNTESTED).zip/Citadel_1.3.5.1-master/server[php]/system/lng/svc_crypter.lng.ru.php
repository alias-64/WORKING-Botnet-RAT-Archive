<?php
define('LNG_THEME_TITLE',			'Крипт exe');

define('LNG_WARNING_PERMISSIONS',		'ВНИМАНИЕ!! Требуется право записи "rwx" на папку ');
define('LNG_HINT_JABBERS',			'Подсказка: если настроен scan4you — Вы можете <a href="?m=ajax_config&action=scan4you" class="ajax_colorbox" />добавить JabberID криптера</a> в список');

define('LNG_DIV_UPLOAD',				'Загрузка');
define('LNG_DIV_UPLOAD_NOPERM',		'Недостаточно прав для загрузки: нужно `r_svc_crypter_crypt`');
define('LNG_DIV_UPLOAD_SUBMIT',		'Загрузить');
define('LNG_DIV_UPLOAD_ERROR',		'Ошибка загрузки #');
define('LNG_DIV_UPLOAD_SUCCESS',		'Успешно загружено');

define('LNG_DIV_HISTORY',			'История загрузок');
define('LNG_DIV_HISTORY_FILENAME',		'Файл');
define('LNG_DIV_HISTORY_FILENAME_CUR',	'(используется)');
define('LNG_DIV_HISTORY_DATE',		'Дата');
define('LNG_DIV_HISTORY_HASH',		'Хэш');
define('LNG_DIV_HISTORY_PAID',		'Оплачено');
define('LNG_DIV_HISTORY_PAY',			'Оплатить');



