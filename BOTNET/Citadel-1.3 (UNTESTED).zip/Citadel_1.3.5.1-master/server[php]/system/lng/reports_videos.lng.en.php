<?php if(!defined('__CP__'))die();
define('LNG_REPORTS', 'Video viewer');
define('LNG_STATS_BOTNET', 'For botnet: ');
?>