<?php if(!defined('__CP__'))die();
define('LNG_STATS',              'Installed Software Statistics');
define('LNG_STATS_LIMIT',        'TOP N');
?>