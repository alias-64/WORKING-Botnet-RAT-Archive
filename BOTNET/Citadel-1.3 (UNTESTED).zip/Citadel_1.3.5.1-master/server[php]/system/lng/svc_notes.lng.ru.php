<?php
define('LNG_DIR_MUST_BE_WRITABLE',									'Директория должна иметь права записи');
define('LNG_FILE_MUST_BE_WRITABLE',								'Файл должен иметь права записи');
