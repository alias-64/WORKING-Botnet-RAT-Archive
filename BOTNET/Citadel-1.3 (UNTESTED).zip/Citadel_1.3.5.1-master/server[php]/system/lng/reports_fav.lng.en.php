<?php
define('LNG_REPORTS_TH_BOT_REPORT',										'Bot, Report');
define('LNG_REPORTS_TH_RTIME',											'Report time');
define('LNG_REPORTS_TH_COMMENT',										'Comment');

