#ifndef __M_RESOURCE__
#define __M_RESOURCE__

#include "mRandom.h"
#include "mPathBuilder.h"
#include "mCode.h"
#include "funcs.h"

extern mRandom random;

class mResourceBuilder
{
	DWORD			total;
	mPathBuilder*	path_builder;
	mCode			rc;

	void	begin_resource();
	void	escape_path(PCHAR dest, PCHAR source);
	mCode&	get_sentence(mCode &stub, DWORD min, DWORD max);
public:
	mResourceBuilder(mPathBuilder *path_builder);
	void	generate_manifest_uac();
	void	generate_version_info();
	void	add_rcdata(DWORD id, PVOID data, DWORD data_size);
	void	save_resource();
	void	add_custom_file(PCHAR file_name, PVOID data, DWORD data_size);
	bool	is_empty();
};

#endif