#ifndef __CONFIG__
#define __CONFIG__

#define CONFIG_DEBUG 1
#define CONFIG_MCODE_EXPRESSION_MAX_ARGUMENTS 4
#define CONFIG_CODE_LINE_MAX_LENGTH 256
#define CONFIG_COMMENT_MAX_LENGTH 72
#define CONFIG_EXTEND_MIN_SIZE 32

#define CONFIG_DEBUG_SOURCE // tmp/0_0000000000/

#ifdef _DEBUG
//#define CONFIG_DEBUG_SWITCH
//#define CONFIG_DEBUG_IF
//#define CONFIG_DEBUG_PAYLOAD // __debugbreak() before payload callpi
//#define CONFIG_DEBUG_EMULATOR
#endif

#endif