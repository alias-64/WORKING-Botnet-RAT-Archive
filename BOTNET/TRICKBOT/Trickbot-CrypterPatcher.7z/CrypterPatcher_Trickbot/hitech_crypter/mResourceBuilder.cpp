#include <windows.h>
#include <tchar.h>

#include "config.h"
#include "mResourceBuilder.h"

mResourceBuilder::mResourceBuilder(mPathBuilder *path_builder) : rc(16000)
{
	this->path_builder = path_builder;
	total = 0;
}

void mResourceBuilder::begin_resource()
{
	if( !total )
	{
		rc << "#include <windows.h>\r\n";
		rc << "\r\n";
	}
}

void mResourceBuilder::add_custom_file(PCHAR file_name, PVOID data, DWORD data_size)
{
	path_builder->add_file(file_name, data, data_size);
}

void mResourceBuilder::add_rcdata(DWORD id, PVOID data, DWORD data_size)
{
	CHAR name[50];

	wsprintfA(name,"rcdata_%d.dat", id);

	add_custom_file(name, data, data_size);

	begin_resource();

	rc << id << " RCDATA \"" << name << "\"\r\n"; 
	//rc << id << " FONT \"" << name << "\"\r\n";
	total++;
}

bool mResourceBuilder::is_empty()
{
	return total==0;
}

void mResourceBuilder::escape_path(PCHAR dest, PCHAR source)
{
	if( dest && source )
	{
		PCHAR pdest = dest;
		for(int i = 0; source[i] ; i++)
		{
			if( source[i]=='\\' )
			{
				*pdest++ = '\\';
			}
			*pdest++ = source[i];
		}
		*pdest = 0;
	}
}

void mResourceBuilder::generate_manifest_uac()
{
	begin_resource();

	rc << "1 RT_MANIFEST \"manifest.txt\"\r\n\r\n";

	CHAR uac[] = 
		"<assembly xmlns=\"urn:schemas-microsoft-com:asm.v1\" manifestVersion=\"1.0\">\r\n"
		"  <trustInfo xmlns=\"urn:schemas-microsoft-com:asm.v3\">\r\n"
		"    <security>\r\n"
		"      <requestedPrivileges>\r\n"
		"        <requestedExecutionLevel level=\"asInvoker\" uiAccess=\"false\"></requestedExecutionLevel>\r\n"
		"      </requestedPrivileges>\r\n"
		"    </security>\r\n"
		"  </trustInfo>\r\n"
		"</assembly>";
	
	add_custom_file("manifest.txt", uac, sizeof(uac) - 1);

	total++;
}

mCode& mResourceBuilder::get_sentence(mCode &stub, DWORD min, DWORD max)
{
	DWORD count = random.get_equal(min,max);

	DWORD  word_list_size;
	PCHAR* word_list = get_wordlist(&word_list_size);

	CHAR saved_word[256];

	for(int i = 0; i < count; i++)
	{
		if( i > 0 )
			stub << " ";

		PCHAR word = word_list[ random.get_less(0,word_list_size) ];

		if( !i )
		{
			lstrcpyA(saved_word, word);

			if( saved_word[0]>=0x61 && saved_word[0]<=0x7A )
			{
				saved_word[0] -= 0x20; // to upper case
			}

			stub << saved_word;
		}else{
			stub << word;
		}
	}

	return stub;
}

void mResourceBuilder::generate_version_info()
{
	begin_resource();

	mCode verinfo(0xFFFF);
	CHAR version[256];
	CHAR verdot[256];

	DWORD a,b,c,d;

	a = random.get_less(1,9);
	b = random.get_less(0,312);
	c = random.get_less(0,312);
	d = random.get_less(0,9);

	wsprintfA(version,"%d,%d,%d,%d",a,b,c,d);
	wsprintfA(verdot,"%d.%d.%d.%d",a,b,c,d);

	verinfo << "1 VERSIONINFO\r\n";
	verinfo << "\tFILEVERSION " << version << "\r\n";
	verinfo << "\tPRODUCTVERSION " << version << "\r\n";
	verinfo << "\tFILEOS 0x4\r\n";
	verinfo << "\tFILETYPE 0x1\r\n";
	verinfo << "\r\n";
	verinfo << "\tBEGIN\r\n";
	verinfo << "\tBLOCK \"StringFileInfo\"\r\n";
	verinfo << "\tBEGIN\r\n";
	verinfo << "\t\tBLOCK \"040904E4\"\r\n";
	verinfo << "\t\tBEGIN\r\n" ;

	verinfo << "\t\t\tVALUE \"Comments\", \""; get_sentence(verinfo, 2, 6); verinfo << "\\0\"\r\n";
	verinfo << "\t\t\tVALUE \"CompanyName\", \"";		get_sentence(verinfo, 1 , 3); verinfo << "\\0\"\r\n";
	verinfo << "\t\t\tVALUE \"FileDescription\", \"";	get_sentence(verinfo, 2, 6); verinfo << "\\0\"\r\n";
	verinfo << "\t\t\tVALUE \"FileVersion\", \"" << verdot << "\\0\"\r\n";
	verinfo << "\t\t\tVALUE \"InternalName\", \"";		get_sentence(verinfo,1 , 2); verinfo << "\\0\"\r\n";
	verinfo << "\t\t\tVALUE \"LegalCopyright\", \"Copyright � "; get_sentence(verinfo, 2, 6); verinfo << "\\0\"\r\n";
	verinfo << "\t\t\tVALUE \"LegalTrademarks\", \"";  get_sentence(verinfo, 2, 6); verinfo << "\\0\"\r\n";
	verinfo << "\t\t\tVALUE \"OriginalFilename\", \"";get_sentence(verinfo,1 , 2); verinfo << "\\0\"\r\n";
	verinfo << "\t\t\tVALUE \"ProductName\", \""; get_sentence(verinfo,1 , 2); verinfo << "\\0\"\r\n";
	verinfo << "\t\t\tVALUE \"ProductVersion\", \"" << verdot << "\\0\"\r\n";

	verinfo << "\t\tEND\r\n" ;
	verinfo << "\tEND\r\n" ;
	verinfo << "\r\n";

	verinfo << "\tBLOCK \"VarFileInfo\"\r\n" ;
	verinfo << "\tBEGIN\r\n" ;
	verinfo << "\t\tVALUE \"Translation\", 0x081A 0x081A\r\n" ;
	verinfo << "\tEND\r\n" ;
	verinfo << "END\r\n\r\n" ;

	rc.add(verinfo);
	total++;
}

void mResourceBuilder::save_resource()
{
	add_custom_file("resource.rc", rc.get(), rc.length());
}