#ifndef _M_OUTPUT_PATCHER_
#define _M_OUTPUT_PATCHER_

#include "funcs.h"
#include "base64.h"

enum MMARKER_TYPE
{
	MMARKER_TYPE_UNKNOWN,
	MMARKER_TYPE_RCDATA_RVA,
	MMARKER_TYPE_FONT_RVA,
	MMARKER_TYPE_IMPORT_RVA
};

typedef struct _MMARKER_DATA
{
	DWORD	marker;
	BYTE	type;
	union
	{
		struct  
		{
			DWORD id;
			DWORD offset;
		}rcdata;
		struct  
		{
			CHAR name[30];
		}import;
	};
}MMARKER_DATA,*PMMARKER_DATA;

typedef struct _MPATCHER_SERIALIZE
{
	DWORD total;
	MMARKER_DATA markers[0xFF];
}MPATCHER_SERIALIZE,*PMPATCHER_SERIALIZE;

class mOutputPatcher
{
	PTCHAR out_file;
	DWORD  total;
	DWORD  current;

	MMARKER_DATA	markers[0xFF];

	PDWORD	find_marker(DWORD marker, PVOID data, DWORD data_size);
	DWORD	get_iat_offset(PIMAGE_DOS_HEADER dos, PCHAR proc_name);
public:
	mOutputPatcher(PTCHAR out_file);

	void	clear();
	DWORD	get_rcdata_marker(DWORD resource_id, DWORD offset);
	DWORD	get_font_marker(DWORD resource_id, DWORD offset);
	DWORD	get_import_marker(PCHAR proc_name);

	PCHAR	serialize();
	bool	unserialize(PCHAR data, DWORD length);

	bool	patch_markers();
	PTCHAR	get_out_file();
	DWORD	get_count();
};

#endif