#include "cConsole.h"

//////////////////////////////////////////////////////////////////////////
//	ConsoleCloseHandler
//////////////////////////////////////////////////////////////////////////
BOOL _stdcall ConsoleCloseHandler(DWORD IN dwCtrlType)
{
	DWORD				dwCurPid, dwCurTid;
	HANDLE				hSnap, hProcess, hThread;
	PROCESSENTRY32W		ProcEntryW;
	THREADENTRY32		ThrEntry;
	std::vector<DWORD>	Pids;
	DWORD				pid_i, pid_x, pid_y;
	BOOL				blTargetPid;
	BOOL				blProcessFound;
	BOOL				blListed;


	//==========================================
	//	INITIALIZE
	//==========================================
	dwCurPid = GetCurrentProcessId();
	dwCurTid = GetCurrentThreadId();
	Pids.clear();
	Pids.push_back(GetCurrentProcessId());
	g_blStopFlag = TRUE;

	//==========================================
	//	STOP PROCESSES
	//==========================================
	//	stop all created processes, for examble
	//	cl.exe, link.exe, rc.exe, etc...
	//

	hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPALL, 0);
	if (hSnap != INVALID_HANDLE_VALUE)
	{
		ProcEntryW.dwSize = sizeof(ProcEntryW);


	_rescan:
		blProcessFound = FALSE;
		Process32FirstW(hSnap, &ProcEntryW);
		do
		{
			//	check for parent pid
			for (pid_i = 0; pid_i < Pids.size(); pid_i++)
			{
				if (Pids.at(pid_i) == ProcEntryW.th32ParentProcessID)
				{

					//	check for already existing
					blListed = FALSE;
					for (pid_x = 0; pid_x<Pids.size(); pid_x++)
					{
						if (Pids.at(pid_x) == ProcEntryW.th32ProcessID)
						{
							blListed = TRUE;
							break;
						};
					};

					//	if not listed - add to list
					if (blListed == FALSE)
					{
						Pids.push_back(ProcEntryW.th32ProcessID);
						blProcessFound = TRUE;
					};
				};
			};
		} while (Process32NextW(hSnap, &ProcEntryW) != 0);
		if (blProcessFound == TRUE) goto _rescan;
		CloseHandle(hSnap);

		//	terminate processes
		for (pid_i = 0; pid_i<Pids.size(); pid_i++)
		{
			hProcess = OpenProcess(PROCESS_TERMINATE | PROCESS_SUSPEND_RESUME | PROCESS_QUERY_INFORMATION, FALSE, Pids.at(pid_i));
			if (hProcess != 0)
			{
				TerminateProcess(hProcess, -1L);
				CloseHandle(hProcess);
			};
		};
	};

	//==========================================
	//	EXIT PROCESS
	//==========================================
	g_blStopFlag = TRUE;
	Pids.clear();
	ExitProcess(0);
};


//////////////////////////////////////////////////////////////////////////
//	PrepareConsole
//////////////////////////////////////////////////////////////////////////
//	This function contains all code for initialization and preparing 
//	main console
//////////////////////////////////////////////////////////////////////////
BOOL _stdcall PrepareConsole()
{
	//CONSOLE_SCREEN_BUFFER_INFO	ScreenInfo;


	////	initialize
	//g_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
	//SetErrorMode(1);
	//SetPriorityClass(GetCurrentProcess(), IDLE_PRIORITY_CLASS);

	////	set new exit handler
	//SetConsoleCtrlHandler(0, FALSE);
	//SetConsoleCtrlHandler(&ConsoleCloseHandler, TRUE);


	////	set new console size
	//GetConsoleScreenBufferInfo(g_hStdOut, &ScreenInfo);
	//ScreenInfo.dwSize.Y |= 0xFF;
	//SetConsoleScreenBufferSize(g_hStdOut, ScreenInfo.dwSize);
	return TRUE;
}