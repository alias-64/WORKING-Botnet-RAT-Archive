#pragma once

void makeApiHash(DWORD64 _seed, mPathBuilder _path);