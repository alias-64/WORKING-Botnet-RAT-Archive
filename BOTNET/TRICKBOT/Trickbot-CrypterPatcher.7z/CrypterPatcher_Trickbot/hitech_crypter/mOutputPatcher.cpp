#include <windows.h>
#include <tchar.h>
#include <intrin.h>

#include "mOutputPatcher.h"

mOutputPatcher::mOutputPatcher(PTCHAR out_file)
{
	this->out_file = out_file;

	clear();
}

void mOutputPatcher::clear()
{
	total = 0;
	current = 0;

	mem_zero(markers,sizeof(markers));
	for(int i = 0; i < sizeof(markers)/sizeof(MMARKER_DATA); i++)
	{
		markers[i].marker = 0x70DEA00A | (i << 4);
	}
}

DWORD mOutputPatcher::get_rcdata_marker(DWORD resource_id, DWORD offset)
{
	if( current >= sizeof(markers)/sizeof(MMARKER_DATA) )
		return NULL;

	markers[current].type = MMARKER_TYPE_RCDATA_RVA;
	markers[current].rcdata.id = resource_id;
	markers[current].rcdata.offset = offset;

	total++;

	return markers[current++].marker;
}

DWORD mOutputPatcher::get_font_marker(DWORD resource_id, DWORD offset)
{
	if (current >= sizeof(markers) / sizeof(MMARKER_DATA))
		return NULL;

	markers[current].type = MMARKER_TYPE_FONT_RVA;
	markers[current].rcdata.id = resource_id;
	markers[current].rcdata.offset = offset;

	total++;

	return markers[current++].marker;
}

DWORD mOutputPatcher::get_import_marker(PCHAR proc_name)
{
	if( current >= sizeof(markers)/sizeof(MMARKER_DATA) )
		return NULL;

	markers[current].type = MMARKER_TYPE_IMPORT_RVA;
	lstrcpyA(markers[current].import.name ,proc_name);

	total++;

	return markers[current++].marker;
}

PDWORD mOutputPatcher::find_marker(DWORD marker, PVOID data, DWORD data_size)
{
	if( marker && data && data_size > 3 )
	{
		for(int i = 0; i < data_size; i++)
		{
			if( *(PDWORD)((PBYTE)data + i)==marker )
				return (PDWORD)((PBYTE)data + i);
		}
	}
	return NULL;
}

PCHAR mOutputPatcher::serialize()
{
	MPATCHER_SERIALIZE sdata;

	sdata.total = total;
	mem_copy(sdata.markers, markers, sizeof(markers));

	return base64_encode((PBYTE)&sdata, sizeof(MPATCHER_SERIALIZE));
}

bool mOutputPatcher::unserialize(PCHAR data, DWORD data_length)
{
	if( data && data_length )
	{
		MPATCHER_SERIALIZE* sdata = (MPATCHER_SERIALIZE*)base64_decode(data, data_length);
		if( sdata )
		{
			total = sdata->total;
			mem_copy(markers, sdata->markers, sizeof(markers));

			return true;
		}
	}
	return false;
}

DWORD mOutputPatcher::get_iat_offset(PIMAGE_DOS_HEADER dos, PCHAR proc_name)
{
	if( dos )
	{
		if( dos->e_magic==IMAGE_DOS_SIGNATURE )
		{
			PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS)((DWORD_PTR)dos + dos->e_lfanew);
			if( nt->Signature==IMAGE_NT_SIGNATURE )
			{
				PIMAGE_IMPORT_DESCRIPTOR import;

				if( nt->FileHeader.Machine==IMAGE_FILE_MACHINE_I386 )
				{
					import = (PIMAGE_IMPORT_DESCRIPTOR)((DWORD_PTR)dos + ((PIMAGE_NT_HEADERS32)nt)->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);
				}else{
					import = (PIMAGE_IMPORT_DESCRIPTOR)((DWORD_PTR)dos + ((PIMAGE_NT_HEADERS64)nt)->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);
				}

				if( import!=(PIMAGE_IMPORT_DESCRIPTOR)dos )
				{
					while( import->Characteristics!=0 )
					{
						if( nt->FileHeader.Machine==IMAGE_FILE_MACHINE_I386 )
						{
							PDWORD32 orig = (PDWORD32)((DWORD_PTR)dos + import->OriginalFirstThunk);
							PDWORD32 iat  = (PDWORD32)((DWORD_PTR)dos + import->FirstThunk);

							while( *iat )
							{
								PCHAR cur_name = (PCHAR)((DWORD_PTR)dos + *orig + 2);

								if( !lstrcmpA(cur_name, proc_name) )
								{
									return ((DWORD_PTR)iat - (DWORD_PTR)dos);
								}

								orig++;
								iat++;
							}
						}else{
							PDWORD64 orig = (PDWORD64)((DWORD_PTR)dos + import->OriginalFirstThunk);
							PDWORD64 iat  = (PDWORD64)((DWORD_PTR)dos + import->FirstThunk);

							while( *iat )
							{
								PCHAR cur_name = (PCHAR)((DWORD_PTR)dos + *orig + 2);

								if( !lstrcmpA(cur_name, proc_name) )
								{
									return ((DWORD_PTR)iat - (DWORD_PTR)dos);
								}

								orig++;
								iat++;
							}
						}

						import++;
					}
				}
			}
		}
	}

	return 0;
}

PTCHAR mOutputPatcher::get_out_file()
{
	return out_file;
}

DWORD mOutputPatcher::get_count()
{
	return total;
}

bool mOutputPatcher::patch_markers()
{
	bool result = false;

	if( total && out_file )
	{
		HANDLE file = CreateFile(out_file,GENERIC_READ | GENERIC_WRITE,NULL,NULL,OPEN_EXISTING,NULL,NULL);
		if( file!=INVALID_HANDLE_VALUE )
		{
			HANDLE map = CreateFileMapping(file,NULL,PAGE_READWRITE, 0, 0, NULL);
			if( map )
			{
				PVOID data = MapViewOfFile(map,FILE_MAP_WRITE,0,0,0);
				if( data )
				{
					PIMAGE_DOS_HEADER dos = (PIMAGE_DOS_HEADER)data;
					PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS)((PBYTE)data + dos->e_lfanew);

					PIMAGE_SECTION_HEADER section = IMAGE_FIRST_SECTION(nt);

					PVOID image = NULL;

					for(int i = 0; i < total; i++)
					{
						PDWORD finded = find_marker(markers[i].marker, (PBYTE)data + section->PointerToRawData, section->SizeOfRawData);
						if( finded )
						{
							if( !image )
							{
								image = file2image(data);
							}
							result = true;
							switch( markers[i].type )
							{
								case MMARKER_TYPE_RCDATA_RVA:
									{
										PIMAGE_RESOURCE_DATA_ENTRY res = (PIMAGE_RESOURCE_DATA_ENTRY)FindResource((HMODULE)image,MAKEINTRESOURCE(markers[i].rcdata.id),RT_RCDATA);
										if( res )
										{
											auto _resOffset = res->OffsetToData + markers[i].rcdata.offset;
											*finded = _resOffset;

											if (_resOffset == 0) {
												_tprintf(_T("Critical Error: _resOffset is zero (0)!\r\n"));
											}
										}else{
											_tprintf(_T("Critical Error: Can not find patch RCData resource!\r\n"));
#ifdef _DEBUG
#ifdef __CONFIG__ // in hitech_project needed, but not neeeded in patcher
											__debugbreak();
#endif
#endif
										}
									}
									break;
								case MMARKER_TYPE_FONT_RVA:
								{
									PIMAGE_RESOURCE_DATA_ENTRY res = (PIMAGE_RESOURCE_DATA_ENTRY)FindResource((HMODULE)image, MAKEINTRESOURCE(markers[i].rcdata.id), RT_FONT); //(LPCTSTR)"jpeg"
									if (res)
									{
										*finded = res->OffsetToData + markers[i].rcdata.offset; // *finded = ((DWORD)image - (DWORD)res) + markers[i].rcdata.offset;
									}
									else{
										_tprintf(_T("Critical Error: Can not find patch font resource!\r\n"));
									}
								}
									break;
								case MMARKER_TYPE_IMPORT_RVA: {
									auto _iatOffset = get_iat_offset((PIMAGE_DOS_HEADER)image, markers[i].import.name);

									if (_iatOffset == 0) {
										_tprintf(_T("Critical Error: Can not find patch IAT offset!\r\n"));
										result = false;
									}

									*finded = _iatOffset;
								}
								break;
							}
						}else{
							_tprintf(_T("Critical Error: Can not find patch marker!\r\n"));
#ifdef _DEBUG
#ifdef __CONFIG__  // in hitech_project needed, but not neeeded in patcher
							__debugbreak();
#endif
#endif
						}
					}

					UnmapViewOfFile(data);
				}

				CloseHandle(map);
			}

			CloseHandle(file);
		}
	}
	return result;
}