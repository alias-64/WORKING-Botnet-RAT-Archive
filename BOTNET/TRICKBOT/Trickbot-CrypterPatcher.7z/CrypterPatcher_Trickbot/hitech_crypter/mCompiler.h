#ifndef __MCOMPILER__
#define __MCOMPILER__

#include "mPathBuilder.h"

typedef struct _MCOMPILER_LINE
{
	LIST_ENTRY	entry;
	CHAR		string[1024];
}MCOMPILER_LINE,*PMCOMPILER_LINE;

typedef struct _MCOMPILER_LINE_EX
{
	LIST_ENTRY	entry;
	PCHAR		string;
}MCOMPILER_LINE_EX,*PMCOMPILER_LINE_EX;

class mCompiler
{
	PIMAGE_NT_HEADERS	nt;
	mCode				bat;
	LIST_ENTRY			lines;
	LIST_ENTRY			files;
	LIST_ENTRY			pause_lines;

	mPathBuilder		*path_builder;
	BOOL				is_resource;
	PCHAR				entry_point;

	PCHAR				advanced_flags;

	void create_bat_file(PCHAR bat_path, PCHAR out_file);
	DWORD get_image_size(PCHAR file_path);
	void strip_extension(PCHAR dest, PCHAR source);
	bool	add_custom_file(PCHAR format, ...);
public:
	mCompiler(mPathBuilder *path_builder, PVOID orig_file_data);

	void	set_advanced_flags(PCHAR flags);

	bool	add_custom_line(PCHAR format, ...);
	void	add_file(PCHAR file_name);

	void	add_pause_line(PCHAR format, ...);
	void	add_pause_line_ex(PCHAR line);

	void	set_entry_point(PCHAR entry_point_name);

	bool	add_asm_file(PCHAR file_name);
	bool	add_resource();
	bool	add_main_cpp();

	DWORD	build(PCHAR	out_file);
	DWORD	build(PWCHAR out_file);
};

#endif