#ifndef __MUTATE__
#define __MUTATE__

#include "mCodeLines.h"

UINT32 mutate_get_imm32()
{
	UINT32 start = 0;
	for(int i = 0; i < 8; i++)
	{
		start <<= 4;
		start |= random.get_less(1,0xF);
	}
	return start;
}

UINT16 mutate_get_imm16()
{
	UINT32 start = 0;
	for(int i = 0; i < 4; i++)
	{
		start <<= 4;
		start |= random.get_less(1,0xF);
	}
	return start;
}

void mutate_create32(mVars* locals, PCHAR name)
{
	if( random.get_less(0,2) )
	{
		locals->add_custom("INT32", name);
	}else{
		locals->add_custom("UINT32", name);
	}
}

void mutate_mov_imm32(mCodeLines *lines, PCHAR var_name, UINT32 imm)
{
	UINT32 crypted_imm, crypted_imm2, random_imm;

	random_imm = mutate_get_imm32();

	DWORD pos = random.get_less(0,4);

	//pos = 3;
	//lines->add_ex(MCODELINE_FLAG_NO_TRASH, "__debugbreak();\r\n");

	switch( pos )
	{
		case 0: // xor
			crypted_imm = imm ^ random_imm;

			lines->add("%s = 0x%0.8X;\r\n", var_name, crypted_imm);
			lines->add("%s ^= 0x%0.8X;\r\n", var_name, random_imm);
			break;
		case 1: // add
			crypted_imm = imm + random_imm;

			lines->add("%s = 0x%0.8X;\r\n", var_name, crypted_imm);
			lines->add("%s -= 0x%0.8X;\r\n", var_name, random_imm);
			break;
		case 2: // sub
			crypted_imm = imm - random_imm;

			lines->add("%s = 0x%0.8X;\r\n", var_name, crypted_imm);
			lines->add("%s += 0x%0.8X;\r\n", var_name, random_imm);
			break;
		case 3: // or
			crypted_imm = imm & random_imm;
			crypted_imm2 = imm ^ crypted_imm;

			lines->add("%s = 0x%0.8X;\r\n", var_name, crypted_imm);
			lines->add("%s |= 0x%0.8X;\r\n", var_name, crypted_imm2);
			break;

	}
}


#endif