#ifndef __BASE64__
#define __BASE64__


PCHAR	base64_encode(PBYTE data, DWORD data_size);
PBYTE	base64_decode(PCHAR input, DWORD input_length);

#endif