#ifndef __M_PATH__
#define __M_PATH__

#include "funcs.h"
#include <Windows.h>

/////////////////////////////////////////////////////////////////////////////////////////////////
//	STRUCTURES
/////////////////////////////////////////////////////////////////////////////////////////////////
#pragma pack(push, 8)
typedef struct _APP_BASIC_PATHES
{
	WCHAR	wExeDir[0x100], wExePath[0x100];
	WCHAR	wWinDir[0x100], wSysDir[0x100];
	WCHAR	wTmpDir[0x100];
} APP_BASIC_PATHES, *PAPP_BASIC_PATHES;
#pragma pack(pop)

/////////////////////////////////////////////////////////////////////////////////////////////////
//	PROTO
/////////////////////////////////////////////////////////////////////////////////////////////////
BOOL _stdcall path_GetBasicPathes(PAPP_BASIC_PATHES OUT pPathes);

class mPathBuilder
{
	CHAR	tmp_folder[MAX_PATH];
	CHAR	exe_folder[MAX_PATH];

	DWORD	pid;
	DWORD64 rand_name;

public:
	mPathBuilder(DWORD pid, DWORD64 rand_name);

	PCHAR	get_tmp_folder(); 
	PCHAR	get_exe_folder();
	BOOL	create_tmp_folder();
	INT		remove_tmp_folder();
	void	add_file(PCHAR file_name, PVOID data, DWORD data_size);
	PMBUF	get_file(PCHAR file_name);
};

#endif