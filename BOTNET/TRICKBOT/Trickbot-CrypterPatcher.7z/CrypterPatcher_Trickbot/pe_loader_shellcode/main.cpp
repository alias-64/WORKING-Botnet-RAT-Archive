#include <Windows.h>
#include <tchar.h>
#include <intrin.h>
#include "load_pe.h"
#include "funcs.h"


#ifdef _DEBUG

/*
DWORD func2(PDWORD a)
{
	DWORD_PTR regs[r_all];
	mem_zero(regs,r_all*sizeof(DWORD_PTR));

	PDWORD_PTR Rsp = (PDWORD_PTR)_AddressOfReturnAddress();
	while( 1 )
	{
		Rsp = find_next_rsp(regs,Rsp);
	}

	return *a << 3;
}

DWORD func1(PDWORD a)
{
	*a *= 234;
	*a += 34;

	return func2(a);
}
*/

int WINAPI WinMain( __in HINSTANCE hInstance, __in_opt HINSTANCE hPrevInstance, __in_opt LPSTR lpCmdLine, __in int nShowCmd )
{


	return 0;
}

#endif