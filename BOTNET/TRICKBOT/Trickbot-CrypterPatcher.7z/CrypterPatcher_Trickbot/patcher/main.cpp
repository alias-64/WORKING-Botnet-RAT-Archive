#include <windows.h>
#include <tchar.h>
#include <intrin.h>
#include <stdio.h>

#include "../hitech_crypter/funcs.h"
#include "../hitech_crypter/base64.h"
#include "../hitech_crypter/mOutputPatcher.h"
#include "../hitech_crypter/mCode.h"

void hexdump(void *ptr, int buflen) {
	unsigned char *buf = (unsigned char*)ptr;
	int i, j;
	for (i=0; i<buflen; i+=16) {
		printf("%06x: ", i);
		for (j=0; j<16; j++) 
			if (i+j < buflen)
				printf("%02x ", buf[i+j]);
			else
				printf("   ");
		printf(" ");
		for (j=0; j<16; j++) 
			if (i+j < buflen)
				printf("%c", isprint(buf[i+j]) ? buf[i+j] : '.');
		printf("\n");
	}
}

void _tmain(int _Argc, PTCHAR argv[])
{
	if( _Argc < 2 )
	{
		_tprintf(_T("Usage: patcher.exe <file> <serialized_data_base64>\r\n"));
		return;
	}

	PTCHAR out_file = argv[1];
	PTCHAR patch_file = argv[2];

	_tprintf(_T("Output: %s\r\n"), out_file);
	_tprintf(_T("Patch data: %s\r\n"), patch_file);

	mOutputPatcher patch(out_file);

	PMBUF d = file_get_contents(patch_file);

	if( patch.unserialize((PCHAR)d->data, d->size) )
	{
		printf("Total markers: %d\r\n", patch.get_count());

		patch.patch_markers();
	}else{
		printf("Error: unserialize failed!\r\n");
	}
}