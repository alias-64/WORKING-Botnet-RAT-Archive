#pragma once
#include <stdio.h>
#include "vector.h"
#include "Zip.h"

void doIExplore(HZIP hZip, DWORD* dwCount);