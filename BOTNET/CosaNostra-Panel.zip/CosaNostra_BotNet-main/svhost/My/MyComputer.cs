﻿// Decompiled with JetBrains decompiler
// Type: svhost.My.MyComputer
// Assembly: svhost, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7DC793DB-CF4C-4ECD-BC3A-2E8425BD618A
// Assembly location: C:\Users\matze\Desktop\Neuer Ordner (7)\Builder\Builder\Resources\svhost.exe

using Microsoft.VisualBasic.Devices;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;

namespace svhost.My
{
  [GeneratedCode("MyTemplate", "11.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  internal class MyComputer : Computer
  {
    [EditorBrowsable(EditorBrowsableState.Never)]
    [DebuggerHidden]
    public MyComputer()
    {
    }
  }
}
