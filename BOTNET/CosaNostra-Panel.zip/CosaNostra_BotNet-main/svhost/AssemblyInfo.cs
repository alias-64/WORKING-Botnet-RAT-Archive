﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("")]
[assembly: AssemblyTitle("svshot")]
[assembly: AssemblyProduct("svshot")]
[assembly: AssemblyCopyright("Copyright ©  2021")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: Guid("56f6f78a-3619-4e04-a8e6-3169f5b310f8")]
[assembly: ComVisible(false)]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("1.0.0.0")]
