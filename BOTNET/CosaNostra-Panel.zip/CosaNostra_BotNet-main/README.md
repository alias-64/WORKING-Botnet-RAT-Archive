# CosaNostra_BotNet


<img src="https://i.ibb.co/Bn3vk36/Cosa-Nostra-v-1-Web-Panel.png" ><br>

<img src="https://i.ibb.co/9mD0CBH/Unbkknt.png" ><br>


