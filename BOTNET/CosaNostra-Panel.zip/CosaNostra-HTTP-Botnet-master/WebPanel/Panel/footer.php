              <!--  <nav class="navbar navbar-inverse navbar-fixed-bottom" style='border-radius:0px;background-color:#232323;opacity: 0.7'>

        
            <div class="container-fluid">
                <div class="navbar-header">
               <a class="navbar-brand" href="facebook.com/th3.dark.ly">Created by Ly_kermit</a>
                </div>
                
            </div>
        </nav>-->
	</body>
</html>	