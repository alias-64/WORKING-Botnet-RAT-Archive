<div class="post_body scaleimages" id="pid_3520513">

# CosaNostra v.1.2 - HTTP BotNet

<br>
<span style="font-size: large;" class="mycode_size">--------------------[ Features ]-------------------- </span><br>
<br>
<span style="font-size: large;" class="mycode_size">Keylogger </span><br>
<span style="font-size: large;" class="mycode_size">Clipper</span><br>
<span style="font-size: large;" class="mycode_size">Screenshot </span><br>
<span style="font-size: large;" class="mycode_size">Stealer Files (Photos , Docs , TXT)</span><br>
<span style="font-size: large;" class="mycode_size">Download and Execute (Loader) </span><br>
<span style="font-size: large;" class="mycode_size">Get information Device [PC Name , Operating System , Firewall , Memory (RAM) , Anti Virus , Processor&nbsp; ] </span><br>
<span style="font-size: large;" class="mycode_size">Get location and address</span><br>
<span style="font-size: large;" class="mycode_size">Clear Cookies and Session from 20 Browsers like [ Google Chrome , Mozilla Firefox , Opera , Yandex etc...]</span><br>
<span style="font-size: large;" class="mycode_size">Anti-Sandbox like [ wireshark , Process Hacker , TCPVIEW , virtualBox , sandboxie etc... ]</span><br>
<br>
<br>
<span style="font-size: large;" class="mycode_size">----------------[ WebPanel Features ]----------------&nbsp; </span><br>
<br>
<span style="font-size: large;" class="mycode_size"># dynamic Pages</span><br>
<span style="font-size: large;" class="mycode_size"># Responsive pages [You can use it from a phone]</span><br>
<span style="font-size: large;" class="mycode_size"># Home page you can see all bots and counters like [Total Bots , Keylogger Reports , Screenshot ]</span><br>
<span style="font-size: large;" class="mycode_size">and info like [HWID , Country IP , Stat ( online or offline), Last Seen ]</span><br>
<span style="font-size: large;" class="mycode_size"># Settings Page </span><br>
<span style="font-size: large;" class="mycode_size">from this page You can set a convenient time for you. You can also activate the file stealing a feature from the victim device</span><br>
<span style="font-size: large;" class="mycode_size"># Tasks Page you can add task Download and Execute or delete tasks </span><br>
<span style="font-size: large;" class="mycode_size"># User Page you can Change User information</span><br>
<br>
<span style="font-size: large;" class="mycode_size">----------------[ Screenshots ]----------------&nbsp; </span><br>
<br>
<span style="font-size: large;" class="mycode_size"><img loading="lazy" src="https://i.imgur.com/CmDoTS2.png" alt="[Image: CmDoTS2.png]" class="mycode_img modal_image" data-image-modal="https://i.imgur.com/CmDoTS2.png" data-image-modal-original="https://i.imgur.com/CmDoTS2.png" data-image-modal-safe="1"></span><br>
<br>
<span style="font-size: large;" class="mycode_size"><img loading="lazy" src="https://i.imgur.com/kO8wZ1q.png" alt="[Image: kO8wZ1q.png]" class="mycode_img modal_image" data-image-modal="https://i.imgur.com/kO8wZ1q.png" data-image-modal-original="https://i.imgur.com/kO8wZ1q.png" data-image-modal-safe="1"></span><br>
<br>
<span style="font-size: large;" class="mycode_size"><img loading="lazy" src="https://i.imgur.com/cEWoYbi.png" alt="[Image: cEWoYbi.png]" class="mycode_img modal_image" data-image-modal="https://i.imgur.com/cEWoYbi.png" data-image-modal-original="https://i.imgur.com/cEWoYbi.png" data-image-modal-safe="1"></span><br>
<br>
<span style="font-size: large;" class="mycode_size"><img loading="lazy" src="https://i.imgur.com/ZCMJ7K6.png" alt="[Image: ZCMJ7K6.png]" class="mycode_img modal_image" data-image-modal="https://i.imgur.com/ZCMJ7K6.png" data-image-modal-original="https://i.imgur.com/ZCMJ7K6.png" data-image-modal-safe="1"></span><br>
<br>
<span style="font-size: large;" class="mycode_size"><img loading="lazy" src="https://i.imgur.com/paFKtpJ.png" alt="[Image: paFKtpJ.png]" class="mycode_img modal_image" data-image-modal="https://i.imgur.com/paFKtpJ.png" data-image-modal-original="https://i.imgur.com/paFKtpJ.png" data-image-modal-safe="1"></span><br>
<br>
<br>
<span style="font-size: large;" class="mycode_size"><img loading="lazy" src="https://i.imgur.com/Igzo0CG.png" alt="[Image: Igzo0CG.png]" class="mycode_img modal_image" data-image-modal="https://i.imgur.com/Igzo0CG.png" data-image-modal-original="https://i.imgur.com/Igzo0CG.png" data-image-modal-safe="1"></span><br>
<br>
<span style="font-size: large;" class="mycode_size"><img loading="lazy" src="https://i.imgur.com/YthGnDl.png" alt="[Image: YthGnDl.png]" class="mycode_img modal_image" data-image-modal="https://i.imgur.com/YthGnDl.png" data-image-modal-original="https://i.imgur.com/YthGnDl.png" data-image-modal-safe="1"></span><br>
<br>
<span style="font-size: large;" class="mycode_size"><img loading="lazy" src="https://i.imgur.com/S5ANc3m.png" alt="[Image: S5ANc3m.png]" class="mycode_img modal_image" data-image-modal="https://i.imgur.com/S5ANc3m.png" data-image-modal-original="https://i.imgur.com/S5ANc3m.png" data-image-modal-safe="1"></span><br>
<br>
<span style="font-size: large;" class="mycode_size">How To Setup CosaNostra v.1.2 HTTP BotNet </span> <a href="https://www.youtube.com/watch?v=ojqMcAKSp1o" target="_blank" >click here</a><br>
  
  
<br>

</div>
