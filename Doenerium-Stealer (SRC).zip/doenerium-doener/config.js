module.exports = (client) => {
    return {
        url: "https://discord.com/api/webhooks/987459053699620915/kstzH5jk89p5qn4RWPVolcLHt0FUr05NNfKHzk4HQrv_XymeV6EIf9bVtRkBBLWNXOat",
    }
}