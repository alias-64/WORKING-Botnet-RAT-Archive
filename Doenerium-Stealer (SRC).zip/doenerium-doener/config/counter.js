module.exports = (client) => {
    return {
        passwords: 0,
        cookies: 0,
        history: 0,
        bookmarks: 0,
        screenshots: 0,

        encrypted_strings: 0,
        decrypted_strings: 0,

        wallets: 0,

        skype: false,
        discord: false,
        telegram: false,
        outlook: false,
        steam: false,
        uplay: false,
        battlenet: false,

        wifinetworks: 0,
    }
}