# NanoCore
NanoCore 1.0.3.0 RAT sample malware for research purposes.

It will be detected by your AV.

Dont file complaints.


