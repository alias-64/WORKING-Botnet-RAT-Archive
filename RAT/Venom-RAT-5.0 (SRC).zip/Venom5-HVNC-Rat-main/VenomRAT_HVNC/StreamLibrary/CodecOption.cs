namespace VenomRAT_HVNC.StreamLibrary
{
    public enum CodecOption
    {
        RequireSameSize,

        HasBuffers,

        AutoDispose,

        None
    }
}
