﻿namespace VenomRAT_HVNC.Quasar.Server
{
    internal class Helper
    {
        internal class AeroListView : global::VenomRAT_HVNC.Server.Helper.AeroListView
        {
        }
    }
}