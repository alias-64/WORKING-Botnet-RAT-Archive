using System.Windows.Forms;

namespace VenomRAT_HVNC.Server.Forms
{
    public partial class FormAbout : Form
    {
        public FormAbout()
        {
            this.InitializeComponent();
        }
    }
}
