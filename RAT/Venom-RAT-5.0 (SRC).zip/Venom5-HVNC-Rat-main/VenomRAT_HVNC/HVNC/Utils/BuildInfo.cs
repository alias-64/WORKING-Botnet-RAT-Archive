﻿namespace VenomRAT_HVNC.HVNC.Utils
{
    internal class BuildInfo
    {
        public static string ip { get; set; }

        public static string port { get; set; }

        public static string id { get; set; }

        public static string mutex { get; set; }

        public static string startup { get; set; }

        public static string path { get; set; }

        public static string folder { get; set; }

        public static string filename { get; set; }

        public static string wdex { get; set; }

        public static string hhvnc { get; set; }
    }
}