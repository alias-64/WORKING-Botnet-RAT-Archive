﻿using System;

namespace FxResources.System.Collections.Immutable
{
	// Token: 0x02000C8F RID: 3215
	internal static class SR
	{
	}
}
