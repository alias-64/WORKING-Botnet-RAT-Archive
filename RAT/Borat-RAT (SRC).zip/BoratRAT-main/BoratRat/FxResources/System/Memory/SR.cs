﻿using System;

namespace FxResources.System.Memory
{
	// Token: 0x02000CCD RID: 3277
	internal static class SR
	{
	}
}
