﻿using System;

namespace FxResources.System.Buffers
{
	// Token: 0x02000C84 RID: 3204
	internal static class SR
	{
	}
}
