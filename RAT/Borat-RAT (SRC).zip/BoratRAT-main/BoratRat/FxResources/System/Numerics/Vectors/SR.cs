﻿using System;

namespace FxResources.System.Numerics.Vectors
{
	// Token: 0x02000CFA RID: 3322
	internal static class SR
	{
	}
}
