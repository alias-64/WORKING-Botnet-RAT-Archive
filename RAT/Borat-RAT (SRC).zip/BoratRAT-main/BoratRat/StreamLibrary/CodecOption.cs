﻿using System;

namespace StreamLibrary
{
	// Token: 0x02000004 RID: 4
	public enum CodecOption
	{
		// Token: 0x04000005 RID: 5
		RequireSameSize,
		// Token: 0x04000006 RID: 6
		HasBuffers,
		// Token: 0x04000007 RID: 7
		AutoDispose,
		// Token: 0x04000008 RID: 8
		None
	}
}
