﻿using System;

// Token: 0x02000C11 RID: 3089
internal sealed class ThisAssembly
{
	// Token: 0x06007AED RID: 31469 RVA: 0x002447D4 File Offset: 0x002447D4
	private ThisAssembly()
	{
	}

	// Token: 0x04003B3B RID: 15163
	internal const string AssemblyVersion = "2.4.0.0";

	// Token: 0x04003B3C RID: 15164
	internal const string AssemblyFileVersion = "2.4.6.0";

	// Token: 0x04003B3D RID: 15165
	internal const string AssemblyInformationalVersion = "2.4.6+g43df102394";

	// Token: 0x04003B3E RID: 15166
	internal const string AssemblyName = "protobuf-net";

	// Token: 0x04003B3F RID: 15167
	internal const string AssemblyTitle = "protobuf-net";

	// Token: 0x04003B40 RID: 15168
	internal const string AssemblyConfiguration = "Release";

	// Token: 0x04003B41 RID: 15169
	internal const string PublicKey = "002400000480000094000000060200000024000052534131000400000100010009ed9caa457bfc205716c3d4e8b255a63ddf71c9e53b1b5f574ab6ffdba11e80ab4b50be9c46d43b75206280070ddba67bd4c830f93f0317504a76ba6a48243c36d2590695991164592767a7bbc4453b34694e31e20815a096e4483605139a32a76ec2fef196507487329c12047bf6a68bca8ee9354155f4d01daf6eec5ff6bc";

	// Token: 0x04003B42 RID: 15170
	internal const string PublicKeyToken = "257b51d87d2e4d67";

	// Token: 0x04003B43 RID: 15171
	internal const string RootNamespace = "ProtoBuf";
}
