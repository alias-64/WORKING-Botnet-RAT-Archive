﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using DarkUI.Forms;
using Server.Properties;

namespace Server.Forms
{
	// Token: 0x02000056 RID: 86
	public partial class FormAbout : DarkForm
	{
		// Token: 0x0600033D RID: 829 RVA: 0x0001B758 File Offset: 0x0001B758
		public FormAbout()
		{
			this.InitializeComponent();
		}
	}
}
