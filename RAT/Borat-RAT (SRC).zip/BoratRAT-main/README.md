# BoratRAT
Shame on you(both sides)

So...What's the hype around Borat Rat!? 
It's damn DcRat! 
Malware hunter/analyst idiots should do their research before posting garbage 
instead of compete who will copy/paste faster or simply get a normal life cause clearly this isn't proffesion for you. 
Some people actually rely on your trash posts! 
// 
For other side(1x37x), just....DUDE!? 
You do know that you do more harm than benefit with things like this?? 
Especially when you skid public thing leave proper credits at least...

![1](https://user-images.githubusercontent.com/1867768/162823339-ecdf9a4f-3408-4b10-b0ca-a57d3b11865d.jpg)
![2](https://user-images.githubusercontent.com/1867768/162823341-da94378a-731a-47c5-bbce-c925caebf688.jpg)
![3](https://user-images.githubusercontent.com/1867768/162823342-79bb359d-bf49-4539-bbca-10e9150b5d1b.jpg)
![4](https://user-images.githubusercontent.com/1867768/162823343-78d0b325-ab40-4f0b-8a79-e7c14efc283a.jpg)
![5](https://user-images.githubusercontent.com/1867768/162823347-f1f6fb9f-2f91-4b20-9325-01eedc85aaa4.jpg)
![6](https://user-images.githubusercontent.com/1867768/162823349-c2232239-eed0-4882-b9d8-980967835ce2.jpg)
![7](https://user-images.githubusercontent.com/1867768/162823351-704f642d-53d1-4af6-abf8-cd8e7c810cf8.jpg)
