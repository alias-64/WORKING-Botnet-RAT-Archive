﻿namespace stub
{
    public enum CommandType : byte
	{
		BaseCommand,
		PluginCommand,
		FileCommand
	}
}