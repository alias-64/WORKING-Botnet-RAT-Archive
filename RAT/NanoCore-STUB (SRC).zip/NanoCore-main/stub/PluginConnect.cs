﻿using System;

namespace stub
{
	class PluginConnect
	{
		public PluginConnect(Guid guid, string string_0, Plugin plugin)
		{
			this.Guid = guid;
			this.string_0 = string_0;
			this.Plugin = plugin;
		}

		public Guid Guid;
		public string string_0;
		public Plugin Plugin;
	}
}