# NanoCore
NanoCore stub source code
![Screenshot](Capture.gif)

# basic
vs2019 + net2.0 + c#

# usage
stub.exe host port
