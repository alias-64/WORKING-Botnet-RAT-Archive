﻿namespace Server
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.listView1 = new System.Windows.Forms.ListView();
            this.lv_ip = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_country = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_group = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_hwid = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_user = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_os = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_version = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_ins = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_admin = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_av = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_ping = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_act = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuClient = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.aBOUTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.sENDFILEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tOMEMORYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tODISKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.monitoringToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.remoteDesktopToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.keyloggerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.passwordRecoveryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fileManagerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.processManagerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.reportWindowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.stopToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.webcamToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miscellaneousToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.botsKillerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uSBSpreadToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.seedTorrentToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.remoteShellToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.dOSAttackToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.executeNETCodeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xMRMinerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.killToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filesSearcherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.extraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visitWebsiteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sendMessageBoxToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.chatToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.getAdminPrivilegesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blankScreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.stopToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.disableWindowsDefenderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setWallpaperToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.systemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.serverToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blockClientsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.bUILDERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.ping = new System.Windows.Forms.Timer(this.components);
            this.UpdateUI = new System.Windows.Forms.Timer(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuLogs = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cLEARToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.listView3 = new System.Windows.Forms.ListView();
            this.contextMenuThumbnail = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.sTARTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sTOPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ThumbnailImageList = new System.Windows.Forms.ImageList(this.components);
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.listView4 = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuTasks = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.pASSWORDRECOVERYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.downloadAndExecuteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sENDFILETOMEMORYToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.minerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.uPDATEToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.dELETETASKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.performanceCounter1 = new System.Diagnostics.PerformanceCounter();
            this.performanceCounter2 = new System.Diagnostics.PerformanceCounter();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.TimerTask = new System.Windows.Forms.Timer(this.components);
            this.shutdownToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.restartToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.logoffToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.restartToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.updateToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.uninstallToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.showFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clientToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuClient.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.contextMenuLogs.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.contextMenuThumbnail.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.contextMenuTasks.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter2)).BeginInit();
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lv_ip,
            this.lv_country,
            this.lv_group,
            this.lv_hwid,
            this.lv_user,
            this.lv_os,
            this.lv_version,
            this.lv_ins,
            this.lv_admin,
            this.lv_av,
            this.lv_ping,
            this.lv_act});
            this.listView1.ContextMenuStrip = this.contextMenuClient;
            this.listView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(3, 3);
            this.listView1.Name = "listView1";
            this.listView1.ShowGroups = false;
            this.listView1.ShowItemToolTips = true;
            this.listView1.Size = new System.Drawing.Size(1287, 440);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.ListView1_ColumnClick);
            this.listView1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.listView1_KeyDown);
            this.listView1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseMove);
            // 
            // lv_ip
            // 
            this.lv_ip.Text = "IP Address";
            this.lv_ip.Width = 121;
            // 
            // lv_country
            // 
            this.lv_country.Text = "Country";
            this.lv_country.Width = 124;
            // 
            // lv_group
            // 
            this.lv_group.Text = "Group";
            this.lv_group.Width = 110;
            // 
            // lv_hwid
            // 
            this.lv_hwid.Text = "HWID";
            this.lv_hwid.Width = 117;
            // 
            // lv_user
            // 
            this.lv_user.Text = "Username";
            this.lv_user.Width = 117;
            // 
            // lv_os
            // 
            this.lv_os.Text = "Operating System";
            this.lv_os.Width = 179;
            // 
            // lv_version
            // 
            this.lv_version.Text = "Payload Version";
            this.lv_version.Width = 126;
            // 
            // lv_ins
            // 
            this.lv_ins.Text = "Installed";
            this.lv_ins.Width = 120;
            // 
            // lv_admin
            // 
            this.lv_admin.Text = "Privileges";
            this.lv_admin.Width = 166;
            // 
            // lv_av
            // 
            this.lv_av.Text = "Anti-Virus Software";
            this.lv_av.Width = 136;
            // 
            // lv_ping
            // 
            this.lv_ping.Text = "Ping";
            // 
            // lv_act
            // 
            this.lv_act.Text = "Active Window";
            this.lv_act.Width = 350;
            // 
            // contextMenuClient
            // 
            this.contextMenuClient.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuClient.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aBOUTToolStripMenuItem,
            this.toolStripSeparator2,
            this.sENDFILEToolStripMenuItem,
            this.monitoringToolStripMenuItem,
            this.miscellaneousToolStripMenuItem,
            this.extraToolStripMenuItem,
            this.systemToolStripMenuItem,
            this.toolStripSeparator1,
            this.serverToolStripMenuItem,
            this.toolStripSeparator5,
            this.bUILDERToolStripMenuItem});
            this.contextMenuClient.Name = "contextMenuStrip1";
            this.contextMenuClient.Size = new System.Drawing.Size(238, 278);
            // 
            // aBOUTToolStripMenuItem
            // 
            this.aBOUTToolStripMenuItem.Image = global::Server.Properties.Resources.info;
            this.aBOUTToolStripMenuItem.Name = "aBOUTToolStripMenuItem";
            this.aBOUTToolStripMenuItem.Size = new System.Drawing.Size(202, 32);
            this.aBOUTToolStripMenuItem.Text = "ABOUT";
            this.aBOUTToolStripMenuItem.Click += new System.EventHandler(this.ABOUTToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(199, 6);
            // 
            // sENDFILEToolStripMenuItem
            // 
            this.sENDFILEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tOMEMORYToolStripMenuItem,
            this.tODISKToolStripMenuItem});
            this.sENDFILEToolStripMenuItem.Image = global::Server.Properties.Resources.tomem;
            this.sENDFILEToolStripMenuItem.Name = "sENDFILEToolStripMenuItem";
            this.sENDFILEToolStripMenuItem.Size = new System.Drawing.Size(202, 32);
            this.sENDFILEToolStripMenuItem.Text = "Send File";
            // 
            // tOMEMORYToolStripMenuItem
            // 
            this.tOMEMORYToolStripMenuItem.Image = global::Server.Properties.Resources.tomem1;
            this.tOMEMORYToolStripMenuItem.Name = "tOMEMORYToolStripMenuItem";
            this.tOMEMORYToolStripMenuItem.Size = new System.Drawing.Size(206, 34);
            this.tOMEMORYToolStripMenuItem.Text = "To Memory";
            this.tOMEMORYToolStripMenuItem.Click += new System.EventHandler(this.TOMEMORYToolStripMenuItem_Click);
            // 
            // tODISKToolStripMenuItem
            // 
            this.tODISKToolStripMenuItem.Image = global::Server.Properties.Resources.tomem1;
            this.tODISKToolStripMenuItem.Name = "tODISKToolStripMenuItem";
            this.tODISKToolStripMenuItem.Size = new System.Drawing.Size(206, 34);
            this.tODISKToolStripMenuItem.Text = "To Disk";
            this.tODISKToolStripMenuItem.Click += new System.EventHandler(this.TODISKToolStripMenuItem_Click);
            // 
            // monitoringToolStripMenuItem
            // 
            this.monitoringToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.remoteDesktopToolStripMenuItem1,
            this.keyloggerToolStripMenuItem1,
            this.passwordRecoveryToolStripMenuItem1,
            this.fileManagerToolStripMenuItem1,
            this.processManagerToolStripMenuItem1,
            this.reportWindowToolStripMenuItem,
            this.webcamToolStripMenuItem});
            this.monitoringToolStripMenuItem.Image = global::Server.Properties.Resources.monitoring_system;
            this.monitoringToolStripMenuItem.Name = "monitoringToolStripMenuItem";
            this.monitoringToolStripMenuItem.Size = new System.Drawing.Size(202, 32);
            this.monitoringToolStripMenuItem.Text = "Monitoring";
            // 
            // remoteDesktopToolStripMenuItem1
            // 
            this.remoteDesktopToolStripMenuItem1.Image = global::Server.Properties.Resources.remotedesktop;
            this.remoteDesktopToolStripMenuItem1.Name = "remoteDesktopToolStripMenuItem1";
            this.remoteDesktopToolStripMenuItem1.Size = new System.Drawing.Size(267, 34);
            this.remoteDesktopToolStripMenuItem1.Text = "Remote Desktop";
            this.remoteDesktopToolStripMenuItem1.Click += new System.EventHandler(this.RemoteDesktopToolStripMenuItem1_Click);
            // 
            // keyloggerToolStripMenuItem1
            // 
            this.keyloggerToolStripMenuItem1.Image = global::Server.Properties.Resources.logger;
            this.keyloggerToolStripMenuItem1.Name = "keyloggerToolStripMenuItem1";
            this.keyloggerToolStripMenuItem1.Size = new System.Drawing.Size(267, 34);
            this.keyloggerToolStripMenuItem1.Text = "Keylogger";
            this.keyloggerToolStripMenuItem1.Click += new System.EventHandler(this.KeyloggerToolStripMenuItem1_Click);
            // 
            // passwordRecoveryToolStripMenuItem1
            // 
            this.passwordRecoveryToolStripMenuItem1.Image = global::Server.Properties.Resources.key;
            this.passwordRecoveryToolStripMenuItem1.Name = "passwordRecoveryToolStripMenuItem1";
            this.passwordRecoveryToolStripMenuItem1.Size = new System.Drawing.Size(267, 34);
            this.passwordRecoveryToolStripMenuItem1.Text = "Password Recovery";
            this.passwordRecoveryToolStripMenuItem1.Click += new System.EventHandler(this.PasswordRecoveryToolStripMenuItem1_Click);
            // 
            // fileManagerToolStripMenuItem1
            // 
            this.fileManagerToolStripMenuItem1.Image = global::Server.Properties.Resources.filemanager;
            this.fileManagerToolStripMenuItem1.Name = "fileManagerToolStripMenuItem1";
            this.fileManagerToolStripMenuItem1.Size = new System.Drawing.Size(267, 34);
            this.fileManagerToolStripMenuItem1.Text = "File Manager";
            this.fileManagerToolStripMenuItem1.Click += new System.EventHandler(this.FileManagerToolStripMenuItem1_Click);
            // 
            // processManagerToolStripMenuItem1
            // 
            this.processManagerToolStripMenuItem1.Image = global::Server.Properties.Resources.process;
            this.processManagerToolStripMenuItem1.Name = "processManagerToolStripMenuItem1";
            this.processManagerToolStripMenuItem1.Size = new System.Drawing.Size(267, 34);
            this.processManagerToolStripMenuItem1.Text = "Process Manager";
            this.processManagerToolStripMenuItem1.Click += new System.EventHandler(this.ProcessManagerToolStripMenuItem1_Click);
            // 
            // reportWindowToolStripMenuItem
            // 
            this.reportWindowToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.runToolStripMenuItem1,
            this.stopToolStripMenuItem2});
            this.reportWindowToolStripMenuItem.Image = global::Server.Properties.Resources.report;
            this.reportWindowToolStripMenuItem.Name = "reportWindowToolStripMenuItem";
            this.reportWindowToolStripMenuItem.Size = new System.Drawing.Size(267, 34);
            this.reportWindowToolStripMenuItem.Text = "Report Window";
            // 
            // runToolStripMenuItem1
            // 
            this.runToolStripMenuItem1.Name = "runToolStripMenuItem1";
            this.runToolStripMenuItem1.Size = new System.Drawing.Size(152, 34);
            this.runToolStripMenuItem1.Text = "Run";
            this.runToolStripMenuItem1.Click += new System.EventHandler(this.RunToolStripMenuItem1_Click);
            // 
            // stopToolStripMenuItem2
            // 
            this.stopToolStripMenuItem2.Name = "stopToolStripMenuItem2";
            this.stopToolStripMenuItem2.Size = new System.Drawing.Size(152, 34);
            this.stopToolStripMenuItem2.Text = "Stop";
            this.stopToolStripMenuItem2.Click += new System.EventHandler(this.StopToolStripMenuItem2_Click);
            // 
            // webcamToolStripMenuItem
            // 
            this.webcamToolStripMenuItem.Image = global::Server.Properties.Resources.webcam;
            this.webcamToolStripMenuItem.Name = "webcamToolStripMenuItem";
            this.webcamToolStripMenuItem.Size = new System.Drawing.Size(267, 34);
            this.webcamToolStripMenuItem.Text = "Webcam";
            this.webcamToolStripMenuItem.Click += new System.EventHandler(this.WebcamToolStripMenuItem_Click);
            // 
            // miscellaneousToolStripMenuItem
            // 
            this.miscellaneousToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.botsKillerToolStripMenuItem,
            this.uSBSpreadToolStripMenuItem1,
            this.seedTorrentToolStripMenuItem1,
            this.remoteShellToolStripMenuItem1,
            this.dOSAttackToolStripMenuItem,
            this.executeNETCodeToolStripMenuItem,
            this.xMRMinerToolStripMenuItem,
            this.filesSearcherToolStripMenuItem});
            this.miscellaneousToolStripMenuItem.Image = global::Server.Properties.Resources.Miscellaneous;
            this.miscellaneousToolStripMenuItem.Name = "miscellaneousToolStripMenuItem";
            this.miscellaneousToolStripMenuItem.Size = new System.Drawing.Size(202, 32);
            this.miscellaneousToolStripMenuItem.Text = "Miscellaneous";
            // 
            // botsKillerToolStripMenuItem
            // 
            this.botsKillerToolStripMenuItem.Image = global::Server.Properties.Resources.botkiller;
            this.botsKillerToolStripMenuItem.Name = "botsKillerToolStripMenuItem";
            this.botsKillerToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.botsKillerToolStripMenuItem.Text = "Bots Killer";
            this.botsKillerToolStripMenuItem.Click += new System.EventHandler(this.BotsKillerToolStripMenuItem_Click);
            // 
            // uSBSpreadToolStripMenuItem1
            // 
            this.uSBSpreadToolStripMenuItem1.Image = global::Server.Properties.Resources.usb;
            this.uSBSpreadToolStripMenuItem1.Name = "uSBSpreadToolStripMenuItem1";
            this.uSBSpreadToolStripMenuItem1.Size = new System.Drawing.Size(270, 34);
            this.uSBSpreadToolStripMenuItem1.Text = "USB Spread";
            this.uSBSpreadToolStripMenuItem1.Click += new System.EventHandler(this.USBSpreadToolStripMenuItem1_Click);
            // 
            // seedTorrentToolStripMenuItem1
            // 
            this.seedTorrentToolStripMenuItem1.Image = global::Server.Properties.Resources.u_torrent_logo;
            this.seedTorrentToolStripMenuItem1.Name = "seedTorrentToolStripMenuItem1";
            this.seedTorrentToolStripMenuItem1.Size = new System.Drawing.Size(270, 34);
            this.seedTorrentToolStripMenuItem1.Text = "Seed Torrent";
            this.seedTorrentToolStripMenuItem1.Click += new System.EventHandler(this.SeedTorrentToolStripMenuItem1_Click_1);
            // 
            // remoteShellToolStripMenuItem1
            // 
            this.remoteShellToolStripMenuItem1.Image = global::Server.Properties.Resources.shell;
            this.remoteShellToolStripMenuItem1.Name = "remoteShellToolStripMenuItem1";
            this.remoteShellToolStripMenuItem1.Size = new System.Drawing.Size(270, 34);
            this.remoteShellToolStripMenuItem1.Text = "Remote Shell";
            this.remoteShellToolStripMenuItem1.Click += new System.EventHandler(this.RemoteShellToolStripMenuItem1_Click_1);
            // 
            // dOSAttackToolStripMenuItem
            // 
            this.dOSAttackToolStripMenuItem.Image = global::Server.Properties.Resources.ddos;
            this.dOSAttackToolStripMenuItem.Name = "dOSAttackToolStripMenuItem";
            this.dOSAttackToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.dOSAttackToolStripMenuItem.Text = "DOS Attack";
            this.dOSAttackToolStripMenuItem.Click += new System.EventHandler(this.DOSAttackToolStripMenuItem_Click_1);
            // 
            // executeNETCodeToolStripMenuItem
            // 
            this.executeNETCodeToolStripMenuItem.Image = global::Server.Properties.Resources.coding;
            this.executeNETCodeToolStripMenuItem.Name = "executeNETCodeToolStripMenuItem";
            this.executeNETCodeToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.executeNETCodeToolStripMenuItem.Text = "Execute .NET Code";
            this.executeNETCodeToolStripMenuItem.Click += new System.EventHandler(this.ExecuteNETCodeToolStripMenuItem_Click_1);
            // 
            // xMRMinerToolStripMenuItem
            // 
            this.xMRMinerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.runToolStripMenuItem,
            this.killToolStripMenuItem});
            this.xMRMinerToolStripMenuItem.Image = global::Server.Properties.Resources.xmr;
            this.xMRMinerToolStripMenuItem.Name = "xMRMinerToolStripMenuItem";
            this.xMRMinerToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.xMRMinerToolStripMenuItem.Text = "XMR Miner";
            this.xMRMinerToolStripMenuItem.Visible = false;
            // 
            // runToolStripMenuItem
            // 
            this.runToolStripMenuItem.Image = global::Server.Properties.Resources.play_button;
            this.runToolStripMenuItem.Name = "runToolStripMenuItem";
            this.runToolStripMenuItem.Size = new System.Drawing.Size(152, 34);
            this.runToolStripMenuItem.Text = "Run";
            this.runToolStripMenuItem.Click += new System.EventHandler(this.RunToolStripMenuItem_Click);
            // 
            // killToolStripMenuItem
            // 
            this.killToolStripMenuItem.Image = global::Server.Properties.Resources.stop__1_;
            this.killToolStripMenuItem.Name = "killToolStripMenuItem";
            this.killToolStripMenuItem.Size = new System.Drawing.Size(152, 34);
            this.killToolStripMenuItem.Text = "Stop";
            this.killToolStripMenuItem.Click += new System.EventHandler(this.KillToolStripMenuItem_Click);
            // 
            // filesSearcherToolStripMenuItem
            // 
            this.filesSearcherToolStripMenuItem.Image = global::Server.Properties.Resources.report;
            this.filesSearcherToolStripMenuItem.Name = "filesSearcherToolStripMenuItem";
            this.filesSearcherToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.filesSearcherToolStripMenuItem.Text = "Files Searcher";
            this.filesSearcherToolStripMenuItem.Click += new System.EventHandler(this.filesSearcherToolStripMenuItem_Click);
            // 
            // extraToolStripMenuItem
            // 
            this.extraToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.visitWebsiteToolStripMenuItem1,
            this.sendMessageBoxToolStripMenuItem1,
            this.chatToolStripMenuItem1,
            this.getAdminPrivilegesToolStripMenuItem,
            this.blankScreenToolStripMenuItem,
            this.disableWindowsDefenderToolStripMenuItem,
            this.setWallpaperToolStripMenuItem});
            this.extraToolStripMenuItem.Image = global::Server.Properties.Resources.extra;
            this.extraToolStripMenuItem.Name = "extraToolStripMenuItem";
            this.extraToolStripMenuItem.Size = new System.Drawing.Size(202, 32);
            this.extraToolStripMenuItem.Text = "Extra";
            // 
            // visitWebsiteToolStripMenuItem1
            // 
            this.visitWebsiteToolStripMenuItem1.Image = global::Server.Properties.Resources.visit;
            this.visitWebsiteToolStripMenuItem1.Name = "visitWebsiteToolStripMenuItem1";
            this.visitWebsiteToolStripMenuItem1.Size = new System.Drawing.Size(329, 34);
            this.visitWebsiteToolStripMenuItem1.Text = "Visit Website";
            this.visitWebsiteToolStripMenuItem1.Click += new System.EventHandler(this.VisitWebsiteToolStripMenuItem1_Click);
            // 
            // sendMessageBoxToolStripMenuItem1
            // 
            this.sendMessageBoxToolStripMenuItem1.Image = global::Server.Properties.Resources.msgbox;
            this.sendMessageBoxToolStripMenuItem1.Name = "sendMessageBoxToolStripMenuItem1";
            this.sendMessageBoxToolStripMenuItem1.Size = new System.Drawing.Size(329, 34);
            this.sendMessageBoxToolStripMenuItem1.Text = "Send MessageBox";
            this.sendMessageBoxToolStripMenuItem1.Click += new System.EventHandler(this.SendMessageBoxToolStripMenuItem1_Click);
            // 
            // chatToolStripMenuItem1
            // 
            this.chatToolStripMenuItem1.Image = global::Server.Properties.Resources.chat;
            this.chatToolStripMenuItem1.Name = "chatToolStripMenuItem1";
            this.chatToolStripMenuItem1.Size = new System.Drawing.Size(329, 34);
            this.chatToolStripMenuItem1.Text = "Chat";
            this.chatToolStripMenuItem1.Click += new System.EventHandler(this.ChatToolStripMenuItem1_Click);
            // 
            // getAdminPrivilegesToolStripMenuItem
            // 
            this.getAdminPrivilegesToolStripMenuItem.Image = global::Server.Properties.Resources.uac;
            this.getAdminPrivilegesToolStripMenuItem.Name = "getAdminPrivilegesToolStripMenuItem";
            this.getAdminPrivilegesToolStripMenuItem.Size = new System.Drawing.Size(329, 34);
            this.getAdminPrivilegesToolStripMenuItem.Text = "Get Admin Privileges";
            this.getAdminPrivilegesToolStripMenuItem.Click += new System.EventHandler(this.GetAdminPrivilegesToolStripMenuItem_Click_1);
            // 
            // blankScreenToolStripMenuItem
            // 
            this.blankScreenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.runToolStripMenuItem2,
            this.stopToolStripMenuItem1});
            this.blankScreenToolStripMenuItem.Image = global::Server.Properties.Resources.blank_screen;
            this.blankScreenToolStripMenuItem.Name = "blankScreenToolStripMenuItem";
            this.blankScreenToolStripMenuItem.Size = new System.Drawing.Size(329, 34);
            this.blankScreenToolStripMenuItem.Text = "Blank Screen";
            // 
            // runToolStripMenuItem2
            // 
            this.runToolStripMenuItem2.Image = global::Server.Properties.Resources.play_button;
            this.runToolStripMenuItem2.Name = "runToolStripMenuItem2";
            this.runToolStripMenuItem2.Size = new System.Drawing.Size(152, 34);
            this.runToolStripMenuItem2.Text = "Run";
            this.runToolStripMenuItem2.Click += new System.EventHandler(this.RunToolStripMenuItem2_Click);
            // 
            // stopToolStripMenuItem1
            // 
            this.stopToolStripMenuItem1.Image = global::Server.Properties.Resources.stop__1_;
            this.stopToolStripMenuItem1.Name = "stopToolStripMenuItem1";
            this.stopToolStripMenuItem1.Size = new System.Drawing.Size(152, 34);
            this.stopToolStripMenuItem1.Text = "Stop";
            this.stopToolStripMenuItem1.Click += new System.EventHandler(this.StopToolStripMenuItem1_Click);
            // 
            // disableWindowsDefenderToolStripMenuItem
            // 
            this.disableWindowsDefenderToolStripMenuItem.Image = global::Server.Properties.Resources.disabled;
            this.disableWindowsDefenderToolStripMenuItem.Name = "disableWindowsDefenderToolStripMenuItem";
            this.disableWindowsDefenderToolStripMenuItem.Size = new System.Drawing.Size(329, 34);
            this.disableWindowsDefenderToolStripMenuItem.Text = "Disable Windows Defender";
            this.disableWindowsDefenderToolStripMenuItem.Click += new System.EventHandler(this.DisableWindowsDefenderToolStripMenuItem_Click_1);
            // 
            // setWallpaperToolStripMenuItem
            // 
            this.setWallpaperToolStripMenuItem.Image = global::Server.Properties.Resources.iconfinder_32_171485__1_;
            this.setWallpaperToolStripMenuItem.Name = "setWallpaperToolStripMenuItem";
            this.setWallpaperToolStripMenuItem.Size = new System.Drawing.Size(329, 34);
            this.setWallpaperToolStripMenuItem.Text = "Set Wallpaper";
            this.setWallpaperToolStripMenuItem.Click += new System.EventHandler(this.setWallpaperToolStripMenuItem_Click);
            // 
            // systemToolStripMenuItem
            // 
            this.systemToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clientToolStripMenuItem,
            this.pCToolStripMenuItem});
            this.systemToolStripMenuItem.Image = global::Server.Properties.Resources.system;
            this.systemToolStripMenuItem.Name = "systemToolStripMenuItem";
            this.systemToolStripMenuItem.Size = new System.Drawing.Size(237, 32);
            this.systemToolStripMenuItem.Text = "Client Managment";
            // 
            // pCToolStripMenuItem
            // 
            this.pCToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logoffToolStripMenuItem1,
            this.restartToolStripMenuItem3,
            this.shutdownToolStripMenuItem1});
            this.pCToolStripMenuItem.Image = global::Server.Properties.Resources.pc;
            this.pCToolStripMenuItem.Name = "pCToolStripMenuItem";
            this.pCToolStripMenuItem.Size = new System.Drawing.Size(158, 34);
            this.pCToolStripMenuItem.Text = "PC";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(199, 6);
            // 
            // serverToolStripMenuItem
            // 
            this.serverToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.blockClientsToolStripMenuItem});
            this.serverToolStripMenuItem.Image = global::Server.Properties.Resources.server;
            this.serverToolStripMenuItem.Name = "serverToolStripMenuItem";
            this.serverToolStripMenuItem.Size = new System.Drawing.Size(202, 32);
            this.serverToolStripMenuItem.Text = "Server";
            // 
            // blockClientsToolStripMenuItem
            // 
            this.blockClientsToolStripMenuItem.Image = global::Server.Properties.Resources.disabled;
            this.blockClientsToolStripMenuItem.Name = "blockClientsToolStripMenuItem";
            this.blockClientsToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.blockClientsToolStripMenuItem.Text = "Block Clients";
            this.blockClientsToolStripMenuItem.Click += new System.EventHandler(this.BlockClientsToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(199, 6);
            // 
            // bUILDERToolStripMenuItem
            // 
            this.bUILDERToolStripMenuItem.Image = global::Server.Properties.Resources.builder;
            this.bUILDERToolStripMenuItem.Name = "bUILDERToolStripMenuItem";
            this.bUILDERToolStripMenuItem.Size = new System.Drawing.Size(202, 32);
            this.bUILDERToolStripMenuItem.Text = "BUILDER";
            this.bUILDERToolStripMenuItem.Click += new System.EventHandler(this.bUILDERToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 479);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1301, 32);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(179, 25);
            this.toolStripStatusLabel2.Text = "[Notification]             ";
            this.toolStripStatusLabel2.Click += new System.EventHandler(this.ToolStripStatusLabel2_Click);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(24, 25);
            this.toolStripStatusLabel1.Text = "...";
            // 
            // ping
            // 
            this.ping.Enabled = true;
            this.ping.Interval = 30000;
            this.ping.Tick += new System.EventHandler(this.ping_Tick);
            // 
            // UpdateUI
            // 
            this.UpdateUI.Enabled = true;
            this.UpdateUI.Interval = 500;
            this.UpdateUI.Tick += new System.EventHandler(this.UpdateUI_Tick);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1301, 479);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.listView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1293, 446);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Clients";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.listView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1293, 446);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Logs";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // listView2
            // 
            this.listView2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.listView2.ContextMenuStrip = this.contextMenuLogs;
            this.listView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView2.FullRowSelect = true;
            this.listView2.GridLines = true;
            this.listView2.HideSelection = false;
            this.listView2.Location = new System.Drawing.Point(3, 3);
            this.listView2.Name = "listView2";
            this.listView2.ShowGroups = false;
            this.listView2.ShowItemToolTips = true;
            this.listView2.Size = new System.Drawing.Size(1287, 440);
            this.listView2.TabIndex = 1;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Time";
            this.columnHeader1.Width = 150;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Message";
            this.columnHeader2.Width = 1078;
            // 
            // contextMenuLogs
            // 
            this.contextMenuLogs.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuLogs.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cLEARToolStripMenuItem});
            this.contextMenuLogs.Name = "contextMenuLogs";
            this.contextMenuLogs.ShowImageMargin = false;
            this.contextMenuLogs.Size = new System.Drawing.Size(111, 36);
            // 
            // cLEARToolStripMenuItem
            // 
            this.cLEARToolStripMenuItem.Name = "cLEARToolStripMenuItem";
            this.cLEARToolStripMenuItem.Size = new System.Drawing.Size(110, 32);
            this.cLEARToolStripMenuItem.Text = "CLEAR";
            this.cLEARToolStripMenuItem.Click += new System.EventHandler(this.CLEARToolStripMenuItem_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.listView3);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1293, 446);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Thumbnail";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // listView3
            // 
            this.listView3.ContextMenuStrip = this.contextMenuThumbnail;
            this.listView3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView3.HideSelection = false;
            this.listView3.LargeImageList = this.ThumbnailImageList;
            this.listView3.Location = new System.Drawing.Point(0, 0);
            this.listView3.Name = "listView3";
            this.listView3.ShowItemToolTips = true;
            this.listView3.Size = new System.Drawing.Size(1293, 446);
            this.listView3.SmallImageList = this.ThumbnailImageList;
            this.listView3.TabIndex = 0;
            this.listView3.UseCompatibleStateImageBehavior = false;
            // 
            // contextMenuThumbnail
            // 
            this.contextMenuThumbnail.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuThumbnail.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sTARTToolStripMenuItem,
            this.sTOPToolStripMenuItem});
            this.contextMenuThumbnail.Name = "contextMenuStrip2";
            this.contextMenuThumbnail.Size = new System.Drawing.Size(144, 68);
            // 
            // sTARTToolStripMenuItem
            // 
            this.sTARTToolStripMenuItem.Image = global::Server.Properties.Resources.play_button;
            this.sTARTToolStripMenuItem.Name = "sTARTToolStripMenuItem";
            this.sTARTToolStripMenuItem.Size = new System.Drawing.Size(143, 32);
            this.sTARTToolStripMenuItem.Text = "START";
            this.sTARTToolStripMenuItem.Click += new System.EventHandler(this.STARTToolStripMenuItem_Click);
            // 
            // sTOPToolStripMenuItem
            // 
            this.sTOPToolStripMenuItem.Image = global::Server.Properties.Resources.stop__1_;
            this.sTOPToolStripMenuItem.Name = "sTOPToolStripMenuItem";
            this.sTOPToolStripMenuItem.Size = new System.Drawing.Size(143, 32);
            this.sTOPToolStripMenuItem.Text = "STOP";
            this.sTOPToolStripMenuItem.Click += new System.EventHandler(this.STOPToolStripMenuItem_Click);
            // 
            // ThumbnailImageList
            // 
            this.ThumbnailImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth16Bit;
            this.ThumbnailImageList.ImageSize = new System.Drawing.Size(256, 256);
            this.ThumbnailImageList.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.listView4);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1293, 446);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Tasks";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // listView4
            // 
            this.listView4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView4.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader5});
            this.listView4.ContextMenuStrip = this.contextMenuTasks;
            this.listView4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView4.FullRowSelect = true;
            this.listView4.HideSelection = false;
            this.listView4.Location = new System.Drawing.Point(3, 3);
            this.listView4.Name = "listView4";
            this.listView4.Size = new System.Drawing.Size(1287, 440);
            this.listView4.TabIndex = 0;
            this.listView4.UseCompatibleStateImageBehavior = false;
            this.listView4.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Task";
            this.columnHeader4.Width = 97;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Execution";
            this.columnHeader5.Width = 116;
            // 
            // contextMenuTasks
            // 
            this.contextMenuTasks.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuTasks.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pASSWORDRECOVERYToolStripMenuItem,
            this.downloadAndExecuteToolStripMenuItem,
            this.sENDFILETOMEMORYToolStripMenuItem1,
            this.minerToolStripMenuItem1,
            this.uPDATEToolStripMenuItem1,
            this.toolStripSeparator4,
            this.dELETETASKToolStripMenuItem});
            this.contextMenuTasks.Name = "contextMenuStrip4";
            this.contextMenuTasks.ShowImageMargin = false;
            this.contextMenuTasks.Size = new System.Drawing.Size(250, 202);
            // 
            // pASSWORDRECOVERYToolStripMenuItem
            // 
            this.pASSWORDRECOVERYToolStripMenuItem.Name = "pASSWORDRECOVERYToolStripMenuItem";
            this.pASSWORDRECOVERYToolStripMenuItem.Size = new System.Drawing.Size(249, 32);
            this.pASSWORDRECOVERYToolStripMenuItem.Text = "PASSWORD RECOVERY";
            this.pASSWORDRECOVERYToolStripMenuItem.Click += new System.EventHandler(this.PASSWORDRECOVERYToolStripMenuItem_Click);
            // 
            // downloadAndExecuteToolStripMenuItem
            // 
            this.downloadAndExecuteToolStripMenuItem.Name = "downloadAndExecuteToolStripMenuItem";
            this.downloadAndExecuteToolStripMenuItem.Size = new System.Drawing.Size(249, 32);
            this.downloadAndExecuteToolStripMenuItem.Text = "SEND FILE TO DISK";
            this.downloadAndExecuteToolStripMenuItem.Click += new System.EventHandler(this.DownloadAndExecuteToolStripMenuItem_Click);
            // 
            // sENDFILETOMEMORYToolStripMenuItem1
            // 
            this.sENDFILETOMEMORYToolStripMenuItem1.Name = "sENDFILETOMEMORYToolStripMenuItem1";
            this.sENDFILETOMEMORYToolStripMenuItem1.Size = new System.Drawing.Size(249, 32);
            this.sENDFILETOMEMORYToolStripMenuItem1.Text = "SEND FILE TO MEMORY";
            this.sENDFILETOMEMORYToolStripMenuItem1.Click += new System.EventHandler(this.SENDFILETOMEMORYToolStripMenuItem1_Click);
            // 
            // minerToolStripMenuItem1
            // 
            this.minerToolStripMenuItem1.Name = "minerToolStripMenuItem1";
            this.minerToolStripMenuItem1.Size = new System.Drawing.Size(249, 32);
            this.minerToolStripMenuItem1.Text = "XMR MINER";
            this.minerToolStripMenuItem1.Visible = false;
            this.minerToolStripMenuItem1.Click += new System.EventHandler(this.MinerToolStripMenuItem1_Click);
            // 
            // uPDATEToolStripMenuItem1
            // 
            this.uPDATEToolStripMenuItem1.Name = "uPDATEToolStripMenuItem1";
            this.uPDATEToolStripMenuItem1.Size = new System.Drawing.Size(249, 32);
            this.uPDATEToolStripMenuItem1.Text = "UPDATE ALL CLIENTS";
            this.uPDATEToolStripMenuItem1.Click += new System.EventHandler(this.UPDATEToolStripMenuItem1_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(246, 6);
            // 
            // dELETETASKToolStripMenuItem
            // 
            this.dELETETASKToolStripMenuItem.Name = "dELETETASKToolStripMenuItem";
            this.dELETETASKToolStripMenuItem.Size = new System.Drawing.Size(249, 32);
            this.dELETETASKToolStripMenuItem.Text = "DELETE TASK";
            this.dELETETASKToolStripMenuItem.Click += new System.EventHandler(this.DELETETASKToolStripMenuItem_Click);
            // 
            // performanceCounter1
            // 
            this.performanceCounter1.CategoryName = "Processor";
            this.performanceCounter1.CounterName = "% Processor Time";
            this.performanceCounter1.InstanceName = "_Total";
            // 
            // performanceCounter2
            // 
            this.performanceCounter2.CategoryName = "Memory";
            this.performanceCounter2.CounterName = "% Committed Bytes In Use";
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "AsyncRAT";
            this.notifyIcon1.Visible = true;
            // 
            // TimerTask
            // 
            this.TimerTask.Enabled = true;
            this.TimerTask.Interval = 5000;
            this.TimerTask.Tick += new System.EventHandler(this.TimerTask_Tick);
            // 
            // shutdownToolStripMenuItem1
            // 
            this.shutdownToolStripMenuItem1.Name = "shutdownToolStripMenuItem1";
            this.shutdownToolStripMenuItem1.Size = new System.Drawing.Size(270, 34);
            this.shutdownToolStripMenuItem1.Text = "Shutdown";
            this.shutdownToolStripMenuItem1.Click += new System.EventHandler(this.ShutdownToolStripMenuItem1_Click);
            // 
            // restartToolStripMenuItem3
            // 
            this.restartToolStripMenuItem3.Name = "restartToolStripMenuItem3";
            this.restartToolStripMenuItem3.Size = new System.Drawing.Size(270, 34);
            this.restartToolStripMenuItem3.Text = "Restart";
            this.restartToolStripMenuItem3.Click += new System.EventHandler(this.RestartToolStripMenuItem3_Click);
            // 
            // logoffToolStripMenuItem1
            // 
            this.logoffToolStripMenuItem1.Name = "logoffToolStripMenuItem1";
            this.logoffToolStripMenuItem1.Size = new System.Drawing.Size(270, 34);
            this.logoffToolStripMenuItem1.Text = "Logoff";
            this.logoffToolStripMenuItem1.Click += new System.EventHandler(this.LogoffToolStripMenuItem1_Click);
            // 
            // closeToolStripMenuItem1
            // 
            this.closeToolStripMenuItem1.Name = "closeToolStripMenuItem1";
            this.closeToolStripMenuItem1.Size = new System.Drawing.Size(270, 34);
            this.closeToolStripMenuItem1.Text = "Close";
            this.closeToolStripMenuItem1.Click += new System.EventHandler(this.CloseToolStripMenuItem1_Click);
            // 
            // restartToolStripMenuItem2
            // 
            this.restartToolStripMenuItem2.Name = "restartToolStripMenuItem2";
            this.restartToolStripMenuItem2.Size = new System.Drawing.Size(270, 34);
            this.restartToolStripMenuItem2.Text = "Restart";
            this.restartToolStripMenuItem2.Click += new System.EventHandler(this.RestartToolStripMenuItem2_Click);
            // 
            // updateToolStripMenuItem2
            // 
            this.updateToolStripMenuItem2.Name = "updateToolStripMenuItem2";
            this.updateToolStripMenuItem2.Size = new System.Drawing.Size(270, 34);
            this.updateToolStripMenuItem2.Text = "Update";
            this.updateToolStripMenuItem2.Click += new System.EventHandler(this.UpdateToolStripMenuItem2_Click);
            // 
            // uninstallToolStripMenuItem
            // 
            this.uninstallToolStripMenuItem.Name = "uninstallToolStripMenuItem";
            this.uninstallToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.uninstallToolStripMenuItem.Text = "Uninstall";
            this.uninstallToolStripMenuItem.Click += new System.EventHandler(this.UninstallToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(267, 6);
            // 
            // showFolderToolStripMenuItem
            // 
            this.showFolderToolStripMenuItem.Name = "showFolderToolStripMenuItem";
            this.showFolderToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.showFolderToolStripMenuItem.Text = "Show Folder";
            this.showFolderToolStripMenuItem.Click += new System.EventHandler(this.ShowFolderToolStripMenuItem_Click);
            // 
            // clientToolStripMenuItem
            // 
            this.clientToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.closeToolStripMenuItem1,
            this.restartToolStripMenuItem2,
            this.updateToolStripMenuItem2,
            this.uninstallToolStripMenuItem,
            this.toolStripSeparator3,
            this.showFolderToolStripMenuItem});
            this.clientToolStripMenuItem.Image = global::Server.Properties.Resources.client;
            this.clientToolStripMenuItem.Name = "clientToolStripMenuItem";
            this.clientToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.clientToolStripMenuItem.Text = "Client";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1301, 511);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.statusStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AsyncRAT-Sharp";
            this.Activated += new System.EventHandler(this.Form1_Activated);
            this.Deactivate += new System.EventHandler(this.Form1_Deactivate);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.contextMenuClient.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.contextMenuLogs.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.contextMenuThumbnail.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.contextMenuTasks.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader lv_ip;
        private System.Windows.Forms.ColumnHeader lv_user;
        private System.Windows.Forms.ColumnHeader lv_os;
        private System.Windows.Forms.ContextMenuStrip contextMenuClient;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Timer ping;
        private System.Windows.Forms.Timer UpdateUI;
        private System.Windows.Forms.ToolStripMenuItem sENDFILEToolStripMenuItem;
        public System.Windows.Forms.ColumnHeader lv_hwid;
        private System.Windows.Forms.ColumnHeader lv_country;
        private System.Windows.Forms.ToolStripMenuItem bUILDERToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ColumnHeader lv_version;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        public System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Diagnostics.PerformanceCounter performanceCounter1;
        private System.Diagnostics.PerformanceCounter performanceCounter2;
        public System.Windows.Forms.ColumnHeader lv_act;
        private System.Windows.Forms.ToolStripMenuItem aBOUTToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ContextMenuStrip contextMenuThumbnail;
        private System.Windows.Forms.ToolStripMenuItem sTARTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sTOPToolStripMenuItem;
        public System.Windows.Forms.ImageList ThumbnailImageList;
        public System.Windows.Forms.ListView listView3;
        public System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ColumnHeader lv_admin;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ContextMenuStrip contextMenuTasks;
        private System.Windows.Forms.ToolStripMenuItem downloadAndExecuteToolStripMenuItem;
        public System.Windows.Forms.ListView listView4;
        private System.Windows.Forms.ToolStripMenuItem sENDFILETOMEMORYToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem uPDATEToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem dELETETASKToolStripMenuItem;
        private System.Windows.Forms.Timer TimerTask;
        private System.Windows.Forms.ToolStripMenuItem tOMEMORYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tODISKToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuLogs;
        private System.Windows.Forms.ToolStripMenuItem cLEARToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem monitoringToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem remoteDesktopToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem keyloggerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem passwordRecoveryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fileManagerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem processManagerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem reportWindowToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miscellaneousToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem botsKillerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uSBSpreadToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem extraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visitWebsiteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sendMessageBoxToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem chatToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem runToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem stopToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem systemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pCToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem seedTorrentToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem remoteShellToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem dOSAttackToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripMenuItem executeNETCodeToolStripMenuItem;
        private System.Windows.Forms.ColumnHeader lv_av;
        private System.Windows.Forms.ToolStripMenuItem pASSWORDRECOVERYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blankScreenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem getAdminPrivilegesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem disableWindowsDefenderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem webcamToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xMRMinerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem runToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem killToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem serverToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem blockClientsToolStripMenuItem;
        private System.Windows.Forms.ColumnHeader lv_ins;
        public System.Windows.Forms.ColumnHeader lv_ping;
        private System.Windows.Forms.ToolStripMenuItem minerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem runToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem stopToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem setWallpaperToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem filesSearcherToolStripMenuItem;
        private System.Windows.Forms.ColumnHeader lv_group;
        private System.Windows.Forms.ToolStripMenuItem clientToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem restartToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem updateToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem uninstallToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem showFolderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoffToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem restartToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem shutdownToolStripMenuItem1;
    }
}

