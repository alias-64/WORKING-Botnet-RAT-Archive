# HiddenzHVNC
R.I.P. HIVE/Hiddenz/Mistercoenkel. This is free release for all kids who got scammed/ghosted by gentelman mentioned above. Have fun...

For the time being, project will be published like this, more as test of my protector project. If anyone manages to reverse it should feel free to contact me on tg @EvilInside1312 for bonus content...

GL&HF ;)

# Status: iPwn

![ss1](https://user-images.githubusercontent.com/1867768/158731425-fb8d56b4-c476-402f-bf11-36f69fb56753.jpg)
![ss3](https://user-images.githubusercontent.com/1867768/158731408-4a079151-407c-4698-8e41-f7b418939085.jpg)
![ss2](https://user-images.githubusercontent.com/1867768/158731427-0a420e23-6a65-42b9-b59d-1c37e0f19a3d.jpg)
![ss4](https://user-images.githubusercontent.com/1867768/158731413-b6a6ea7c-d622-4651-bb51-1ea6ca58888e.jpg)
![ss5](https://user-images.githubusercontent.com/1867768/158731418-c2943f14-b277-469b-9bb9-f0dac25746af.jpg)
![ss6](https://user-images.githubusercontent.com/1867768/158731423-0634c97c-b891-4441-bd5c-ddb4e8b42857.jpg)
