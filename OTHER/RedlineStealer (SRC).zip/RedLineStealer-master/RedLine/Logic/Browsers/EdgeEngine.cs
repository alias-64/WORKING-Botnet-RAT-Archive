﻿using RedLine.Models.Browsers;

namespace RedLine.Logic.Browsers
{
  public static class EdgeEngine
  {
    public static Browser ParseBrowsers()
    {
      return new Browser();
    }
  }
}
