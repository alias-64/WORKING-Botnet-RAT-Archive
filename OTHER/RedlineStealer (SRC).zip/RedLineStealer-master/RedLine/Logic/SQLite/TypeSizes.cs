﻿namespace RedLine.Logic.SQLite
{
  public struct TypeSizes
  {
    public long Size { get; set; }

    public long Type { get; set; }
  }
}
