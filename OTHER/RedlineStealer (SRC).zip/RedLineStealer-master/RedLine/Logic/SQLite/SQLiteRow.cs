﻿namespace RedLine.Logic.SQLite
{
  public struct SQLiteRow
  {
    public long ID { get; set; }

    public string[] RowData { get; set; }
  }
}
