﻿namespace RedLine.Logic.Json
{
  public enum JsonType
  {
    String,
    Number,
    Object,
    Array,
    Boolean,
  }
}
