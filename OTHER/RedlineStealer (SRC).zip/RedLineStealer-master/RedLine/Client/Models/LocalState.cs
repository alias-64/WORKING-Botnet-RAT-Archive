﻿namespace RedLine.Client.Models
{
  public class LocalState
  {
    public OsCrypt os_crypt { get; set; }
  }
}
