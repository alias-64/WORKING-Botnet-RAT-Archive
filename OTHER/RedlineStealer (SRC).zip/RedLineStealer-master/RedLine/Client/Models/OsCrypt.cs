﻿namespace RedLine.Client.Models
{
  public class OsCrypt
  {
    public string encrypted_key { get; set; }
  }
}
