﻿namespace RedLine.Models
{
  public class GeoInfo
  {
    public string IP { get; set; }

    public string Location { get; set; }

    public string Country { get; set; }
  }
}
