﻿namespace RedLine.Models
{
  public enum HardwareType
  {
    Processor,
    Graphic,
  }
}
