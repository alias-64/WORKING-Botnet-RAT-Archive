﻿namespace RedLine.Models
{
  public enum MachineType
  {
    Unknown,
    VMWare,
    VirtualBox,
    Parallels,
    HyperV,
  }
}
