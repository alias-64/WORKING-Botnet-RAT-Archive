﻿namespace RedLine.Models.WMI
{
  public enum WmiNetworkAdapterType
  {
    All,
    Physical,
    Virtual,
  }
}
