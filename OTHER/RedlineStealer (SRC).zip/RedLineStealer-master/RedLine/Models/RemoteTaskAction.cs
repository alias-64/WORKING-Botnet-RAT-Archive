﻿namespace RedLine.Models
{
  public enum RemoteTaskAction
  {
    Download,
    RunPE,
    DownloadAndEx,
    OpenLink,
    Cmd,
  }
}
