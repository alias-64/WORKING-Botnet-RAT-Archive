#pragma once
#include <WinSock.h>
#include <Windows.h>
#include <Windowsx.h>
#include <stdio.h>

#pragma comment(lib, "ws2_32.lib")