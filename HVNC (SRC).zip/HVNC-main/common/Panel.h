#include "Common.h"

char *PanelRequest(char *data, int *outputSize);
void  InitPanelRequest();