#pragma once
#include "Common.h"

BOOL InjectDll(BYTE *dllBuffer, HANDLE hProcess, BOOL x64);